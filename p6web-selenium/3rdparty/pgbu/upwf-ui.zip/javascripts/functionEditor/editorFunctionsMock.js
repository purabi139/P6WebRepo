define(["underscore"], function (_) {
    "use strict";

    return {
        put: function (json) {
            return "";
        },

        get: function () {
            return {
                functionBody: ""
            };
        }
    };
});