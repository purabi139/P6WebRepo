define([], function () {
    return {
        Event: {
            TARGET_OBJECT_TYPE_CHANGED: "functionEditor:targetObjectTypeChanged",
            TARGET_FIELD_CHANGED: "functionEditor:targetFieldChanged",
            SAVE_BUTTON_CLICKED: "functionEditor:saveButtonClicked",
            DELETE_BUTTON_CLICKED: "functionEditor:deleteButtonClicked"
        }
    };
});