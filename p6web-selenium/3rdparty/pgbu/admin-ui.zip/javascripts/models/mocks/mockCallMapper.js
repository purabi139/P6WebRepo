/*
 * If there is a live JSON resource available, the call must not be mocked in here.
 * This is the mock definition file for the production server.
 *
 * The goal of this file should be to have it empty.
 */
(function () {
    'use strict';
    window.mock_call_mapper = [
        {
            name : "Global Options",
            url : /rest\/security\/global\/options/,
            mockUrl : "javascripts/features/admin/securitymanagement/mock/globalOptions.json",
            useMock : true
        }
    ];
}());
