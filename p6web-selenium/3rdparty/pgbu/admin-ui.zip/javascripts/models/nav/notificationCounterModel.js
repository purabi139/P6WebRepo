define(['underscore', 'backbone'], function (_, Backbone) {
    'use strict';
    return Backbone.Model.extend({
        url : 'notifications',
        defaults : {
            count : 0,
            unreadCounter : -1
        }
    });
});
