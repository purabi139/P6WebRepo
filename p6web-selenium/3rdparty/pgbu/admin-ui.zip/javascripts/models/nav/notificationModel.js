define(['underscore', 'backbone'], function (_, Backbone) {
    'use strict';
    var notifications = {};

    notifications.model = Backbone.Model.extend({
        defaults : {
            shortDescription : '',
            message : '',
            type : 'insight',
            notificationDate : new Date(),
            read : false,
            ignore : false
        }
    });

    notifications.collection = Backbone.Collection.extend({
        model : notifications.model,
        url : 'rest/notifications',
        pagePosition : 0,
        pageIncrement : 4,
        comparator : function (model) {
            return -Date.create(model.get('notificationDate')).getTime();
        }
    });


    return notifications;
});
