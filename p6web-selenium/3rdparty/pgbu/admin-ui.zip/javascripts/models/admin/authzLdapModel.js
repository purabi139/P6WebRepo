define(['jquery', 'underscore', 'backbone'],
    function ($, _, Backbone) {
    'use strict';

    /*
     * Re-use the same models and collections for both direct Ldap queries and Opss associations.
     */

    var Ldap = {};
    
    Ldap.GroupModel = Backbone.Model.extend({
        defaults: {
            'name': '',
            'description': ''
        },

        // Artificially add id during fetch for Backbone isNew() bookkeeping
        parse: function (rawData) {
            return _.extend(rawData, { id: rawData.name });
        },

        toJSON: function () {
            return this.get('name');
        },

        fetch: _.noop // Not possible to operate on a single group
    });

    /**
     * GroupCollection for both Ldap groups and Opss group assignments
     * @type {Ldap.GroupCollection (attributes, options)}
     * @param {Array} attributes, may be empty
     * @param {Object} options
     *    // optional 'options'
     *    profileID: {String} id of an Authz.ProfileModel
     *    // required 'options'
     *    parse: {Boolean} always set to true for new & reset, never for add.
     */
    Ldap.GroupCollection = Backbone.Collection.extend({
        model: Ldap.GroupModel,
        ldapUrl: 'rest/ldap/roles',
        opssUrlFormat: 'rest/authorizationProfiles/%0/groups',

        initialize: function (items, options) {
            var that = this;
            that._reinitialize();
            // Backbone.Collection calls initialize() before reset() and brute forces reset to be silent,
            // so we can't clone this._byId during initialization.
            that._originalMap = items.length ?
                _.reduce(items, function (map, item) { map[item.name] = true; }, {}) :
                {};
            that._profileID = (options && options.profileID) || null; // profileID => URL is OPSS assigned groups
            that.on('all', that._handleSelfEvent, that);
        },

        _reinitialize: function () {
            this._removedIDs = [];
            this._newCIDs = [];
            this._originalMap = this._byId ? _.clone(this._byId) : {};
        },

        _handleSelfEvent: function () {
            var argArray = _.toArray(arguments), that = this;
            var eventName = argArray[0], otherArgs = argArray.slice(1);
            var model = otherArgs[0]; // unless event is 'reset'
            var name = null; // can only get 'name' if event is not 'reset'
            switch (eventName) {
                case 'add':
                    if (model.isNew()) {
                        name = model.get('name');
                        if (that._originalMap[name]) {
                            that._removedIDs = _.without(that._removedIDs, name);
                        } else {
                            that._newCIDs = _.union(that._newCIDs, [name]);
                        }
                    } // otherwise, it is part of a reset, and we can ignore it.
                    break;
                case 'remove':
                    name = model.get('name');
                    if (that._originalMap[name]) {
                        that._removedIDs = _.union(that._removedIDs, [name]);
                    } else {
                        that._newCIDs = _.without(that._newCIDs, name);
                    }
                    break;
                case 'reset':
                    that._reinitialize();
                    break;
            }
            return that;
        },

        url: function () {
            return this._profileID ? _.formatString(this.opssUrlFormat, this._profileID) : this.ldapUrl;
        },

        getRemovedIDs: function () {
            return _.clone(this._removedIDs);
        },

        getNewCIDs: function () {
            return _.clone(this._newCIDs);
        },

        isDirty: function () {
            return (this._newCIDs.length + this._removedIDs.length) ? true : false;
        },

        toJSON: function () {
            return {
                removed: this.getRemovedIDs(),
                added: this.getNewCIDs()
            };
        }
    });

    Ldap.UserModel = Backbone.Model.extend({
        defaults: {
            'userName': '',
            'firstName': '',
            'lastName': ''
        },

        // Artificially add id during fetch for Backbone isNew() bookkeeping
        parse: function (rawData) {
            return _.extend(rawData, { id: rawData.userName });
        },

        toJSON: function () {
            return this.get('userName');
        },

        fetch: _.noop // Not possible to operate on a single user
    });

    /**
     * UserCollection for both Ldap users and Opss user assignments
     * @type {Ldap.UserCollection (attributes, options)}
     * @param {Array} attributes, may be empty
     * @param {Object} options
     *    // optional 'options'
     *    profileID: {String} id of an Authz.ProfileModel
     *    // required 'options'
     *    parse: {Boolean} always set to true for new & reset, never for add.
     */
    Ldap.UserCollection = Backbone.Collection.extend({
        model: Ldap.UserModel,
        ldapUrl: 'rest/ldap/users',
        opssUrlFormat: 'rest/authorizationProfiles/%0/users',

        initialize: function (items, options) {
            var that = this;
            that._reinitialize();
            // Backbone.Collection calls initialize() before reset() and brute forces reset to be silent,
            // so we can't clone this._byId during initialization.
            that._originalMap = (items && items.length) ?
                _.reduce(items, function (map, item) { map[item.userName] = true; }, {}) :
            {};
            that._profileID = (options && options.profileID) || null; // profileID => URL is OPSS assigned users
            that.on('all', that._handleSelfEvent, that);
        },

        _reinitialize: function () {
            this._removedIDs = [];
            this._newCIDs = [];
            this._originalMap = this._byId ? _.clone(this._byId) : {};
        },

        _handleSelfEvent: function () {
            var argArray = _.toArray(arguments), that = this;
            var eventName = argArray[0], otherArgs = argArray.slice(1);
            var model = otherArgs[0]; // unless event is 'reset'
            var name = null; // can only get 'name' if event is not 'reset'
            switch (eventName) {
                case 'add':
                    if (model.isNew()) {
                        name = model.get('userName');
                        if (that._originalMap[name]) {
                            that._removedIDs = _.without(that._removedIDs, name);
                        } else {
                            that._newCIDs = _.union(that._newCIDs, [name]);
                        }
                    } // otherwise, it is part of a reset, and we can ignore it.
                    break;
                case 'remove':
                    name = model.get('userName');
                    if (that._originalMap[name]) {
                        that._removedIDs = _.union(that._removedIDs, [name]);
                    } else {
                        that._newCIDs = _.without(that._newCIDs, name);
                    }
                    break;
                case 'reset':
                    that._reinitialize();
                    break;
            }
            return that;
        },

        url: function () {
            return this._profileID ? _.formatString(this.opssUrlFormat, this._profileID) : this.ldapUrl;
        },

        getRemovedIDs: function () {
            return _.clone(this._removedIDs);
        },

        getNewCIDs: function () {
            return _.clone(this._newCIDs);
        },

        isDirty: function () {
            return (this._newCIDs.length + this._removedIDs.length) ? true : false;
        },

        toJSON: function () {
            return {
                removed: this.getRemovedIDs(),
                added: this.getNewCIDs()
            };
        }
    });

    return Ldap;
});
