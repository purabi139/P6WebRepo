define(['jquery', 'underscore', 'backbone'],
    function ($, _, Backbone) {
    'use strict';

    var Authz = {};

    Authz.ProfileModel = Backbone.Model.extend({
        name: 'Authz.ProfileModel',
        defaults: {
            displayName: '',
            description: '',
            default : false,
            permissions:null,
            newProfileId:null,
            assignedUsers:null
        },
        idAttribute: 'internalName',
        // No url: we never fetch just one profile.

        initialize: function () {
            this.on('all', this._handleSelfEvent, this);
        },
        toJSON: function () {
            var that = this;
            var jsonObject = _.extend((that.id ? { internalName: that.id } : {}), {
                displayName: that.get('displayName'),
                description: that.get('description'),
                privileges:that.get('permissions'),
                default: that.get('default'),
                users: _.map(that.get('assignedUsers'), function(user){return _.omit(user,['key','actualname']);})
            });

            return jsonObject;
        },

        _handleSelfEvent: function () {
            var argArray = _.toArray(arguments), that = this, thisSetEvent = argArray[0];
            switch (thisSetEvent) {
                case 'change:privileges':
                case 'change:groupAssignments':
                case 'change:userAssignments':
                    // arguments: [0: eventName, 1: that, 2: value, 3: options]
                    var eventParts = thisSetEvent.split(':'), attrName = eventParts.slice(1).join(':');
                    var attrValue = argArray[2], options = argArray[3];
                    var propagate = function () {
                        var attrArgs = _.toArray(arguments), eventName = attrArgs[0], otherArgs = attrArgs.slice(1);
                        var newEventName = eventName.split(':');
                        newEventName.splice(1, 0, attrName);
                        that.collection.trigger(newEventName.join(':'), that, that.collection, otherArgs);
                    };
                    if (attrValue && attrValue.hasOwnProperty('models') && that.collection) {
                        attrValue[options.unset ? 'off' : 'on']('all', propagate);
                    }
                    break;
            }
        }
    });

    Authz.ProfileCollection = Backbone.Collection.extend({
        name: 'Authz.ProfileCollection',
        url: 'rest/security', // Pass name param in fetch options to filter
        model: Authz.ProfileModel,
        comparator : function (profile) {
            return profile.get('displayName');
        },

        initialize: function () {
            this._reinitialize();
            this.on('all', this._handleSelfEvent, this);
        },

        _reinitialize: function () {
            this._removedIDs = [];
            this._changedIDs = [];
            this._newCIDs = [];
        },

        _handleSelfEvent: function () {
            var argArray = _.toArray(arguments), that = this;
            var eventName = argArray[0], eventParts = eventName.split(':'), otherArgs = argArray.slice(1);
            var model = otherArgs[0]; // unless event is 'reset'
            switch (eventName) {
                case 'add':
                    that._newCIDs = _.union(that._newCIDs, [model.cid]);
                    that._removedIDs = _.without(that._removedIDs, model.id);
                    break;
                case 'remove':
                        that._newCIDs = _.without(that._newCIDs, model.cid);
                        that._changedIDs = _.without(that._changedIDs, model.id);
                        that._removedIDs = _.union(that._removedIDs, model.id);
                    break;
                case 'change:internalName':
                    if(model.get('internalName')){
                        that._newCIDs = _.without(that._newCIDs, model.cid);
                    }
                    break;
                case 'change:newProfileId':
                    //do nothing this is a UI attribute to hold temporary new ID
                    break;
                default:
                    if (1 < eventParts.length) {
                        switch (eventParts[1]) {
                            case 'privileges':
                            case 'groupAssignments':
                            case 'userAssignments':
                                if (model.get(eventParts[1]).isDirty()) {
                                    that._handleModelChange(model);
                                }
                                break;
                            default:
                                that._handleModelChange(model);
                        }
                    }
            }
            return that;
        },

        _handleModelChange: function (model) {
            if (!model.isNew()) {
                this._changedIDs = _.union(this._changedIDs, [model.id]);
            }
            return this;
        },

        getNewCIDs: function () {
            return _.clone(this._newCIDs);
        },

        getChangedIDs: function () {
            return _.clone(this._changedIDs);
        },

        getChangedModels: function () {
            var that = this;
            return _.map(this.getChangedIDs(), function(id) { return that.get(id); });
        },

        getRemovedIDs: function () {
            return _.clone(this._removedIDs);
        },

        isDirty: function () {
            return (this._removedIDs.length + this._changedIDs.length + this._newCIDs.length) ? true : false;
        },

        toJSON: function () {
            var that = this;
            return {
                removed: _.clone(that._removedIDs),
                added: _.map(that._newCIDs, function (cid) {
                        return that.get(cid).toJSON();
                    }),
                changed: _.map(that._changedIDs, function (id) {
                        return that.get(id).toJSON();
                    })
            };
        },

        // Not part of the Backbone API for Collection
        save: function (options) {
            return (this.sync || Backbone.sync)('create', this, options || {});
        }
    });

    return Authz;
});
