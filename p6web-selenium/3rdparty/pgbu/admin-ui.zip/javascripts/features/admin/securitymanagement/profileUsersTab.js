define([
    'jquery', 'underscore', 'gridapi'],
    function ($, _) {
        'use strict';
        var grid;
        var ldapgrid;
        return {
            initializeTab : function (view) {
                grid = view.$el.find('.assigned_users_grid').grid({
                    editable : false,
                    layout : {
                        width : '500px',
                        height : '500px',
                        waffers : [
                            {
                                id : 'global_profile_users',
                                type : 'flex'
                            }
                        ]
                    },
                    rows : {
                        id : 'key'
                    },
                    selection : {mode : 'check'},
                    contextMenu : {
                        enabled : false,
                        populate : false
                    },
                    columnMenu : false,
                    columns : {
                        groups : [
                            {
                                id : 'bar',
                                type : 'flex',
                                columns : [
                                    {
                                        title : 'User Name',
                                        dataIndex : 'userName',
                                        draggable : false,
                                        resize : false
                                    },
                                    {
                                        title : 'Actual Name',
                                        dataIndex : 'displayName',
                                        width : '200px',
                                        draggable : false,
                                        resize : false
                                    },
                                    {
                                        title : 'Email',
                                        dataIndex : 'emailAddress',
                                        draggable : false,
                                        resize : false
                                    },
                                    {
                                        title : 'Phone',
                                        dataIndex : 'phoneNumber',
                                        draggable : false,
                                        resize : false
                                    }
                                ]
                            }
                        ]
                    }
                });
            },
            populateAssignedUsers : function (store) {
                store = store || [];
                grid.data('grid').element.grid('setStore', store);

            },
            populateLdapUsers : function (store) {
                store = store || [];
                ldapgrid.data('grid').element.grid('setStore', store);

            },
            openAssignUser : function (view) {
                var userTabScope = this;
                var assignUserDialog = $('#assign-users-modal');
                if (!ldapgrid) {
                    ldapgrid = view.$el.find('.ldap-users-grid').grid({
                        editable : false,
                        layout : {
                            //width : '650px',
                            height : '250px',
                            waffers : [
                                {
                                    id : 'ldap_users',
                                    type : 'flex'
                                }
                            ]
                        },
                        rows : {
                            id : 'key'
                        },
                        selection : {
                            mode : 'check'
                        },
                        contextMenu : {
                            enabled : false,
                            populate : false
                        },
                        columnMenu : false,
                        columns : {
                            groups : [
                                {
                                    id : 'bar',
                                    type : 'flex',
                                    columns : [
                                        {
                                            title : 'User Name',
                                            dataIndex : 'userName',
                                            draggable : false,
                                            resize : false
                                        },
                                        {
                                            title : 'Actual Name',
                                            dataIndex : 'displayName',
                                            //width : '200px',
                                            draggable : false,
                                            resize : false
                                        },
                                        {
                                            title : 'Email',
                                            dataIndex : 'emailAddress',
                                            draggable : false,
                                            resize : false
                                        },
                                        {
                                            title : 'Phone',
                                            dataIndex : 'phoneNumber',
                                            draggable : false,
                                            resize : false
                                        }
                                    ]
                                }
                            ]
                        }
                    });

                    assignUserDialog.on('hide', function(){
                        ldapgrid.data('grid').clearSelection();
                    });
                    assignUserDialog.find('button.assign-user-assign').on('click', function () {
                        var currentSelectedLdapUsers = ldapgrid.data('grid').getSelection() || [];
                        if (!_.isEmpty(currentSelectedLdapUsers)) {
                            var currentAssignedUsers = view._selectedProfileModel.get('assignedUsers');
                            _.each(currentSelectedLdapUsers, function (ldapuser) {
                                ldapuser.key = currentAssignedUsers.length;
                                currentAssignedUsers.push(ldapuser);
                            });

                            view._selectedProfileModel.unset('assignedUsers');
                            view._selectedProfileModel.set('assignedUsers', currentAssignedUsers);
                            userTabScope.populateAssignedUsers(view._selectedProfileModel.get('assignedUsers'));
                        }

                        assignUserDialog.modal('hide');
                    });
                }
                assignUserDialog.modal({backdrop : 'static', show : true});
                view.trigger('openAssignUserDialog');
            }
        };
    }
);