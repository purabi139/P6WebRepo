define(['jquery', 'underscore','src/features/admin/securitymanagement/securityManagementView',
    'src/features/admin/securitymanagement/securityProfileModel', 'src/enums/actionBar','underscorestring'],
    function ($, _, SecurityManagementView, globalProfileModel, ActionBarEnums) {
        'use strict';

        var securityView = new SecurityManagementView();

        function SecurityController() {
            this.initialize();
        }

        $.extend(SecurityController.prototype, {
            initialize : function () {
                var securityControllerScope = this;
                var globalProfiles = $.getJSON('rest/security/global');
                var globalOptions = $.getJSON('rest/security/global/options');

                $.when(globalProfiles, globalOptions)
                    .done(function (globalpermissions, globalOptions) {
                        //populate the backbone model with global permission sets
                        securityControllerScope.globalCollection = new globalProfileModel.ProfileCollection(_.map(globalpermissions[0],
                            function (profile) {

                                profile.internalName = _.unescapeHTML(profile.internalName);
                                profile.displayName = _.unescapeHTML(profile.displayName);
                                profile.description = _.unescapeHTML(profile.description);
                                return profile;
                            }));
                        securityView.setData({groups : globalOptions[0], globalPermissionSet : securityControllerScope.globalCollection});
                    });


                securityView.on('change:selectedProfileModel changeDefaultProfile', function (selectedProfileModel) {
                    if (!selectedProfileModel.isNew() && !selectedProfileModel.has('permissions')) {
                        $.get('rest/security/' + encodeURIComponent(_.unescapeHTML(selectedProfileModel.get('internalName'))) + '/info').done(function (profileModulesResponse) {
                            //fill in the permissions of the selected permission set
                            var profileInfo = _.isString(profileModulesResponse) ? $.parseJSON(profileModulesResponse) : profileModulesResponse;
                            profileInfo.permissions = _.filter(profileInfo.permissions, function (val) {
                                return (val !== null);
                            });

                            selectedProfileModel.set('permissions', profileInfo.permissions, {silent : true});
                            selectedProfileModel.set('assignedUsers', profileInfo.users || [], {silent : true});
                            securityView.populatePermissions();
                        }).fail(function (errorResponse) {
                                selectedProfileModel.set('permissions', [], {silent : true});
                                selectedProfileModel.set('assignedUsers', [], {silent : true});
                                securityView.populatePermissions();
                            });
                    } else {
                        securityView.populatePermissions();
                    }
                    //?? Should I return anything here?
                });

                securityView.on(ActionBarEnums.Event.SAVE, function () {
                    securityControllerScope.globalCollection.save({
                        url : securityControllerScope.globalCollection.url + '/global',
                        complete : function (jqXHR, textStatus) {
                            securityView.clean();
                        },
                        success : function (data, textStatus, jqXHR) {
                            var newProfilesToSync = [];
                            if (data.added) {

                                _.each(data.added, function (createdProfile) {
                                        var createdProfileModel = securityControllerScope.globalCollection.where({displayName : _.str.unescapeHTML(createdProfile.displayName)})[0];
                                        createdProfileModel.set('internalName', createdProfile.internalName);
                                        newProfilesToSync.push({currentID : createdProfileModel.get('newProfileId'), newID : createdProfileModel.get('internalName')});
                                        createdProfileModel.unset('newProfileId');
                                    }
                                );
                            }
                            securityView.syncProfileElements(newProfilesToSync);
                            securityView.closeEditMode();
                        }});
                });

                securityView.on(ActionBarEnums.Event.CANCEL, function () {
                    securityView.cancelChanges();
                });

                securityView.on('openAssignUserDialog', function () {
                    $.getJSON('rest/ldap/users','',function(result){
                        securityView.populateLdapUsers(result);
                    });
                });
            }
        });

        return SecurityController;
    });
