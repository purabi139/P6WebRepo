define([
    'jquery', 'underscore', 'backbone', 'i18n!src/nls/localeStrings', 'pgbu-backbone',
    'src/views/common/pageView',
    'text!src/features/admin/securitymanagement/securityManagement.htm',
    'src/views/widgets/forms/formCheckbox', 'src/features/admin/securitymanagement/securityProfileModel','src/features/admin/securitymanagement/profileUsersTab',
    'src/views/widgets/scrollablelist', 'src/views/widgets/checkboxTable', 'underscorestring',
    'src/views/widgets/filter/filter'
], function ($, _, Backbone, Locale, PgbuBackbone, PageView, securityLayout, FormCheckbox, profileModel,usersTab) {
    'use strict';
    var $securityMarkup = $(securityLayout);
    var pageLayoutMarkup = _.pluckMarkup($securityMarkup, '.security_mgmt', null);
    var default_profile_indicatorMarkup = '<span class="default-profile-text">(<%=lbl_default_profile_indicator%>)</span>';

    var privilegeTablesSelector = '.privilege-list table';
    var lastSelectedProfileModel;
    var currentScope;


    var securityManagementView = PageView.extend({
        events : {
            'click div.open .dropdown-menu a.duplicate-profile-selected' : function ($event) {
                this._duplicateProfile($event);
            },
            'click button.add-profile' : function ($event) {
                this._addProfile($event);
            },
            'click button.expandAll' : function () {
                this._expandAll();
            },
            'click button.collapseAll' : function () {
                this._collapseAll();
            },
            'editend .left-navigation .scrollable' : function ($event) {
                this._addToCollection($event);
            },
            'click .profile-details .profile-details-edit-text' : function ($event) {
                this._editDetails($event);
            },
            'blur .profile-details-edit input,textarea' : function ($event) {
                this._editDetailsData($event);
            },
            'click .profile-default input[type=checkbox]' : function ($event) {
                if (!$($event.currentTarget).is(':checked')) {
                    $event.stopPropagation();
                    return false;
                }

                this._setDefaultProfile();
            },
            'click button.assign-user' : function($event){
                this._openAssignUserDialog();
            }
        },
        getContentMarkup : function () {
            var userStrings = {global : "Global Profiles", project : "Project Profiles", tableType : "global-privileges", privileges : "Privileges", users : "Users", expand_all_text : "Expand All",
                no_profile_selected_text : "Select a profile to view more information.", lbl_default_profile : "Default Profile", user_assignment_header:"User Assignments",
                assign_user_lbl: "Assign User", remove_lbl: "Remove", cancel_lbl:"Cancel", assign_lbl:"Assign"};
            return _.template(pageLayoutMarkup, userStrings);

        },
        renderChildren : function () {
            var securityViewScope = this;

            securityViewScope.$el.find('.profile-selected').hide();
            //TODO: localize "Edit"
            securityViewScope.$el.find('.profile-details .profile-details-edit-text').html('Edit');
            securityViewScope.$el.find('label.profile-description-label').html('Description');
            securityViewScope.$el.find('.profile-details-edit').hide();
            securityViewScope.$el.find('.left-navigation button.delete-profile').prop('disabled', true);
            usersTab.initializeTab(securityViewScope);
        },
        setData : function (options) {
            var securityViewScope = this;

            _.extend(securityViewScope.options, options);

            //Create a copy of collection to reset the collection if the clicks cancel
            if (!securityViewScope.options.backupGlobalPermissionSet) {
                securityViewScope.options.backupGlobalPermissionSet = new profileModel.ProfileCollection();
                //securityViewScope.options.backupGlobalPermissionSet.on('all',function(eventName){alert("eventName: " + eventName);});
                if (securityViewScope.options.globalPermissionSet) {

                    _.each(securityViewScope.options.globalPermissionSet.models, function (model) {
                        var modelCopy = model.clone();
                        securityViewScope.options.backupGlobalPermissionSet.add(modelCopy);
                    });
                }
            }

            securityViewScope.options.globalPermissionSet.on('change remove', $.proxy(securityViewScope._changeCollection,securityViewScope));

            //Populate the scrollable list with permission sets
            var profilesInfo = securityViewScope._transformScrollableListData(securityViewScope);
            securityViewScope.options.leftNavigation = securityViewScope.$el.find('.left-navigation .scrollable');
            var selectionProfileHandler = $.proxy(securityViewScope._selectProfile, securityViewScope);
            securityViewScope.options.leftNavigation.scrollablelist({
                content : profilesInfo,
                selected : selectionProfileHandler,
                deleteButtons : true,
                newPlaceholder : "New Profile",
                editstart : function ($event, newId) {
                    securityViewScope._addToCollection(newId.id);
                },
                remove : function ($event, deletedId) {
                    var deletedModel = securityViewScope.options.globalPermissionSet.get(deletedId);
                    if (!deletedModel) {
                        deletedModel = securityViewScope.options.globalPermissionSet.where({newProfileId : deletedId})[0];
                    }
                    securityViewScope.options.globalPermissionSet.remove(deletedModel);
                    if (deletedId === securityViewScope._selectedProfileModel.get((securityViewScope._selectedProfileModel.isNew()) ? 'newProfileId' : 'internalName')) {
                        securityViewScope._selectedProfileModel = null;
                    }
                    securityViewScope._clearSelection();
                }
            });

            securityViewScope.$el.find('.left-navigation .profile-search').filtersearch({
                alternateText : 'Search Profiles',
                placeholder : 'Search Profiles',
                getSelectorsToHide : function (matchedIds) {
                    var matchedSelector = _.map(matchedIds,
                        function (matchedId) {
                            return "[id=" + matchedId + "]";
                        }).join(',');
                    return matchedSelector ? [$('.profile-list li:not(' + matchedSelector + ')')] : [];
                },
                searchData : securityViewScope.options.filterSearchData,
                resetSearch: function(){
                    securityViewScope.$el.find('.hidden').removeClass('hidden');
                }
            });

            securityViewScope._setDefaultProfile();

            securityViewScope.options.$rightContent = $('.right-content ul.privilege-list');
            var tableCheckboxSections = _.map(securityViewScope.options.groups, function (value, key, list) {
                return {columnHeaders : value.actions, rowHeaders : value.entities, title : value.title};
            });
            securityViewScope.options.$rightContent.tableofcheckboxes({
                sections : tableCheckboxSections,
                tablePrefix : 'global-privileges_',
                tableofcheckboxchanged : function (event) {
                    if (securityViewScope._selectedProfileModel) {
                        var tablePermissions = _.map(securityViewScope.options.$rightContent.tableofcheckboxes("getCheckboxes"),
                            function (value, key, list) {
                                return {resourceType : value.row, actions : value.columns};
                            });
                        securityViewScope._selectedProfileModel.set('permissions', tablePermissions);
                    }
                },
                expandCollapseCallback : function (event) {
                    securityViewScope._handleExpandCollapse();
                }
            });

        },
        _handleExpandCollapse : function () {
            var securityViewScope = this;

            var expcollapseButton = securityViewScope.$el.find('button.expandCollapse');

            if (securityViewScope.$el.find(privilegeTablesSelector + ':visible').length > 0) {
                expcollapseButton.removeClass('expandAll');
                expcollapseButton.addClass('collapseAll');
                expcollapseButton.html('Collapse All');
            } else {
                expcollapseButton.removeClass('collapseAll');
                expcollapseButton.addClass('expandAll');
                securityViewScope.$el.find('button.expandAll').html('Expand All');

            }
        },
        _setDefaultProfile : function () {
            var securityViewScope = this;

            var currentDefaultProfile = securityViewScope.options.globalPermissionSet.where({"default" : true})[0];
            if (currentDefaultProfile || securityViewScope._selectedProfileModel) {
                if (securityViewScope._selectedProfileModel) {
                    if (currentDefaultProfile) {
                        currentDefaultProfile.set('default', false, {silent : true});
                        securityViewScope.trigger('changeDefaultProfile', currentDefaultProfile);
                    }
                    securityViewScope.options.leftNavigation.find('.default-profile-text').remove();
                    securityViewScope._selectedProfileModel.set('default', true);
                    currentDefaultProfile = securityViewScope._selectedProfileModel;
                }

                var defaultInternalName = currentDefaultProfile.get(currentDefaultProfile.isNew() ? 'newProfileId' : 'internalName');
                var defaultProfileDOM = securityViewScope.options.leftNavigation.scrollablelist('getItem',
                    defaultInternalName);
                defaultProfileDOM.append(_.template(default_profile_indicatorMarkup,
                    {lbl_default_profile_indicator : 'Default'}));
            }
        },
        _transformScrollableListData : function (securityViewScope) {
            securityViewScope.options.filterSearchData = {};
            return _.map(securityViewScope.options.globalPermissionSet.models, function (profile) {
                securityViewScope.options.filterSearchData[profile.get('displayName')] = profile.escape('internalName');
                //TODO: move accessor to tell scrollablist name of fields
                return {
                    id : profile.escape('internalName'),
                    display : profile.get('displayName')

                };
            });
        },
        _changeCollection : function (currentProfile) {
            var securityViewScope = this;

            var isValidCollection = true;
            var changedProfiles = securityViewScope.options.globalPermissionSet.getChangedModels();

            //validate all profiles before enable save button
            function validateProfile(profile, securityViewScope, isValidCollection) {
                if (profile) {
                    if (_.isEmpty(profile.get('permissions'))) {
                        securityViewScope.disableSave('Profiles must have at least one privilege.');
                        isValidCollection = false;
                    }
                    if (_.isEmpty(profile.get('displayName'))) {
                        securityViewScope.disableSave('Profiles must have a name.');
                        isValidCollection = false;
                    }

                    isValidCollection = isValidCollection && true;

                }
                return isValidCollection;
            }

            if (securityViewScope.options.globalPermissionSet.getNewCIDs() || securityViewScope.options.globalPermissionSet.getRemovedIDs() || changedProfiles) {
                if (securityViewScope.options.globalPermissionSet.getNewCIDs()) {
                    _.each(securityViewScope.options.globalPermissionSet.getNewCIDs(), function (profileCID) {
                        var newProfile = securityViewScope.options.globalPermissionSet.get(profileCID);

                        isValidCollection = validateProfile(newProfile, securityViewScope, isValidCollection);


                    });
                }
                _.each(changedProfiles, function (profile) {
                    isValidCollection = validateProfile(profile, securityViewScope, isValidCollection);
                });
            } else {
                isValidCollection = false;
            }

            if (isValidCollection) {
                securityViewScope.enableSave();
            } else {
                securityViewScope.disableSave();
            }
            securityViewScope.dirty();
        },
        _expandAll : function () {
            var securityViewScope = this;
            securityViewScope.options.$rightContent.tableofcheckboxes('expandAll');
            securityViewScope._handleExpandCollapse();
        },
        _collapseAll : function () {
            var securityViewScope = this;
            securityViewScope.options.$rightContent.tableofcheckboxes('collapseAll');
            securityViewScope._handleExpandCollapse();
        },
        _addProfile : function ($event) {
            var securityViewScope = this;
            return securityViewScope.options.leftNavigation.scrollablelist('insert', 0);
        },
        _duplicateProfile : function ($event) {
            $event.preventDefault();
            // still need the name to map to a profile and change profile placeholdername
            var lastSelectedProfileText =   this._selectedProfileModel.get('displayName');
//            var lastSelectedProfileText = $('.profile-list .selected a').text();
            var openParenIndex = lastSelectedProfileText.indexOf("(");
            var closeParenIndex = lastSelectedProfileText.indexOf(")");
            if ((openParenIndex > 0 ) && (closeParenIndex > 0)) {
                var count = lastSelectedProfileText.substring(openParenIndex + 1, closeParenIndex);

                lastSelectedProfileText = lastSelectedProfileText.replace(count, parseInt(count,10) + 1);

            }
            else {
                lastSelectedProfileText = lastSelectedProfileText + "(2)";
            }

            var securityViewScope = this;


//            securityViewScope.options.leftNavigation.scrollablelist('insert', 0);
            var newProfile = securityViewScope._selectedProfileModel.clone();
            $('.profile-list .selected a').text(lastSelectedProfileText);
         //   newProfile.attributes.internalName = $('.profile-list .selected').attr('data-scrollable-list');
            newProfile.attributes.displayName = lastSelectedProfileText;
            this.options.globalPermissionSet.models.push(newProfile);
            securityViewScope.options.leftNavigation.scrollablelist('insert', 0);
            $('.profile-name').val(lastSelectedProfileText);
            this.populateDuplicatePermissions();
            return this;

        },
        _addToCollection : function (newId) {
            var securityViewScope = this;
            securityViewScope.options.globalPermissionSet.add([
                {
                    newProfileId : newId,
                    assignedUsers: []
                }
            ]);
            securityViewScope.options.leftNavigation.scrollablelist('select', newId);
        },
        _openAssignUserDialog: function(){
            usersTab.openAssignUser(this); //call or apply. put methods on the prototype. look at grid for example
        },
        _editDetailsData : function ($event) {
            var securityViewScope = this;
            if (securityViewScope._selectedProfileModel) {
                var currentField = $($event.currentTarget).attr('name');
                var newProfileData = $($event.currentTarget).val();
                if (!_.isEmpty(newProfileData)) {
                    securityViewScope._selectedProfileModel.set(currentField, newProfileData);
                    if ('displayName' === currentField) {
                        securityViewScope.options.leftNavigation.scrollablelist('edit',
                            securityViewScope._selectedProfileModel.get((securityViewScope._selectedProfileModel.isNew()) ? 'newProfileId' : 'internalName'),
                            $($event.currentTarget).val());
                    }
                }
            }
        },
        _editDetails : function () {
            var securityViewScope = this;
            if (securityViewScope._selectedProfileModel) {
                securityViewScope.$el.find('.profile-details').hide();
                securityViewScope.$el.find('.profile-details-edit').show();
                if (securityViewScope._selectedProfileModel.isNew()) {
                    //TODO translate
                    securityViewScope.$el.find('.profile-details-edit input.profile-name').attr('placeholder',
                        "Enter Profile Name");
                    securityViewScope.$el.find('.profile-details-edit input.profile-name').val('');
                    securityViewScope.$el.find('.profile-details-edit .profile-description-text').val('');
                    securityViewScope.$el.find('.profile-details-edit input.profile-name').focus();

                } else {
                    securityViewScope.$el.find('.profile-details-edit input.profile-name').val(securityViewScope._selectedProfileModel.get('displayName'));
                    securityViewScope.$el.find('.profile-details-edit .profile-description-text').val(securityViewScope._selectedProfileModel.get('description'));
                }
            }
        },
        _handleDetails : function () {
            var securityViewScope = this;
            if (securityViewScope._selectedProfileModel) {
                securityViewScope.$el.find('.profile-details').show();
                securityViewScope.$el.find('.profile-details-edit').hide();
                securityViewScope.$el.find('.profile-details .profile-name').html(securityViewScope._selectedProfileModel.get('displayName'));
                securityViewScope.$el.find('.profile-details .profile-description-text').html(securityViewScope._selectedProfileModel.get('description'));
                securityViewScope.$el.find('.profile-default input[type=checkbox]').prop('checked',
                    securityViewScope._selectedProfileModel.get('default'));

            }


        },
        _selectProfile : function ($event, selection) {
            //the scope is set to the view when creating the scrollablelist
            var securityViewScope = this;

            lastSelectedProfileModel = securityViewScope._selectedProfileModel;
            if (securityViewScope.options.globalPermissionSet) {
                securityViewScope._selectedProfileModel = securityViewScope.options.globalPermissionSet.get(selection.id);
                if (!securityViewScope._selectedProfileModel) {
                    securityViewScope._selectedProfileModel = securityViewScope.options.globalPermissionSet.where({newProfileId : selection.id})[0];
                }
                if (!securityViewScope._selectedProfileModel) {
                    securityViewScope._selectedProfileModel = securityViewScope.options.globalPermissionSet.at(0);
                }
            }

            securityViewScope.options.$rightContent.tableofcheckboxes("setCheckboxes", []);
            securityViewScope.$el.find('.profile-default input[type=checkbox]').removeAttr('checked');

            if (securityViewScope._selectedProfileModel) {
                securityViewScope.$el.find('.no-profile-selected').hide();
                securityViewScope.$el.find('.profile-selected').show();
                securityViewScope.$el.find('.left-navigation button.delete-profile').prop('disabled', false);
                if (securityViewScope._selectedProfileModel.isNew()) {
                    securityViewScope._editDetails();
                } else {

                    securityViewScope._handleDetails();
                }
                if (securityViewScope.$el.find(privilegeTablesSelector + ':visible').length === 0) {
                    //TODO.eq(0) .eq(-1)  better than :first or :last
                    securityViewScope.$el.find(privilegeTablesSelector + ':first').parent().siblings('span.twistie-text').trigger('click');
                }
                securityViewScope._handleExpandCollapse();
                securityViewScope.trigger('change:selectedProfileModel', securityViewScope._selectedProfileModel);
            }
            return this;
        },
        populatePermissions : function () {
            //check the checkboxes in the table where the actions are set
            var securityViewScope = this;


            var originalPermissions = securityViewScope._selectedProfileModel.get('permissions');
            var originalUsers =  securityViewScope._selectedProfileModel.get('assignedUsers');
            if (!securityViewScope._selectedProfileModel.isNew()) {
                var backupModel = securityViewScope.options.backupGlobalPermissionSet.get(securityViewScope._selectedProfileModel.id);
                if (!backupModel.has('permissions')) {
                    var backupPermissions = $.extend(true, [], originalPermissions);
                    backupModel.set('permissions', backupPermissions);
                }
                if (!backupModel.has('assignedUsers')) {
                    var backupUsers = $.extend(true, [], originalUsers);
                    backupModel.set('assignedUsers', backupUsers);
                }
            }

            var tablePermissions = _.map(originalPermissions,
                function (value, key, list) {
                    return {row : value.resourceType, columns : value.actions};
                });
            securityViewScope.options.$rightContent.tableofcheckboxes("setCheckboxes", tablePermissions);
            usersTab.populateAssignedUsers(securityViewScope._selectedProfileModel.get('assignedUsers'));

        },
        populateDuplicatePermissions : function () {
            //check the checkboxes in the table where the actions are set

            currentScope = this;

            var originalPermissions = lastSelectedProfileModel.get('permissions');

            var tablePermissions = _.map(originalPermissions,
                function (value, key, list) {
                    return {row : value.resourceType, columns : value.actions};
                });
            currentScope.options.$rightContent.tableofcheckboxes("setCheckboxes", []);
            currentScope.options.$rightContent.tableofcheckboxes("setCheckboxes", tablePermissions);

            $('.privilege-list input:checked').trigger('change');


        },
        syncProfileElements : function (newProfilesToSync) {
            var securityViewScope = this;
            var newIDs = [];

            _.each(newProfilesToSync, function (newProfile) {
                var currentId = newProfile.currentID;
                var newId = newProfile.newID;
                securityViewScope.options.leftNavigation.scrollablelist('setItemId', currentId, newId);
                newIDs.push(newId);
            });
            securityViewScope.options.globalPermissionSet._reinitialize();
            securityViewScope._cloneCollection(securityViewScope.options.globalPermissionSet,
                securityViewScope.options.backupGlobalPermissionSet);

            securityViewScope.options.leftNavigation.scrollablelist('unsetNew', newIDs);
        },
        _clearSelection : function () {
            var securityViewScope = this;

            securityViewScope.$el.find('.no-profile-selected').show();
            securityViewScope.$el.find('.profile-selected').hide();
        },
        _cloneCollection : function (src, target) {
            var modelsToAdd = [];
            _.each(src.models, function (model) {
                var modelCopy = model.clone();
                modelsToAdd.push(modelCopy);
            });
            target.update(modelsToAdd);
        },
        cancelChanges : function () {
            var securityViewScope = this;
            securityViewScope._cloneCollection(securityViewScope.options.backupGlobalPermissionSet,
                securityViewScope.options.globalPermissionSet);

            securityViewScope.options.leftNavigation.scrollablelist('populate',
                securityViewScope._transformScrollableListData(securityViewScope));

            var selectionId = (securityViewScope._selectedProfileModel && securityViewScope._selectedProfileModel.id );
            securityViewScope._selectedProfileModel = null;
            securityViewScope._setDefaultProfile();
            if (selectionId) {
                securityViewScope.options.leftNavigation.scrollablelist('select', selectionId);
            } else {
                this._clearSelection();
            }

            securityViewScope.clean();
        },
        closeEditMode : function () {
            var securityViewScope = this;
            securityViewScope._handleDetails();
        },
        populateLdapUsers : function(ldapusers){
            var securityViewScope = this;
            ldapusers = _.reject(ldapusers, function(user){
                return !_.isEmpty(_.where(securityViewScope._selectedProfileModel.get('assignedUsers'),{userName:user.userName}));
            });

            _.each(ldapusers, function(user, index){
                user.key = index;
            });
            usersTab.populateLdapUsers(ldapusers);
        }
    });

    return securityManagementView;
});
