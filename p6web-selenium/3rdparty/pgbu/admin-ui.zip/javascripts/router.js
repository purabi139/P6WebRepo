define(['jquery', 'underscore', 'backbone', 'src/routers/adminController', 'src/views/nav/navBarView'], function ($, _, Backbone, AdminRouter, NavBarView) {
    'use strict';

    var albums = [
        {
            "key" : "0",
            "title" : "Show Your Bones",
            "artist" : "Yeah Yeah Yeahs",
            "track-count" : "12",
            "released" : "2006",
            "label" : "Dress Up",
            "genre" : "Indie Rock",
            "rating" : 5
        },
        {
            "key" : "1",
            "title" : "Remission",
            "artist" : "Mastodon",
            "track-count" : "11",
            "released" : "2002",
            "label" : "Relapse",
            "genre" : "Sludge Metal",
            "rating" : 5
        },
        {
            "key" : "2",
            "title" : "Leviathan",
            "artist" : "Mastodon",
            "track-count" : "11",
            "released" : "2004",
            "label" : "Relapse",
            "genre" : "Sludge Metal",
            "rating" : 5
        },
        {
            "key" : "3",
            "title" : "Metals",
            "artist" : "Feist",
            "track-count" : "12",
            "released" : "2011",
            "label" : "Arts & Crafts Productions",
            "genre" : "Indie Pop",
            "rating" : 5
        },
        {
            "key" : "4",
            "title" : "Never Worried About A Thing In My Life",
            "artist" : "Ursa Major",
            "track-count" : "12",
            "released" : "2012",
            "label" : "Sugartop Records",
            "genre" : "Doo Wop",
            "rating" : 5
        },
        {
            "key" : "5",
            "title" : "Aquemini",
            "artist" : "Outkast",
            "track-count" : "16",
            "released" : "1998",
            "label" : "LaFace",
            "genre" : "Hip hop",
            "rating" : 5
        }
    ];

    var Router = Backbone.Router.extend({
        routes : {
            'testInputs' : 'inputs',
            'testChart' : 'chart',
            'testGrid' : 'grid'
        },

        inputs : function () {
            console.log('inputs');
            var $content = $('.content');
            $content.empty();
            var $datePicker = $('<input></input>');
            $content.append($datePicker);
            $datePicker.datePicker({
                style : 'inside',
                fallback : false,
                locale : {
                    today : 'Today',
                    cancel : 'Cancel'
                }
            });
        },

        chart : function () {
            console.log('chart');
            require(['ocharts'], function (autoChart) {
                var $content = $('.content');
                $content.empty();
                var myChart = autoChart({
                    chartWidth : $content.width(),
                    chartHeight : 200
                })
                    .addAxis({
                        type : 'linear',
                        position : 'bottom',
                        domainPadding : 1
                    })
                    .addAxis({
                        type : 'linear',
                        position : 'left'
                    })
                    .addPlot({
                        type : 'bar',
                        data : [
                            {id : 0, x : 1, y : 1}
                        ]
                    })
                    .addLegend({
                        type : 'static',
                        title : 'Simple Legend',
                        entries : [
                            {
                                symbolType : 'square',
                                colorScheme : 1,
                                symbolDescription : 'Simple Entry'
                            }
                        ]
                    });
                $content.append(myChart.get$el());
                myChart.render();
            });
        },

        grid : function () {
            console.log('grid');
            require(['gridapi.grid/storeWrapper'], function (storeWrapper) {
                var $content = $('.content');
                $content.empty();
                var $grid = $content.grid({
                    editable : false,
                    layout : {
                        width : '650px',
                        height : '500px',
                        waffers : [
                            {
                                id : 'foo',
                                type : 'flex'
                            }
                        ]
                    },
                    rows : {
                        id : 'key'
                    },
                    columns : {
                        groups : [
                            {
                                id : 'bar',
                                type : 'flex',
                                columns : [
                                    {
                                        title : 'Title',
                                        dataIndex : 'title',
                                        sort : {
                                            type : 'string'
                                        }
                                    },
                                    {
                                        title : 'Artist',
                                        dataIndex : 'artist',
                                        sort : {
                                            type : 'string'
                                        }
                                    },
                                    {
                                        title : 'Track Count',
                                        dataIndex : 'track-count',
                                        sort : {
                                            type : 'string'
                                        }
                                    },
                                    {
                                        title : 'Released',
                                        dataIndex : 'released',
                                        sort : {
                                            type : 'string'
                                        }
                                    },
                                    {
                                        title : 'Label',
                                        dataIndex : 'label',
                                        sort : {
                                            type : 'string'
                                        }
                                    },
                                    {
                                        title : 'Genre',
                                        dataIndex : 'genre',
                                        sort : {
                                            type : 'string'
                                        }
                                    },
                                    {
                                        title : 'Rating',
                                        dataIndex : 'rating',
                                        sort : {
                                            type : 'string'
                                        }
                                    }
                                ]
                            }
                        ]
                    }
                });
                $grid.grid('setStore', albums, storeWrapper);
            });

        }
    });

    return {
        start : function () {

            $.ajax({
                url : 'rest/moduleAccess',
                async : false,
                datatype : 'json',
                success : function (userModulesResponse) {
                    $(document).ready(function () {
                        $(document.body).navbar({
                            userData : {
                                username : 'Steve Johnson',
                                userModules : userModulesResponse,
                                logoutMethod : function () {
                                    $.post('rest/logout');
                                    window.location = 'login.jsp';
                                }
                            }
                        });
                    });
//            new Router();
                    new AdminRouter();
                    Backbone.history.start();

                }});
        }
    };

});
