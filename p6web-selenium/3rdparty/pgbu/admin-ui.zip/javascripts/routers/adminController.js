define(['jquery', 'underscore', 'backbone'], function ($, _, Backbone) {
    'use strict';
    return Backbone.Router.extend({
        routes : {
            'setupAuthorization' : 'manageAuthorizationPolicy',
            'setupAuthorization/:tab' : 'manageAuthorizationPolicy',
            'applicationSettings': 'manageApplicationSettings',
            'systemSettings': 'manageSystemSettings'
        },
        manageAuthorizationPolicy : function (tab) {
            //TODO
//            var authorizationPolicyLaunched = $.Deferred();
//            require(['routers/admin/authzPolicyController'], function (pageLauncher) {
//                 $.when(pageLauncher.start(tab)).then(authorizationPolicyLaunched.resolve());
//            });
//            return authorizationPolicyLaunched;
        },
        manageApplicationSettings: function () {

            var pageLaunched = null, thisRouter = this;
            require(['src/routers/settingsController'], function (pageLauncher) {
                pageLaunched = pageLauncher(thisRouter, 'application');
            });
            return pageLaunched;
        },
        manageSystemSettings: function () {

        var pageLaunched = null, thisRouter = this;
        require(['src/routers/settingsController'], function (pageLauncher) {
            pageLaunched = pageLauncher(thisRouter, 'system');
        });
        return pageLaunched;
    }
    });
});
