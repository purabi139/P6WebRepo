define(['jquery', 'underscore', 'backbone',
    'src/enums/actionBar', 'src/models/admin/authzLdapModel', 'src/views/admin/settingsView'], function (
    $, _, Backbone, ActionBarEnums, Ldap, SettingsView) {
    'use strict';

    var launcher = function (router, settingType) {
        router.connectionTestMap = {};
        var settingMetadata = null,
            settingValues = null,
            $metadataRequest = $.getJSON('rest/settings/layout/' + settingType)
                .done(function (rawData) { settingMetadata = rawData; }),
            $valuesRequest = $.getJSON('rest/settings/values/' + settingType)
                .done(function (rawData) { settingValues= rawData; }),
            ldapUsers = new Ldap.UserCollection(),
            $ldapRequest = ldapUsers.fetch();
        router.activeView = new SettingsView({
            settingType: settingType,
            users: ldapUsers,
            usersRequest: $ldapRequest
        });
        var $ready = $.when($metadataRequest, $valuesRequest, $ldapRequest, router.activeView.ready())
            .done(function () {
                router.activeView.setMetadata(settingMetadata);
                router.activeView.setData(settingValues);
                //TODO: Don't know why it initializes with the action bar up.
                router.activeView.clean();
            })
            .fail(function () {
                _.flash('Settings failed.');
            });
        router.activeView.on(ActionBarEnums.Event.SAVE, function () {
            router.activeView._actionBar.$el.find(':input').prop('disabled', true);
            $.ajax({
                type: 'PUT',
                url: 'rest/settings/' + settingType,
                data: JSON.stringify(router.activeView.toJSON()),
                contentType : "application/json; charset=utf-8",
                dataType: 'json'
            })
                .done(function () {
                    $.getJSON('rest/settings/values/' + settingType)
                        .done(function (rawData) {
                            router.activeView.enableSave();
                            router.activeView.clean();
                            router.activeView.setData(rawData);
                        });
                })
                .fail(function ($xhr, failure, message) {
                    router.activeView.saveFailed($xhr, failure, message);
                    router.activeView.enableSave();
                    router.activeView.clean();
                });
        });
        router.activeView.on(ActionBarEnums.Event.CANCEL, function () {
            router.activeView.reset();
        });

        // return a $.Promise that aggregates ajax and view completion.
        return $ready;
    };
    return launcher;
});