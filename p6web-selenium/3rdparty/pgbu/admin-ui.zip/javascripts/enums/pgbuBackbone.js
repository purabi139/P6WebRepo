define(function () {
    "use strict";

    return {
        ViewEvent: {
            DATA_MODIFIED: "page:dataModified",
            LAYOUT_CHANGED: "page:layoutChanged",
            TAB_CHANGED: "page:tabChanged"
        }
    };
});
