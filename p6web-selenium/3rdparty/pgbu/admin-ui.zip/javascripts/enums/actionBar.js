define(function () {
    "use strict";

    return {
        Event: {
            CANCEL: "actionBar:cancel",
            SAVE: "actionBar:save",
            SAVE_AS: "actionBar:saveAs"
        },

        Type: {
            SAVE: 0,
            SAVE_AS: 1
        }
    };
});
