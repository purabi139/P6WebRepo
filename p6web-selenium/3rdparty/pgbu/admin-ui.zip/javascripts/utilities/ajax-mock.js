/**
 * Editing this file means that you understand the
 * risk of completely screwing up everyone's development environment.
 *
 * Most people should just use mockCallMapper.js.
 */
define(['jquery', 'underscore', 'src/models/mocks/mockCallMapper'], function ($, _) {
    'use strict';

    console.log('\nWarning: ajax mocking enabled.');
    var enabled = true;
    var realAjax = $.ajax;

    var hijacks = [
        {
            url : /.*/,
            call : function (ajax, option) {
                return ajax.call(this, option);
            }
        }
    ];

    var mockIt = function (realUrl, mockUrl, amd) {
        _.ajaxMock(realUrl, amd, mockUrl, function (ajax, options, file) {
            options.url = mockUrl;
            options.type = 'GET';
            return ajax.call(this, options);
        });
    };

    var processMapper = function () {
        var mockCalls = window.mock_call_mapper;
        if (mockCalls) {
            for (var i = 0; i < mockCalls.length; ++i) {
                if (mockCalls[i].useMock) {
                    mockIt(mockCalls[i].url, mockCalls[i].mockUrl, (mockCalls[i].powerup === 'amd') ? true : false);
                }
            }
        }
    };

    // Default hijack: Just pass it along to the normal jQuery ajax method.
    $.ajax = function (options) {
        if (enabled) {
            for (var i = 0; i < hijacks.length; ++i) {
                if (_.isFunction(options.url)) {
                    options.url = options.url();
                }
                var matches = options.url.match(hijacks[i].url);
                if (matches) {
                    matches.splice(0, 1, realAjax, options);

                    if (hijacks[i].amd) {
                        var dfd = $.Deferred();
                        amdMock(hijacks[i].file, options.type, options.success, options.data, dfd);
                        return dfd.promise();
                    } else {
                        return hijacks[i].call.apply(this, matches);
                    }
                }
            }
            console.log("ajax: dropped request to '%o'.", options.url);
        } else {
            return realAjax.apply(this, arguments);
        }
    };

    var amdMock = function (file, type, successCallback, data, dfd) {
        require([file], function (powerup) {
            dfd.resolve();
            successCallback.call(this, powerup[type.toLowerCase()].call(this, data));
        });
    };


    _.mixin({
        ajaxMock : function (urlPattern, amd, mockUrl, func) {
            _.ajaxUnmock(urlPattern);
            hijacks.unshift({
                url : urlPattern,
                amd : amd,
                file : mockUrl,
                call : func

            });
        },

        ajaxUnmock : function (urlPattern) {
            for (var i = 0; i < hijacks.length; ++i) {
                if (hijacks[i].url.toString() === urlPattern.toString()) {
                    hijacks.splice(i--, 1);
                }
            }
        },

        ajaxMockEnabled : function (state) {
            if (_.isUndefined(state)) {
                enabled = state;
            }
            return enabled;
        }
    });

    processMapper();

});
