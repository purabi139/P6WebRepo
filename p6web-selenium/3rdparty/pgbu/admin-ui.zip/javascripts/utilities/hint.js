define([
    'jquery', 'underscore'
], function ($, _) {
    'use strict';

    function lastChar (str) {
        return str.charAt(str.length - 1);
    }

    var hint = {
        /**
         * Return an array of localized hints regarding bounds.
         * All bounds keys are optional.  The following keys are recognized:
         *      'numberMin', 'numberMax', 'lengthMin', and 'lengthMax'
         * The locale object must include the following keys:
         *      'betweenValue', 'atLeastValue',  'atMostValue',
         *      'betweenLength', 'exactLength', 'atLeastLength', 'atMostLength',
         *      'exactLength1', 'atLeastLength1', 'atMostLength1'
         * The locale values must be mustache templates, with variable names from the set of bounds keys.
         * See localeStrings: *.label.autoHint.
         * @param {Object} bounds
         * @param {Object} locale
         * @return {Array}
         */
        makeHints: function (bounds, locale) {
            if (!bounds) {
                return [];
            }
            var hintList = [],
                inBounds = function (key) {
                    return bounds.hasOwnProperty(key);
                },
                addHint = function (hintName) {
                    hintList.push(_.template(locale[hintName], bounds));
                };
            if (inBounds('numberMin') && inBounds('numberMax')) {
                addHint('betweenValue');
            } else if (inBounds('numberMin')) {
                addHint('atLeastValue');
            } else if (inBounds('numberMax')) {
                addHint('atMostValue');
            }
            if ('1' === bounds.lengthMin && '1' === bounds.lengthMax) {
                addHint('exactLength1');
            } else if (inBounds('lengthMin') && inBounds('lengthMax') && bounds.lengthMin === bounds.lengthMax) {
                addHint('exactLength');
            } else if (inBounds('lengthMin') && inBounds('lengthMax')) {
                addHint('betweenLength');
            } else if ('1' === bounds.lengthMin) {
                addHint('atLeastLength1');
            } else if (inBounds('lengthMin')) {
                addHint('atLeastLength');
            } else if ('1' === bounds.lengthMax) {
                addHint('atMostLength1');
            } else if (inBounds('lengthMax')) {
                addHint('atMostLength');
            }
            if ('1' === bounds.precision) {
                addHint('exactPrecision');
            } else if (inBounds('precision')) {
                addHint('maxPrecision');
            }
            if (inBounds('defaultUnit')) {
                addHint('defaultUnit');
            }
            if (inBounds('permissibleUnits')) {
                addHint('permissibleUnits');
            }
            return hintList;
        },
        /**
         * If statement is non-empty, make sure it ends with a period.
         * @param {String} statement
         * @return {String}
         */
        punctuate: function (statement) {
            var betterStatement = statement.trim();
            return (!betterStatement || '.' === lastChar(betterStatement)) ? betterStatement : (betterStatement + '.');
        },
        nonEmptyStrings: function (strList) {
            return _.filter(strList, function (s) { return s.trim().length;});
        }
    };
    return hint;
});