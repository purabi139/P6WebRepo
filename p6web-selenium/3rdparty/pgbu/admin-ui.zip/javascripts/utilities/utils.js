define([
    'jquery', 'underscore', 'backbone', 'i18n!src/nls/localeStrings',  'src/utilities/ajax-mock'
], function ($, _, Backbone, locale) {
    'use strict';

    var $globalFlash = $('.global-flash');

    var FlashView = Backbone.View.extend({
        tagName: 'div',
        className: 'alert alert-block fade in out',

        initialize: function (options) {
            this.options = options;
        },

        _getDefaultHeading: function () {
            switch (this.options.type) {
                case 'error':
                    return locale.label.error;
                case 'success':
                    return locale.label.success;
                case 'info':
                    return locale.label.info;
                default:
                    return locale.label.warning;
            }
        },

        render: function () {
            this.options.closeable = (this.options.closeable != null ? this.options.closeable : true);
            if (this.options.type) {
                this.$el.addClass('alert-' + this.options.type);
            }
            if (this.options.closeable) {
                this.$el.append($(this.make('a', { 'class': 'close', 'data-dismiss': 'alert' }, '&times;')).css('top', '12px'));
            }
            this.options.heading = this.options.heading || this._getDefaultHeading();
            this.$el.append(this.make('h4', { 'class': 'alert-heading' }, this.options.heading));
            if (this.options.text) {
                this.$el.append(this.make('span', {}, this.options.text));
            }
            this.$el.alert();
            return this;
        }
    });

    _.mixin({

        /** Translate a string
         * @param {String} str The string to merge in params.
         * @param {Object} The remaining arguments that replace %0..%N in
         * the string.
         * @return {String} The merged string.
         */
        formatString: function (str /*, arg1, arg2, ...*/) {
            var localeArgs = _.toArray(arguments);

            return str.replace(/%([0-9]+)/g, function (match, g1) {
                var value = localeArgs[parseInt(g1, 10) + 1];

                return value != null ? value : "";
            });
        },

        /** Extract markup from htm template and inject values.
         *  @param {Object} $markup jQuery object of the template content.
         *  @param {String} clazzName Class name of the element to select.
         *  @param {Object} map Map containing values to inject into markup.
         *  @return {String} Html containing injected values.
         */
        pluckMarkup: function ($markup, clazzName, map) {
            var template = $markup.filter(clazzName).html();
            if (map == null) {
                return template;
            }
            return _.template(template, map);
        },

        getLayout: function () {
            var width = $(window).width();
            if (width < 768) {
                return 'mobile';
            } else if (width <= 980) {
                return 'tablet-portrait';
            } else if (width <= 1024) {
                return 'tablet-landscape';
            } else if (width <= 1400) {
                return 'desktop';
            } else {
                return 'desktop-wide';
            }
        },

        formatUnit: function (unit) {
            return unit;
        },

        formatCost: function (cost, precision) {

            if (cost == null) {
                cost = 0;
            } else if (typeof cost !== 'number') {
                cost = Number(cost);
            }

            if (precision == null){
                precision = 2;
            }
            var costStr = cost.toFixed(precision).toString();

            // Matches any digit that is followed by three digits but not more
            // and replaces said digit with itself and a comma after it.
            var formattedCost = costStr.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, '$1,');
            return '$' + formattedCost;
        },

        formatDuration: function (duration) {
            if (duration == null) {
                duration = 0;
            } else if (typeof duration !== 'number') {
                duration = Number(duration);
            }
            return duration.toFixed(0) + 'h';
        },

        formatTime: function (date) {
            // Do not alter to allow for a custom format.  That is the point of using this method!
            if (date != null && date !== '') {
                return Date.create(date).format('{HH}:{mm}');
            } else {
                return date;
            }
        },

        formatDate: function (date, format) {
            format = format || '{Mon} {d}, {yyyy}';
            if (date != null && date !== '') {
                return Date.create(date).format(format);
            } else {
                return date;
            }
        },

        datePickerFormat: function () {
            return 'M d, yy';
        },

        unitsAgo: function (date) {
            var dateObject = Date.create(date);
            var daysAgo = dateObject.daysAgo();
            var hoursAgo = dateObject.hoursAgo();
            var minutesAgo = dateObject.minutesAgo();
            var secondsAgo = dateObject.secondsAgo();
            if (daysAgo > 7) {
                return _.formatDate(date);
            } else if (daysAgo > 0) {
                if (daysAgo > 1) {
                    return _.formatString(locale.text.time_ago, daysAgo, locale.label.days.toLowerCase());
                } else {
                    return _.formatString(locale.text.time_ago, daysAgo, locale.label.day.toLowerCase());
                }
            } else if (hoursAgo > 0) {
                if (hoursAgo > 1) {
                    return _.formatString(locale.text.time_ago, hoursAgo, locale.label.hours.toLowerCase());
                } else {
                    return _.formatString(locale.text.time_ago, hoursAgo, locale.label.hour.toLowerCase());
                }
            } else if (minutesAgo > 0) {
                if (minutesAgo > 1) {
                    return _.formatString(locale.text.time_ago, minutesAgo, locale.label.minutes.toLowerCase());
                } else {
                    return _.formatString(locale.text.time_ago, minutesAgo, locale.label.minute.toLowerCase());
                }
            } else if (secondsAgo > 0) {
                if (secondsAgo > 1) {
                    return _.formatString(locale.text.time_ago, secondsAgo, locale.label.seconds.toLowerCase());
                } else {
                    return _.formatString(locale.text.time_ago, secondsAgo, locale.label.second.toLowerCase());
                }
            } else {
                return _.formatDate(date);
            }
        },

        formatPercent: function (percent) {
            if (percent == null) {
                percent = 0;
            } else if (typeof percent !== 'number') {
                percent = Number(percent);
            }
            return percent.toFixed(0) + '%';
        },

        delay: (function () {
            var timer = 0;
            return function (callback, ms) {
                clearTimeout(timer);
                timer = setTimeout(callback, ms);
            };
        } ()),

        escapeRegex: function (string) {
            return string.replace(new RegExp('[-[\\]{}()*+?.,\\^$|#\\s]', 'g'), "\\$&");
        },

        parseInt: function (string, radix) {
            if (radix == null) {
                radix = 10;
            }
            return parseInt(string, radix);
        },

        /**
         * intCast: whatever type value is, cast it into an integer.
         * @param value
         * @return {Number}
         */
        intCast: function (value) {
            if (!_.isNumber(value)) {
                value = _.parseInt(value, 10);
            }
            return Math.floor(value);
        },

        /**
         * Builds a flash message with the given options and appends it to the DOM above the page content.
         * Only use this for important, global messages.
         * @param {String}  options.text      The text of the flash message.
         * @param {String}  options.heading   (Optional) The heading of the flash message.
         * @param {Boolean} options.closeable (Optional) Whether the flash message is closeable. Defaults to true.
         * @param {String}  options.type      (Optional) One of "error", "success", or "info".
         */
        flash: function (options) {
            if (options == null) {
                options = {};
            } else if (_.isString(options)) {
                options = { text: options };
            }

            $globalFlash.empty();
            $globalFlash.append(new FlashView(options).render().$el).slideDown(300);
            if (options.closeable !== false) {
                $globalFlash.delay(5000)
                    .slideUp(500, function () {
                        $(this).children().remove();
                    });
            }

            Backbone.history.on('route', function () {
                $globalFlash.empty();
            });
        },
        //
        //
        /**
         * Build a jQuery multiple selector from either a single string, or an array of strings,
         * and a template containing a '{{key}}'.
         *
         * Example: _.joinMultiSelector(['a', 'b', 'c'], '[name="{{key}}"]') ==>
         *          'name=["a"],name=["b"],name=["c"]'
         * @param {Array<String> or String} keys  Key strings to plug into the template's {{key}} field.
         * @param {String} template               Template string for use with _.template with a {{key}} field.
         * @return {String}                       jQuery sizzle multi-selector specifying template for each key.
         */
        joinMultiSelector: function (keys, template) {
            keys = _.isString(keys) ? [keys] : keys;
            var keyToSelector = function (key) {
                return _.template(template, { key: key });
            };
            return _.map(keys, keyToSelector).join(',');
        },
        /**
         * Given an Array of trees, return a flat array of all the tree nodes.
         * @param {Array} treeNodeList // array of tree node objects
         * @param {String} childKey // property name of tree node object for array of child tree nodes
         * @return {Array}
         */
        flattenTrees: function (treeNodeList, childKey) {
            treeNodeList = treeNodeList ? _.filter(treeNodeList, _.isObject) : [];
            if (!treeNodeList.length) {
                return [];
            }
            return _.union(treeNodeList, _.flattenTrees(_.chain(treeNodeList)
                .pluck(childKey)
                .filter(_.isArray)
                .flatten()
                .filter(_.isObject)
                .value(), childKey));
        }
    });
    //this isn't a mixin, but it's a really important utility that we always need.
    (function () {
        window.console = window.console || {};
        var functions = ['log', 'debug', 'info', 'warn', 'error', 'assert', 'dir', 'dirxml',
            'group', 'groupEnd', 'time', 'timeEnd', 'count', 'trace', 'profile', 'profileEnd'];

        _.each(functions, function (fn) {
            if (!_.isFunction(window.console[fn])) {
                window.console[fn] = $.noop;
            }
        });
    } ());
});
