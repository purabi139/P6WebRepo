define([
    'jquery', 'underscore'],
    function ($, _) {
        'use strict';
        var Filter = {
            minimumLettersForWord:2,
            searchData:{},

            applyOnMatchingKeys:function (map, searchTerm, callback) {
                searchTerm = searchTerm.toLowerCase();
                for (var str in map) {
                    if (str.toLowerCase().indexOf(searchTerm) !== -1) {
                        callback(str, Filter.searchData[str]);
                    }
                }
            },

            findWord:function (searchTerm) {
                var results = [];

                Filter.applyOnMatchingKeys(Filter.searchData, searchTerm,
                    function (key, value) {
                        results.push(value);
                    });

                return results;
            },

            findSetting:function (words) {

              //  var matchedSettings = _.intersection.apply(this, _.map(words, Filter.findWord));

                //Filter.undoPreviousSearch();

                Filter.hideUnmatchedSettings(words);

                Filter.navigateToFirstVisibleCategory();
            },

            undoPreviousSearch:function () {
                $('.setting-wrapper').children().removeClass('hidden');
                $('.leftcategories > ul.nav > li').removeClass('hidden');
                $('.setting-group').removeClass('hidden');
                $('.filterbox').removeClass('filterbox-no-results');
                $('.filterbox').removeClass('filterbox-with-results');
                $('.no-results-message').remove();
                $('.setting-wrapper').removeClass('active');
                $($('.leftcategories > ul.nav > li.active > a').attr('href')).addClass('active');
            },

            hideUnmatchedSettings : function(matchedSettings) {
                var $allMatchedSettings = $(_.compact(_.map(matchedSettings,
                    function (internalName) {
                        if (internalName) {
                            return '[name="' + internalName + '"]';
                        }
                    })).join(','));
                var selectorsToHide = [];
                if ($allMatchedSettings.length !== 0) {
                    var matchedCategorySelector = _.map($allMatchedSettings.parents('.setting-category'),
                        function (categoryElement) {
                            var categoryName = $(categoryElement).closest('.setting-wrapper').attr('id');
                            return '[href="#' + categoryName + '"]';
                        });
                    selectorsToHide.push($('.leftcategories > ul.nav > li > a:not(' + matchedCategorySelector + ')').closest('li'));
                    selectorsToHide.push($('.setting-group').not($allMatchedSettings.parents('.setting-group')));
                    selectorsToHide.push($('.setting-wrapper').not($allMatchedSettings.parents('.setting-wrapper')).children());
                 /*   $('.leftcategories > ul.nav > li > a:not(' + matchedCategorySelector + ')').closest('li').addClass('hidden');
                    $('.setting-group').not($allMatchedSettings.parents('.setting-group')).addClass('hidden');
                    $('.setting-wrapper').not($allMatchedSettings.parents('.setting-wrapper')).children().addClass('hidden');
                    */
                }
                return selectorsToHide;
/*
                if (matchedSettings.length === 0 || $allMatchedSettings.length === 0) {
                    Filter.indicateNoResults();
                } else {
                    Filter.indicateFoundResults();
                }
                */
            },

            indicateFoundResults:function () {
                Filter.navigateToFirstVisibleCategory();
            },

            indicateNoResults:function () {
                $('.setting-wrapper').children().addClass('hidden');
                $('.leftcategories > ul.nav > li').addClass('hidden');
                $('.setting-group').addClass('hidden');


                $('.setting-generated-form').append('<div class="no-results-message">No results found</div>');
            },

            navigateToFirstVisibleCategory:function () {
                var $navItems = $('.leftcategories > ul.nav > li');
                if (0 === $navItems.filter(':visible').filter('.active').length) {
                    $navItems.removeClass('active');
                    var $newlySelectedNavItem = $navItems.filter(':visible').first();
                    $newlySelectedNavItem.addClass('active');
                    $('.setting-generated-form > .setting-wrapper').removeClass('active');
                    $($newlySelectedNavItem.children('a').attr('href')).addClass('active');
                }
            },

            registerFilterKeywords:function (keywords, internalName) {
                Filter.searchData[keywords] = internalName;
            }
        };

        return Filter;
    });
