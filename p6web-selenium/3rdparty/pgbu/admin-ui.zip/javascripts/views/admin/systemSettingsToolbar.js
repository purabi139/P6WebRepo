define([
    'jquery', 'underscore', 'backbone', 'i18n!src/nls/localeStrings'
], function ($, _, Backbone, locale) {
    'use strict';

    var dropTemplate = _.template('<li><a href="<%=link%>"><%=text%>></a></li>');

    return Backbone.View.extend({

        events : {
            'click .btn.save' : '_saves',
            'click .btn.revert' : '_revert'
        },

        remove : function () {
            this.$el.empty();
        },

        render : function () {
            if (this.$el.children().length !== 0) {
                return;
            }
            var that = this;

            var testSetting = $(this.make('div', {
                'class' : 'btn-group'
            })).append($(this.make('a', {
                'class' : 'btn btn-primary'
            })).append('<span>' + locale.label.test_connection + '</span>'));

            var defaultSetting = $(this.make('div', {
                'class' : 'btn-group'
            })).append($(this.make('a', {
                'class' : 'btn btn-primary revert'
            })).append('<span>' + locale.label.default_ + '</span>'));


            var saveSetting = $(this.make('div', {
                'class' : 'btn-group'
            })).append($(this.make('a', {
                'class' : 'btn btn-primary save'
            })).append('<span>' + locale.label.save + '</span>'));

            $(this.make('div', {'class' : 'btn-toolbar'}))
                .append(testSetting)
                .append(defaultSetting)
                .append(saveSetting)
                .appendTo(this.$el);
        },

        _saves : function () {

            this.trigger('save');

        },
        _revert : function () {

            this.trigger('revert_system_settings');

        }
    });

});
