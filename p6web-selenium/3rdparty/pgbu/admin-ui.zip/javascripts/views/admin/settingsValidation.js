define([
    'jquery', 'underscore', 'i18n!src/nls/localeStrings'
], function ($, _, Locale) {
    'use strict';

    /**
     * Collection of settings specific utility functions for setting up validation.
     * Validation setup does not depend on DOM design.
     * @type {Object}
     */
    var settingsValidation = {
        /**
         * Given nested metadata in json format and a map, mapping settingKeys to jQuery wrapped DOM elements,
         * set validation data on all the DOM elements.
         * @param {Array} jsonNestedList
         * @param {jQuery} $elementMap
         * @param {Object} options
         */
        setupValidation: function (jsonNestedList, $elementMap, options) {
            var jsonList = _.flattenTrees(jsonNestedList, 'layoutChildren');
            jsonList = settingsValidation._updateIntegerBounds(jsonList, options);
            jsonList = settingsValidation._updateNumberBounds(jsonList);
            jsonList = settingsValidation._updateDatetimeBounds(jsonList);

            var boundsList = settingsValidation._extractBounds(jsonList);
            boundsList = settingsValidation._updateDistinctGroups(boundsList);
            settingsValidation._setValidationData(boundsList, $elementMap);
        },
        _setValidationData: function (boundsList, $elementMap) {
            _.each(boundsList, function (bounds) {
                $elementMap[bounds.internalName].data('validation', bounds);
            });
            return boundsList;
        },
        _updateIntegerBounds: function (jsonList, options) {
            var updateIntegerBounds = function (jsonObject) {
                    jsonObject.bounds = _.extend(jsonObject.bounds || {},
                    {
                        pattern : options.INTEGER || {
                            expression: /^\d+$/,
                            message: Locale.validationMsg.integer
                        }
                    });
                };
            _.chain(jsonList)
                .filter(function (jsonObject) {
                    return 'INTEGER' === jsonObject.type;
                })
                .each(updateIntegerBounds);
            return jsonList;
        },
        _updateNumberBounds: function (jsonList) {
            var updateNumberBounds = function (jsonObject) {
                    // Manage bounds whether creating or replacing
                    if (jsonObject.bounds && jsonObject.bounds.precision){
                        jsonObject.bounds.pattern = {
                            expression: new RegExp(
                                "^[+\\-]?\\.?\\d+\\.?\\d{0," + jsonObject.bounds.precision + "}$"),
                            message: Locale.validationMsg.precision
                        };
                    }
                };
            _.chain(jsonList)
                .filter(function (jsonObject) {
                    return 'NUMBER' === jsonObject.type;
                })
                .each(updateNumberBounds);
            return jsonList;
        },
        _updateDatetimeBounds: function (jsonList) {
            var regex = /^((0?\d)|(1[012]))\/([012]?\d|30|31)\/\d{1,4} ((0?\d)|(1[12])):[0-5]\d?\s?[aApP]\.?[mM]\.?$/;
            var updateDatetimeBounds = function (jsonObject) {
                jsonObject.bounds = _.extend(jsonObject.bounds || {}, {
                    pattern :  {
                        expression: regex,
                        message: Locale.validationMsg.date
                    }
                });
            };
            _.chain(jsonList)
                .filter(function (jsonObject) {
                    return 'DATE' === jsonObject.type;
                })
                .each(updateDatetimeBounds);
            return jsonList;
        },
        /**
         * Given an array of json setting objects,
         * return the bounds of those that have them, augmented with their internalName.
         * @param {Array} jsonList
         * @return {Array} // [ { ... bounds properties ..., internalName: {String} } ]
         * @private
         */
        _extractBounds: function (jsonList) {
            var updateAllBounds = function (jsonObject) {
                    if (_.isString(jsonObject.bounds.pattern)){
                        jsonObject.bounds.pattern = new RegExp(jsonObject.bounds.pattern);
                    }
                    return _.extend({ internalName: jsonObject.internalName }, jsonObject.bounds);
                };
            return _.chain(jsonList)
                .filter(function (jsonObject) {
                    return jsonObject.hasOwnProperty('bounds');
                })
                .map(updateAllBounds)
                .value();
        },
        /**
         * Given an array of bounds objects augmented with internalName,
         * return a copy, augmented with bounds entries for every internalName in every distinctGroup.
         * @param {Array} boundsList
         * @return {Array}
         * @private
         */
        _updateDistinctGroups: function (boundsList) {
            var boundsMap = _.groupBy(boundsList, 'internalName');
            // _.groupBy sticks all the values in arrays, but they're 1-to-1, so map directly to values.
            _.each(_.keys(boundsMap), function (key) { boundsMap[key] = boundsMap[key][0]; });
            // Get all the distinctGroups, and make sure each one includes its own internalName.
            var distinctGroups = _.chain(boundsList)
                    // Only operate on bounds that include distinctGroup
                    .filter(function (bounds) {
                        return bounds.hasOwnProperty('distinctGroup');
                    })
                    // Make sure the distinctGroup includes its own internalName & toss bounds
                    .map(function (bounds) {
                        return _.chain(bounds.distinctGroup)
                            .union(bounds.internalName)
                            .uniq()
                            .value();
                    })
                    .value(),
                distributeDistinctGroup = function (keyList) {
                    _.each(keyList, function (key) {
                        boundsMap[key] = _.extend(boundsMap[key] || {}, {
                            internalName: key,
                            distinctGroup: keyList
                        });
                    });
                };
            _.each(distinctGroups, distributeDistinctGroup);
            return _.values(boundsMap);
        }
    };
    return settingsValidation;
});