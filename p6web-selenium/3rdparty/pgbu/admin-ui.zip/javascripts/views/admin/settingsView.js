define([
    'jquery', 'underscore', 'backbone', 'i18n!src/nls/localeStrings',
    'src/views/common/pageView',
    'text!src/templates/admin/settingLayout.htm',
    'validity',
    'src/views/admin/settingsValidation',
    'src/views/widgets/governor',
    'src/views/widgets/formGenerator',
    'src/views/admin/filter',
    'src/views/widgets/filter/filter',
    'src/views/widgets/scrollablelist' // Attaches to jQuery, never used directly, don't include in function args.
], function ($, _, Backbone, Locale, PageView, settingLayout, validity, settingsValidation, Governor, generateForm, Filter) {
    'use strict';

    // Temporary workaround for a recently emerged bug in jquery validity: ReferenceError: Big is not defined
    window.Big = null;

    var $settingsMarkup = $(settingLayout);
    var settingsMarkup = _.pluckMarkup($settingsMarkup, '.setting-markup', null);

    var $validityDependant = {
        'INTEGER': {
            expression: $.validity.patterns.integer,
            message: Locale.validationMsg.integer
        },
        validationInitialization: function () {
            $.validity.setup({ outputMode: 'label', elementSupport: $.validity.settings.elementSupport + ', input[type="number"], input[type="number"]' });
        },
        validateOne$Element: function ($input, $parentElement) {
            if ($input.data('validation')) {
                var bounds = $input.data('validation');
                if ($.isNumeric(bounds.lengthMin)) {
                    if (0 < parseInt(bounds.lengthMin, 10)) {
                        $input.require(Locale.validationMsg.required);
                    }
                    $input.minLength(bounds.lengthMin);
                }
                if ($.isNumeric(bounds.lengthMax)) {
                    $input.maxLength(bounds.lengthMax,
                        _.formatString(Locale.validationMsg.tooLong, bounds.lengthMax));
                }
                if ($.isNumeric(bounds.numberMin)) {
                    $input.greaterThanOrEqualTo(bounds.numberMin,
                        _.formatString(Locale.validationMsg.greaterThanOrEqualTo, bounds.numberMin));
                }
                if ($.isNumeric(bounds.numberMax)) {
                    $input.lessThanOrEqualTo(bounds.numberMax,
                        _.formatString(Locale.validationMsg.lessThanOrEqualTo, bounds.numberMax));
                }
                // distinctGroup and pattern might take a while, resulting in a noticeable delay in
                // appearance of .error styling, so add error styling sooner.
                var errorCount = $.validity.report.errors;
                if (errorCount > 0){
                    $input.addClass('error');
                }
                if (bounds.distinctGroup) {
                    var $distinctGroup = $parentElement.find(_.map(bounds.distinctGroup, function (internalName) {
                            return '[name="' + internalName + '"]';
                        }).join(','));
                    var groupLabels = $distinctGroup.map(function () {
                            return 'label.setting-label[for="' + $(this).prop('id') + '"]';
                        }).toArray();
                    var lastLabel = groupLabels.pop();
                    $distinctGroup.distinct(_.formatString(Locale.validationMsg.distinct, [
                        groupLabels.join(', '),
                        lastLabel
                    ].join(Locale.validationMsg._and_)));
                    // Highlight the elements that are not distinct.
                    if (errorCount < $.validity.report.errors) {
                        $distinctGroup
                            .filter(function () {
                                return $(this).val() === $input.val();
                            })
                            .addClass('error');
                    }
                }
                if (bounds.pattern) {
                    var validationPattern = _.isRegExp(bounds.pattern) ?
                        {
                            expression: bounds.pattern,
                            message: Locale.validationMsg.match
                        } :
                        bounds.pattern;
                    $input.match(validationPattern.expression, validationPattern.message);
                }
                if ($.validity.report.errors > 0){
                    $input.addClass('error');
                }
            }
        },
        validate$Elements: function ($elementsToValidate, $parentElement) {
            $.validity.start();
            $elementsToValidate.each(function() {
                $validityDependant.validateOne$Element($(this), $parentElement);
            });
            var result = $.validity.end();
            return result.valid;
        }
    };

    return PageView.extend({
        events: {
            'change .setting-generated-form :input': 'handleChange',
            'click .disabled a': 'handleDisabledLinks',
            'submit form': 'handleFormSubmit'
         },

        filter : function(words) {
            Filter.findSetting(words);
        },

        getContentMarkup: function () {
            return _.template(settingsMarkup, {
                revertToDefault: Locale.label.default_
            });
        },
        initializePage: function () {
            $validityDependant.validationInitialization();
            this.mostRecentKeyValueMap = {};
            this._data = null;
            this.$generatedFormEl = null;
            this.$settingNavigationEl = null;
            this.ready();
        },
        renderChildren: function () {
            this.setHeading(Locale.label.admin[this.options.settingType], '');
            var $navColumn = this.$el.find('.setting-navigation');
            //TODO: allow a few pixels of scrolling before sticking just below top of screen
            $navColumn.affix({ offset: { top: -100 } });
            this.$settingNavigationEl = $navColumn.find('ul.nav');
            this.$generatedFormEl = $('.setting-generated-form');
            this.$el.find('.setting-toolchest').filtersearch({
                alternateText:'Filter Settings',
                placeholder:'Filter Settings',
                searchCallback: this.filter,
                resetSearch: Filter.undoPreviousSearch,
                getSelectorsToHide: Filter.hideUnmatchedSettings,
                indicateNoResults:Filter.indicateNoResults,
                indicateFoundResults:Filter.indicateFoundResults
            });
            this._adjustToWindowHeight();
            var debouncedWindowHeightAdjustment = _.debounce($.proxy(this._adjustToWindowHeight, this), 300);
            $(window).resize(debouncedWindowHeightAdjustment);
            this._rendered.resolve(this);
        },
        _adjustToWindowHeight: function () {
            this._stretchView();
            this._shrinkNav();
        },
        _stretchView: function () {
            $('.pgbu-page-container').css('min-height', this.getWindowOptimalContentHeight() + 'px');
        },
        _shrinkNav: function () {
            var $nav = this.$('.leftcategories ul.nav'),
                heightDifference = $nav.offset().top - $('.pgbu-page-container').offset().top;
            $nav.css('max-height', this.getWindowOptimalContentHeight() - heightDifference);
        },
        ready: function () {
            this._rendered = this._rendered || $.Deferred();
            return this._rendered.promise();
        },
        remove: function () {
            this._data = null;
            this.$generatedFormEl.empty().removeClass('setting-wrapper');
            this.$settingNavigationEl.empty();
        },
        //TODO: Compartmentalize enough to move over into settingsValidation.js.
        _validateObject : function ($elementsToValidate) {
            return $validityDependant.validate$Elements($elementsToValidate, this.$generatedFormEl);
        },
        doValidationBookkeeping: function ($event) {
            var $target = $($event.target);
            this._removeValidationFeedbackFromSetting($target);
            if (!this._validateObject($target)) {
                this._addValidationFeedbackToCategory($target);
            }
            this.toggleSaveEnable();
            return this;
        },
        handleChange: function ($event) {
            this.doValidationBookkeeping($event);
            $($event.target).addClass('setting-changed');
            this.dirty();
            return this;
        },
        _addValidationFeedbackToCategory: function ($el) {
            var $categoryWrapper = $el.closest('.setting-category').parent('.setting-wrapper');
            this.$settingNavigationEl
                // Use the setting category id to find the right <li> by its child <a>'s href
                .find('>li>a[href="#' + $categoryWrapper.prop('id') + '"]')
                // Then go back up to the <li> to add the error class.
                .parent()
                .addClass('error');
            return this;
        },
        _removeValidationFeedbackFromDistinctGroup: function ($el) {
            var bounds = $el.data('validation'),
                distinctGroup = bounds && bounds.distinctGroup || null;
            if (distinctGroup) {
                var $distinctElements = this.$generatedFormEl
                        .find(_.joinMultiSelector(distinctGroup, '[name="<%=key%>"]')),
                    distinctSettingIds = $distinctElements.map(function () {
                        return $(this).prop('id');
                    }),
                    errorSelector = _.joinMultiSelector(distinctSettingIds.get(), 'label.error[for="<%=key%>"]');
                $distinctElements.removeClass('error');
                this.$generatedFormEl
                    .find(errorSelector)
                    .remove();
            }
            return this;
        },
        _removeValidationFeedbackFromSetting: function ($el) {
            if (!$el) {
                return this;
            }
            $el.removeClass('error')
                .closest('.setting-wrapper')
                .find(_.template('label.error[for="<%=id%>"]', { id: $el.prop('id') }))
                .remove();
            this._removeValidationFeedbackFromDistinctGroup($el);
            var $navigationEl = this.$settingNavigationEl;
            this.$generatedFormEl.find('.setting-category').parent('.tab-pane')
                .each(function () {
                    if (0 === $(this).find('label.error').length) {
                        $navigationEl.find('>li>a[href="#' + $(this).prop('id') + '"]')
                            .parent()
                            .removeClass('error');
                    }
                });
            return this;
        },
        removeAllValidationFeedback: function () {
            this.$settingNavigationEl.children('li.error').removeClass('error');
            this.$generatedFormEl.find('label.error').remove();
            this.$generatedFormEl.find(':input.error').removeClass('error');
            return this;
        },
        handleDisabledLinks: function () {
            return false;
        },
        handleFormSubmit: function () {
            return false;
        },
        toggleSaveEnable: function () {
            if (0 === this.$settingNavigationEl.children('li.error').length) {
                this.enableSave();
            } else {
                this._actionBar.disableSave();
            }
            return this;
        },
        toJSON: function () {
            var $changedSettings = this.$el.find('.setting-changed').not(':disabled'),
                $checkChanged = $changedSettings.filter('input:checkbox'),
                $radioUnchecked = $changedSettings.filter('input:radio:not(:checked)'),
                $regularChanged = $changedSettings.not($checkChanged).not($radioUnchecked);
            var result = _.union($regularChanged
                        .map(function () {
                            return { internalName: $(this).prop('name'), value: $(this).val() };
                        })
                        .get(),
                    $checkChanged.filter(':checked')
                        .map(function () {
                            return { internalName: $(this).prop('name'), value: 'true' };
                        })
                        .get(),
                    $checkChanged.filter(':not(:checked)')
                        .map(function () {
                            return { internalName: $(this).prop('name'), value: 'false' };
                        })
                        .get()
                );
            $changedSettings.removeClass('setting-changed');
            return result;
        },
        reset: function () {
            this.removeAllValidationFeedback();
            this.clean();
            this.setData(this.mostRecentKeyValueMap);
            return this;
        },
        saveFailed: function ($xhr, failure, message) {
            message = _.template('Save failed with status code <%=code%>, <%=text%>.', {
                code: $xhr.status.toString(),
                text: message
            });
            _.flash(message);
            console.log(message);
            return this;
        },
        // enableSave belongs in PageView alongside disableSave.
        enableSave: function () {
            this._actionBar.$el.find(':input').prop('disabled', false);
            return this;
        },
        registerFilterKeywords : function (settingsLayoutList, parentKeywords) {
            var that = this;
            parentKeywords = (parentKeywords || '') + ' ';
            _.each(settingsLayoutList, function(settingLayout) {
                var keywords = parentKeywords + settingLayout.label;
                if('GROUP' !== settingLayout.type) {
                    if('CHOICE' === settingLayout.type || 'DROPDOWN' === settingLayout.type) {
                        _.each(settingLayout.layoutChildren, function(childOptionLayout) {
                            keywords += childOptionLayout.label;
                        });
                    }
                    Filter.registerFilterKeywords(keywords, settingLayout.internalName);
                }
                that.registerFilterKeywords(settingLayout.layoutChildren, keywords);
            });
        },
        setMetadata: function (responseData) {
            this._data = responseData;
            if (_.isArray(responseData)) {
                this._data = {
                    type: 'GROUP',
                    internalName: 'setting-root',
                    layoutChildren: responseData
                };
            }
            var options = {
                json: this._data,
                $parentElement: this.$generatedFormEl,
                userCollection: this.options.users,
                usersRequest: this.options.usersRequest
            };
            var jsonDomList = generateForm(options),
                $allFieldsets = this.$generatedFormEl.find('fieldset');
            $allFieldsets.parent('.setting-wrapper').addClass('bordered-fieldset');
            $allFieldsets.children('.setting-children').addClass('fieldset-content');
            this.registerFilterKeywords(responseData);
            this.$el.find('.setting-toolchest').filtersearch({
                alternateText:'Filter Settings',
                placeholder:'Filter Settings',
                searchData:Filter.searchData,
                searchCallback: this.filter,
                resetSearch: Filter.undoPreviousSearch,
                getSelectorsToHide: Filter.hideUnmatchedSettings,
                indicateNoResults:Filter.indicateNoResults,
                indicateFoundResults:Filter.indicateFoundResults
            });

            this._buildNav();
            this._setupGovernors(this.$generatedFormEl, jsonDomList);
            var keyedSettingsList = this.$generatedFormEl.find(':input[name]').get(),
                keyedSettingsMap = _.chain(keyedSettingsList)
                    .map(function (el) { return [$(el).attr('name'), $(el)]; })
                    .object()
                    .value();
            settingsValidation.setupValidation(responseData, keyedSettingsMap, $validityDependant.INTEGER);
            return this;
        },
        _setupGovernors: function ($container, jsonDomList) {
            // Transform [{ json: {...governor}, $el: $el },...] to [{ governor: {}, $el: $el},...],
            // keeping only the pairs for which governor is defined.
            var governorDomList = _.chain(jsonDomList)
                .filter(function (jsonDomPair) { return jsonDomPair.json.hasOwnProperty('governor'); })
                .map(function (jsonDomPair) { return { governor: jsonDomPair.json.governor, $el: jsonDomPair.$el }; })
                .value();
            governorDomList = _.union(governorDomList, $container.find('input.setting-url+div.setting-wrapper>button')
                .map(function () {
                    return {
                        governor: {
                            internalName: $(this).parent().prev().attr('name'),
                            action: 'DISABLE',
                            values: ['']
                        },
                        $el: $(this)
                    };
                })
                .toArray());
            Governor.setup(governorDomList, $container);
            return this;
        },
        setData: function (settingKeyValueMap) {
            this.mostRecentKeyValueMap = settingKeyValueMap;
            var $settingDom = this.$generatedFormEl.find('.setting'),
                $checkDom = $settingDom.filter('input:checkbox,input:radio'),
                $regularDom = $settingDom.not($checkDom);
            _.each(settingKeyValueMap, function (value, key) {
                $checkDom.filter('[name="' + key + '"]').val( [ value ] );
                $regularDom.filter('[name="' + key + '"]').val( value );
            });
            $settingDom.filter('.setting-changed').removeClass('.setting-changed');
            Governor.activateGovernors(this.$generatedFormEl);
            $settingDom.filter('.setting-url>input[type="text"]').trigger('change'); // Url settings reset test results
            return this;
        },
        _buildNav: function () {
            var navTabMarkup = '<li><a data-toggle="tab"></a></li>',
                $navigationEl = this.$settingNavigationEl,
                $formCategoryElements = this.$generatedFormEl.find('.setting-category'),
                $categoryContainer = $formCategoryElements.closest('.setting-children');
            $categoryContainer.addClass('tab-content')
                .children('.setting-wrapper')
                    .addClass('tab-pane')
                    .each(function () {
                        var $categoryWrapperEl = $(this),
                            id = _.uniqueId('setting-category-');
                        // Set id's on category wrappers for the sake of bootstrap tabs.
                        $categoryWrapperEl.prop('id', id);
                        // Add tab <li> to the navigation element
                        var $li = $(navTabMarkup).appendTo($navigationEl);
                        $li.children('a')
                            .attr('href', '#' + id)
                            .text($categoryWrapperEl.find('>.setting-category>h3.setting-label').text().trim());
                    });
            $navigationEl.children('li').first().addClass('active');
            $formCategoryElements.first().parent('.tab-pane').addClass('active');
            return this;
        }});
});