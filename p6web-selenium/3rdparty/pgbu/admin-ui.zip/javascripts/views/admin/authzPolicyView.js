define([
    'jquery', 'underscore', 'backbone', 'i18n!src/nls/localeStrings', 'pgbu-backbone',
    'src/views/common/pageView',
    'text!src/templates/admin/authzPolicyLayout.htm','src/views/widgets/forms/formCheckbox','src/views/widgets/scrollablelist.js'
], function ($, _, Backbone, Locale, PgbuBackbone,
            PageView,
            AuthzPolicyLayout,FormCheckbox
    ) {
    'use strict';
    var $authzPolicyMarkup = $(AuthzPolicyLayout);
    var authzPolicyMarkup = _.pluckMarkup($authzPolicyMarkup, '.adm-authz-policy', null);
    var authzPrivRowTemplate = _.template(_.pluckMarkup($authzPolicyMarkup, '.adm-authz-priv-row', null));
    var authzProfileMemberRowTemplate = _.template(_.pluckMarkup($authzPolicyMarkup, '.adm-authz-member-row', null));
    var authzProfileItemTemplate = _.template(_.pluckMarkup($authzPolicyMarkup, '.adm-authz-profile-item', null));
    var authzProfileNewCheckboxLiTemplate = _.template(_.pluckMarkup($authzPolicyMarkup, '.adm-authz-new-cb-li', null));

    var authzPolicyView = PageView.extend({

        options: {
            tab: '0'
        },
        authzCRUD: ['all', 'view', 'update', 'create', 'delete'],


        events: {
            //TODO: move event handlers into separate functions with descriptive names.
            'click #roles ul.nav-tabs a[disabled="disabled"]': function ($event) {
                $event.preventDefault();
            },
            'click #roles #role-groups button.assign-group': function ($event) {
                var that = this;
                $event.preventDefault();
                that._addNewProfileGroupRow();
            },
            'change #roles #role-privileges td>input[type="checkbox"]': function ($event) {
                var that = this;
                var $el = $($event.currentTarget);
                var isChecked = $el.attr('checked');
                var $td = $el.parent();
                var action = $td.data('authzAction');
                var resourceTypeStr = $td.parent().data('resourceType');
                that._selectedProfileModel.isAuthorizedFor(resourceTypeStr, action, isChecked);
            },
            'shown #roles a[data-toggle="tab"]': function () {
                this.populateRolesMinorTab();
            },
            'click li.role-module-access': function($event){

                var $activeTab = this._getActiveTab();
                _.each($activeTab,function(tab){
                    $(tab).removeClass('active');
                        $(tab).find('child').hide();
                    }
                );
                $($event.currentTarget).addClass('active');
                var minorTabContent = this.$el.find('#roles div.role-module-access');
                minorTabContent.addClass('active');

                this.populateRoleModules();
            },
            'change #roles div.role-module-access input[type=checkbox]': function($event){
                var selectedProfiileModules = this._selectedProfileModel.get('modules');
                if ($event.srcElement.checked){
                    selectedProfiileModules.push($event.srcElement.name);
                }else{
                    var moduleIdx = selectedProfiileModules.indexOf($event.srcElement.name);
                    var updatedModuleAccess = selectedProfiileModules.splice(moduleIdx,1);
                }
                this.dirty();
            }
        },

        initializePage: function () {
            this._resourceTypeList = [];
            this._ldapGroupList = [];
            this._ldapUserList = [];
            this._profileCollection = [];
            this._tab = this.options.hasOwnProperty('tab') ? this.options.tab : 'roles';
            this._minorTab = this.options.hasOwnProperty('minorTab') ? this.options.minorTab : 'role-privileges';
            this._selectedProfileModel = null;
            this._$selectedProfileEl = null;
            return this;
        },

        // This is where to do DOM injection that does not rely on asynchronous data
        renderChildren: function () {
            switch (this._tab) {
                case 'roles':
                    switch (this._minorTab) {
                        case 'role-privileges':
                            this.$('#role-privileges .please-add').show();
                            break;
                        case 'role-moduleAccess':
                            this.$('div.module-assignments').show();
                            this.populateRoleModules();
                            break;
                        case 'role-users':
                            this.$('#role-users .please-add').show();
                            break;
                        case 'role-groups':
                            this.$('#role-groups .please-add').show();
                            break;
                        default:
                            throw (new Error(_.formatString('Minor tab %0 not implemented.', this._minorTab)));
                    }
                    break;
                case 'users-groups':
                    break;
                case 'p6users':
                    break;
                default:
                    throw (new Error(_.formatString('Tab %0 not implemented.', this._tab)));
            }
            return this;
        },

        setResourceTypes: function (resourceTypeList) {
            this._resourceTypeList = resourceTypeList;
        },

        setLdapGroups: function (ldapGroupList) {
            this._ldapGroupList = ldapGroupList;
        },

        setLdapUsers: function (ldapUserList) {
            this._ldapUserList = ldapUserList;
        },

        setProfileCollection: function (profileCollection) {
            this._profileCollection = profileCollection;
            if (this._tab === 'roles') {
                this.populateProfileList();
                switch (this._minorTab) {
                    case 'role-privileges':
                        this.$('#role-privileges .please-add').hide();
                        this.$('#role-privileges .privilege-assignment').hide();
                        this.$('#role-privileges .please-select').show();
                        break;
                    case 'role-users':
                        this.$('#role-users .please-add').hide();
                        this.$('#role-users .user-assignments').hide();
                        this.$('#role-users .please-select').show();
                        break;
                    case 'role-groups':
                        this.$('#role-groups .please-add').hide();
                        this.$('#role-groups .group-assignments').hide();
                        this.$('#role-groups .please-select').show();
                        break;
                    default:
                        throw (new Error(_.formatString('Minor tab %0 not implemented.', this._minorTab)));
                }
            }
        },

        selectProfile: function ($event, selection) {
            var profileNameStr = selection.id;
            var viewContext = this;
            if (this.options.profileCollection){
                viewContext._selectedProfileModel = viewContext.options.profileCollection.find(function(profileModel) {
                    return profileModel.get('internalName') === profileNameStr;
                });
            }
            viewContext.trigger('change:selectedProfileModel',profileNameStr);
            this.populateRolesMinorTab();
            return this;
        },
        selectedProfileHasModules: function(){
            var that = this;
             if (that._selectedProfileModel){
                return _.isArray(that._selectedProfileModel.get('modules'));
            }
            return false;
        },
        setProfileInfo: function(profileInfo){
            this._selectedProfileModel.set('modules',profileInfo.modules);
            this.populateRolesMinorTab();
        },
        getContentMarkup: function () {
            // Navigating to this page from the global navigation panel initially displays with no selection.
            // Only enable the Users and Groups minor tab when a profile is selected.
            var enableMinorTab = true; //this._selectedProfileModel ? ' data-toggle="tab"' : 'disabled="disabled"';

            return _.template(authzPolicyMarkup, _.extend({
                groupsTab: enableMinorTab,
                usersTab: enableMinorTab,
                message:''
            }, Locale.label, Locale.label.admin));

        },

        getPageHeaderSettings: function () {
            return {
                heading: 'User Security and Administration' //TODO: use locale
                //TODO: what options do we need?
            };
        },

        // Set data to populate the page
        setData: function (options) {
            var that = this;
            if (!that.options.profileCollection) {
                return this;
            }
            that.populateProfileList().populateRolesMinorTab();
            //TODO: use deferred to aggregate minor tab population.
            return this;
        },

        resizeChildren: function () {
            this.renderChildren();
            return this;
        },
        _getActiveTab:function(){
            var that = this;
            var $activeTabPane = that.$el.find('#roles .active');
            return $activeTabPane;
        },
        populateRolesMinorTab: function () {
            var that = this;
            var $activeTabPane = $(that._getActiveTab()[1]);
            switch ($activeTabPane.attr('id')) {
                case 'role-privileges':
                    that.populateResourceTypes();
                    break;
                case 'role-groups':
                    var selectedModel = that._selectedProfileModel;
                    that.trigger('change:selectedProfileModelGroup', selectedModel);
                    break;
                case 'role-users':
                    that.populateRoleUsers();
                    break;
                case 'role-module-access':
                    that.populateRoleModules();
                    break;
                default:
                    console.warn('Invalid tab pane "' + $activeTabPane.attr('id') + '" selected.');
                    break;
            }
            return that;
        },
        populateRoleModules : function () {
            var that = this;
            var $modulePanel = that.$el.find('div.module-assignments');
            //$modulePanel.removeClass("hidden");
            $modulePanel.empty();

            _.each(that.options.availableModules, function (module) {
                    var moduleCheckbox = new FormCheckbox({ el : $modulePanel, identifier : module.internalName,
                        label : module.displayName, checked : false
                    }).render();
                    $modulePanel.append(moduleCheckbox);
                }
            );
            if (that.selectedProfileHasModules()){
                var assignedModules = that._selectedProfileModel.get('modules');
                var checkedSelector = assignedModules.map(function(module){
                    return 'input[type=checkbox].' + module;
                }).join(',');


                var assignedCheckboxes = $modulePanel.find(checkedSelector);
                assignedCheckboxes.attr({
                    disabled: false,
                    checked: true
                });
            }
        },
        populateRoleGroups: function () {
            var that = this;
            var selectedModel = that._selectedProfileModel;
            var roleMembers = selectedModel.get('roleMembers');
            var sortedGroupMembers = _.chain(roleMembers)
                .filter(function(member) { return 'group' === member.type.toLowerCase(); })
                .sortBy(function (member) { return (member.isNew ? '_' : '') + member.name.toLowerCase(); })
                .map(function(member) { return _.defaults({ name: _.escape(member.name) }, member); })
                .value();
            var $ul = that.$el.find('#role-groups .assignment-selection-panel ul').empty();
            _.reduce(sortedGroupMembers, function($memo, member) {
                return $memo.append($(authzProfileMemberRowTemplate({
                    memberItemStr: member.name,
                    memberItemInput: member.name.toLowerCase().split(' ').join('-')
                })).toggleClass('unsaved', member.isNew || false));
            }, $ul);
            return that;
        },
        populateRoleUsers: function () {
            console.warn('Role major tab, Users minor tab, is not implemented');
            return this;
        },

        populateResourceTypes: function () {
            var that = this;
            var resourceTypes = that.options.resourceTypeList;
            var $tbody = that.$el.find('#role-privileges table > tbody').empty();

            _.each(resourceTypes, function (resourceTypeName) {
                var $row = $(authzPrivRowTemplate({ resourceTypeStr: Locale.label.opss_resource_types[resourceTypeName] }));
                $row.data('resourceType', resourceTypeName);
                var $tds = $row.children();
                for (var actionIndex = 0; actionIndex < that.authzCRUD.length; ++actionIndex) {
                    var actionStr = that.authzCRUD[actionIndex];
                    var $td = $tds.eq(actionIndex + 1);
                    $td.data('authzAction', actionStr);
                    var $checkbox = $td.find('input[type="checkbox"]');
                    if (that._selectedProfileModel && that._selectedProfileModel.get('internalName')) {
                        $checkbox.removeAttr('disabled');
                    } else {
                        $checkbox.attr('disabled', 'disabled');
                    }
                    if (that._selectedProfileModel && that._selectedProfileModel.isAuthorizedFor(resourceTypeName, actionStr)) {
                        $checkbox.attr('checked', 'checked');
                    } else {
                        $checkbox.removeAttr('checked');
                    }
                }
                $tbody.append($row);
            });
            return that;
        },

        populateProfileList: function () {
            var that = this;
            that._$selectedProfileEl = null;


            var profilesInfo = _.map(that.options.profileCollection.models, function(profile){return {id:profile.get('internalName'),display:profile.get('displayName')};});
            var selectionProfileHandler = $.proxy(that.selectProfile,that);
            that.$el.find('#roles .scrollable.profile-list').scrollablelist({
                content: profilesInfo,
                selected: selectionProfileHandler
            });

            return that;
        },

        state: function(property, value) {
            var returnValue = null;
            if (_.isString(property)) {
                returnValue = this.options[property];
                if (!_.isUndefined(value)) {
                    this.options[property] = value;
                }
            } else {
                returnValue = _.extend({}, this._state);
                _.extend(this.options, property);
            }
            return returnValue;
        },

        _addNewProfileGroupRow: function () {
            this._addNewTypeaheadListItem(this.$el.find('#role-groups .assignment-selection-panel ul'), authzProfileNewCheckboxLiTemplate, this.options.groupList); //TODO filter for already assigned
        },

        _addNewTypeaheadListItem: function ($container, liTemplate, source) {
            var that = this;
            var $li = $(liTemplate(_.extend({}, Locale.label, Locale.label.admin)));
            $container.prepend($li);
            var $typeaheadEl = $li.find('[data-provide="typeahead"]');
            var changeEventData = {that: this, $container: $container, $inputEl: $typeaheadEl};
            $typeaheadEl
                .typeahead({ source: source, items: 5 })
                .focus()
                .on('change', null, changeEventData, function($eventObject) {
                    var changeData = $eventObject.data;
                    that.trigger('change:selectedProfileEl.groups', that._selectedProfileModel, changeData.$inputEl.val());
                    that.populateRoleGroups();
                });
            return $li;
        }/*,

        _selectProfileDisplay: function ($el) {
            var that = this;
            if (that._$selectedProfileEl) {
                that._$selectedProfileEl.removeClass('selected');
                that._selectedProfileModel.set('privileges', [], { silent: true });
            }
            that._$selectedProfileEl = $el;
            $el.toggleClass('selected', true);
        }*/
    });

    return authzPolicyView;
});
