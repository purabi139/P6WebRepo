define([
    "jquery", "underscore", "backbone",
    "src/views/widgets/pageHeader",
    "src/views/widgets/actionBar",
    "src/views/widgets/actionPanel",
    "text!src/templates/common/pageLayout.htm", "src/enums/pgbuBackbone"
], function ($, _, Backbone, PageHeader, ActionBar, ActionPanel, Markup, PgbuBackboneEnums) {
    "use strict";

    return Backbone.View.extend({
        /* Abstract methods */

        // Override to provide page-specific action bar settings.
        getActionBarSettings: $.noop,

        // Override to provide page-specific action panel settings.
        getActionPanelSettings: $.noop,

        // Override to provide a page-specific markup to be appended to div.content container.
        getContentMarkup: $.noop,

        // Override to allow collecting data, entered into UI by the user.
        getData: $.noop,

        // Override to provide page-specific header settings.
        getPageHeaderSettings: $.noop,

        // Override to allow page-wide initializations at the beginning of the life-cycle of the page.
        initializePage: $.noop,

        // Override to allow child components to clean up after themselves.
        removePage: $.noop,

        // Override to allow child components to add themselves to the page. Page markup should be fully available at this point.
        renderChildren: $.noop,

        // Override to allow child components to resize themselves on the page. Page markup should be fully available at this point.
        resizeChildren: $.noop,

        // Override to provide the page with data, retrieved from external sources.
        // This method takes an optional parameter, which (if supplied) is an object to hold all implementation-specific options and configurations.
        setData: $.noop,

        /* End of Abstract methods */

        clean: function () {
            this._actionBar.hide();
        },

        dirty: function () {
            this._actionBar.show();
        },

        initialize: function () {
            var self = this;

            this._prepare();

            this._layout = _.getLayout();
            this.initializePage();
            this.render();
            $(window).on("resize", function (event) {
                self._resize();
            });
        },

        remove: function () {
            this.undelegateEvents();

            this._pageHeader.removeWidget();
            this._actionPanel.remove();
            this._actionBar.remove();

            this.removePage();

            $(window).off("resize");

            this.$("div.page-header").empty().removeData();
            this.$("div.toolbar").empty().removeData();
            this.$("div.actions-overlay").empty().removeData();
            this.$("div.content").empty().removeData();
        },

        render: function () {
            this._createHeading();
            this._createActionBar();
            this._createActionPanel();
            this._createContentContainer();
            this._memoDecorativeHeight();
            this._createContentMarkup();

            this.renderChildren();

            return this;
        },

        setHeading: function (heading, subHeading) {
            this._pageHeader.setHeading(heading, subHeading);
        },

        /**
         * Return the pixel height of content above .content and content below .content.
         * @return {Integer}
         */
        getDecorativeHeight: function () {
            return this._decorativeHeight;
        },

        getWindowOptimalContentHeight: function () {
            var windowHeight = $(window).height();
            return windowHeight - this.getDecorativeHeight();
        },

        _ensureElement: function () {
            if (this.el == null) {
                this.setElement($(".page-content"), false);
            } else {
                Backbone.View.prototype._ensureElement.apply(this, arguments);
            }
        },

        _prepare: function () {
            var activeView = this.$el.data("activeView");

            if (activeView != null && _.isFunction(activeView.remove)) {
                activeView.remove();
            }
            this.$el.data("activeView", this);
        },

        _createActionBar: function () {
            var self = this;

            this._actionBar = new ActionBar({
                actionBar: this.getActionBarSettings() || {},
                el: this.$(".actions-overlay").get(0)
            });
            this._actionBar.on("all", function (eventName) {
                self.trigger(eventName);
            });
            this._actionBar.render();
        },


        _createActionPanel: function () {
            var self = this;

            this._actionPanel = new ActionPanel({
                actions: this.getActionPanelSettings(),
                el: this.$(".content").get(0)
            });
            this._actionPanel.on("all", function (eventName) {
                self.trigger(eventName);
            });
            this._actionPanel.render();
        },

        /**
         * Memo height of decoration above and below .pgbu-page-container content area
         * for use with getDecorativeHeight().
         * Must be called after decorative DOM has been added but before content markup.
         * @private
         */
        _memoDecorativeHeight: function () {
            var $containerEl = $(".pgbu-page-container");
            // Decorative height calculation is based on a priori knowledge that there is nothing
            // below $containerEl but the .actions-overlay.
            // Temporarily appending a visible element to body and getting its offset() might make it generic.
            this._decorativeHeight = $containerEl.offset().top +
                ($containerEl.innerHeight() - $containerEl.height()) + // padding
                this.$(".actions-overlay").innerHeight(); // include padding
        },

        _createContentContainer: function () {
            this.$(".content").append($(Markup));
        },

        _createContentMarkup: function () {
            this.$(".pgbu-page-container").html(this.getContentMarkup(this._layout));
        },

        _createHeading: function () {
            this._pageHeader = new PageHeader(this.getPageHeaderSettings() || {});
            this._pageHeader.render(this.$(".page-header").get(0));
        },

        _resize: function () {
            var newLayout = _.getLayout();

            if (newLayout !== this._layout) {
                this._layout = newLayout;
                this.resizeChildren();
                this.trigger(PgbuBackboneEnums.ViewEvent.LAYOUT_CHANGED);
            }
        },
        disableSave: function(disableExplanation){
            this._actionBar.disableSave();
            if (disableExplanation){
                this._actionBar.$el.find(':input.save').attr('title',disableExplanation);
            }
        },
        enableSave: function () {
            this._actionBar.$el.find(':input.save').prop('disabled', false);
            this._actionBar.$el.find(':input.save').removeAttr('title');
            return this;
        }
    });
});
