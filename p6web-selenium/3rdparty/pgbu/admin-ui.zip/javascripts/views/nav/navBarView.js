define([
    'require', 'jquery', 'underscore', 'backbone', 'i18n!src/nls/localeStrings',
    'src/views/nav/menuView', 'text!src/templates/nav/navMenu.htm', 'text!src/templates/nav/navBarView.htm'
], function (require, $, _, Backbone, locale, menuView, Markup, NavHTML) {
    'use strict';
    var $navHTML = $(NavHTML),
        linkMarkup = _.pluckMarkup($navHTML, '.tmp-nav-link', null),
        linkMarkupLabel = _.pluckMarkup($navHTML, '.tmp-nav-link-label', null),
        headerMarkup = _.pluckMarkup($navHTML, '.tmp-nav-header', null),
        contentMarkup = _.pluckMarkup($navHTML, '.tmp-nav-content', null),
        submenuMarkup = _.pluckMarkup($navHTML, '.tmp-nav-submenu', null),
        dropdownMarkup = _.pluckMarkup($navHTML, '.tmp-nav-dropdown', null),
        linkTemplate = _.template(linkMarkup),
        linkTemplateLabel = _.template(linkMarkupLabel),
        headerLinkTemplate = _.template(headerMarkup),
        tabContentRow = _.template(contentMarkup),

        subMenus = _.template(submenuMarkup),
        dropdownTemplate = _.template(dropdownMarkup);

    $.widget('ui.navbar', {
        options : {
            userData : {}
        },

        _create : function () {
            this._createNavbar();
        },

        _createNavbar : function () {
            var that = this;
            $('body > div.navbar').append(Markup);

            menuView({modules:this.options.userData.userModules}); //generate menu

            //var searchController = new SearchController({ el : this.element.find('.search') });
            this.$rightList = $('ul.pull-right');

            var userSettings = dropdownTemplate({link : '#', label : _.formatString(this.options.userData.username) });
            this.$rightList.append(userSettings);
            $('.logout').on('click',this.options.userData.logoutMethod);

            var $conversationButton = $('<li class="conversation"></li>');
            this.$rightList.append($conversationButton);

            var $notificationButton = $('<li class="notification"><div class="unread"><span></span></div></li>');
            this.$rightList.append($notificationButton);
//            var controller = new NotificationController($notificationButton);
//            $notificationButton.on('click', function () {
//                controller.popup();
//            });

            $(document.body).on('keypress', function (evt) {
                if ($(evt.target).is('input,textarea,form *')) {
                    return;
                }
                if (!evt.ctrlKey || evt.altKey || evt.shiftKey) {
                    return;
                }
                if (evt.keyCode === 13) {
                    $('.navbar .menu-toggle').click();
                } else if (evt.keyCode === 17) {
                    $('.navbar .nav-search').focus();
                }
            });
        }
    });
});