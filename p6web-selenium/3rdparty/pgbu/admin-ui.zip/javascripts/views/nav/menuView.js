define(['jquery', 'underscore', 'd3', 'jquery-easing', 'base64', 'text!src/models/mocks/navLinksMock.json'], function ($, _, d3, $easing, base64, json) {
    'use strict';
    try{
        json = JSON.parse(json); //unable to get require to load the json the "right" way so I fell back to parsing as text
    }catch(e){
        console.log('Error: unparsable navLinksMock.json file, fix json syntax.');
    }
    return function menuView(options){
        var is = function is(){ //is defined checking function
            return void 0 !== arguments[0];
        },
        deepFilter = function deepFilter(e, filter){ //like Array.filter except looks at array and all sub arrays to apply filter deeply
            if(!Array.isArray(arguments[2])){ //initialize arguments[2] used for holding deepFilter result
                return deepFilter(e, filter instanceof Function ? filter : function(){return true;}, []); //no filter function results in just returning initial array
            }
            if(Array.isArray(e)){ //if current element is array then recurse through it
                for(var n in e) {
                    if(e.hasOwnProperty(n)){ //ignore undefined array elements
                        deepFilter(e[n], filter, arguments[2]);
                    }
                }
            }
            else if(is(e) && filter(e)){ //Check element if it matches filter
                arguments[2].push(e); //append element to result array
            }
            return arguments[2]; //arguments[2] is the array holding the deepFilter result
        },
        isMatch = function isMatch(a){ //check if href hash matches to element; empty hash is returned as empty string by location.hash
            return a.href === (location.hash === '' || location.hash === '#home' ? '#' : location.hash); //this will need to be updated to accommodate more complex routes
        },
        color = d3.scale.category20(0); //Initialize d3's color generator

        if (!json){ //check to make sure json loaded or return gracefully
            console.log('Error: menu json object was not loaded');
            return;
        }
        var flatTree = (function flatTree(object){ //function to flatten proper tree into semi-flat array tree object
            var array = [], //flatTree associative array that gets returned
                push = function push(node, array, depth, parent){ //recursive function to build flatTree
                    node.depth = depth;
                    if(parent){
                        node.parent = parent;
                    }
                    array.push(node);
                    if(node.children){ //if node has children
                        var child;
                        if(!node.group){ //if group option false
                            for(child in node.children){
                                push(node.children[child], array, depth + 1, node);
                            }
                        }else{

                                //preserve sub array in flatTree
                                var group = []; //holding array to be pushed as sub array in main array
                                group.parent = array[array.length - 1];
                                for(child in node.children){
                                    if(node.children.hasOwnProperty(child)){
                                        push(node.children[child], group, depth + 1, node);
                                    }
                                }
                                array.push(group);

                        }
                    }

                };
            push(object, array, Number()); //seed recursion root's parent is undefined signifying that it's root
            array.deepFilter = function flatTreeDeepFilter(filter){ //give deepFilter method to flatTree
                return deepFilter(array, filter);
            };
            array.currentNode = (function currentNode(){ //store current node to array object
                var found = array.deepFilter(isMatch)[0]; //search for current hash location in flatTree
                if(found && found.parent && found.parent.group){ //if found is a group then return group's parent
                    found = found.parent;
                }
                return found ? found : array[0]; //if nothing found then return root element
            }());
            return array; //return the built flatTree
            }(json)),
            history = (function history(){ //associative array to manage recently visited links with localStorage
                if(!localStorage){
                    console.log('Error: browser does not support localStorage');
                    return {menuIsOpen:false, indexes:[], update:Function, clear:Function};
                }
                if(!localStorage.history){
                    localStorage.history = JSON.stringify({menuIsOpen:true, indexes:[]});
                }
                var json = JSON.parse(localStorage.history),
                    storage = json.indexes.map(function storage(i){
                        if(typeof i === 'string'){
                            return {name:i.replace('#','').replace('/',' '), href:i};
                        }
                        return Array.isArray(i) ? flatTree[i[0]][i[1]] : flatTree[i];
                    }).filter(function filter(d){ //remove nodes that were not found in the tree due to updated links/invalid history
                        return is(d);
                    });
                storage.menuIsOpen = json.menuIsOpen;
                storage.indexMap = function indexMap(){ //function to return array of flatTree element indexes which represent location of element in flatTree
                    return this.map(function map(d){
                        if(d.parent && d.parent.group){ //nodes that are in a group get stored as [group element index, sub element index]
                            var groupArrayIndex = flatTree.indexOf(d.parent) + 1; //group is always next sibling of group's parent
                            return [groupArrayIndex, flatTree[groupArrayIndex].indexOf(d)]; //return element as represented as part of group
                        }
                        if(flatTree.indexOf(d) === -1){
                            return d.href;
                        }
                        return flatTree.indexOf(d); //return elements that do not belong to group
                    }).filter(function filter(d){
                        return is(d);
                    });
                };
                storage.store = function store(){ //function to store flatTree element indexes to localStorage
                    try{
                        localStorage.history = JSON.stringify({menuIsOpen:storage.menuIsOpen, indexes:this.indexMap()}); //store stringify indexMap to localStorage
                        return true;
                    }catch(e){ //catch localStorage errors
                        console.log('error: ' + e.message);
                    }
                };
                storage.clear = function clear(){ //function to clear localStorage
                    localStorage.removeItem('history');
                };
                storage.update = function update(){ //function to update storage
                    var currentNode = flatTree.currentNode.group ? flatTree.deepFilter(isMatch)[0] : flatTree.currentNode; //if flatTree's currentNode is a group then find the specific child element else return flatTree's currentNode
                    if(!currentNode || !isMatch(currentNode)){
                        currentNode = {name:location.hash.replace('#','').replace('/',' '), href:location.hash, parent:Object};
                    }
                    var match = storage.filter(function filter(a){
                        return a.href === currentNode.href;
                    })[0];
                    if(match){
                        storage.splice(storage.indexOf(match), 1);
                    }
                    if(currentNode.parent){ //add currentNode to top of list unless root
                        storage.unshift(currentNode);
                    }
                    if(storage.length > 4){ //keep only top 4 recent
                        storage.pop();
                    }
                    storage.store(); //call storage to update localStorage
                    return this;
                };
                $(window).bind('hashchange', function hashchange(){ //update history on hashchange
                    drawVisited();
                    drawPlus();
                    storage.update();
                });
                return storage;
            }()),
            isShown = function isShown(d){ //logic function to determine if a specific node should be visible
                var shown = false;

                if(!flatTree.currentNode.parent){ //currentNode is root
                    if(d.depth === 1){
                        shown = true;
                    } //only show first level
                }else if(!flatTree.currentNode.children){ //currentNode has no children
                    if(d.parent === flatTree.currentNode.parent || //d is sibling to currentNode
                        d === flatTree.currentNode.parent.parent || //d is currentNode's grandparent
                        (flatTree.currentNode.parent.depth !== 0 && d === flatTree.currentNode.parent) //d is currentNode's parent which isn't root
                        ){
                        shown = true;
                    }
                }else{ //currentNode has children
                    if(d.parent === flatTree.currentNode || //d is child of currentNode
                        d === flatTree.currentNode || //d is currentNode
                        d === flatTree.currentNode.parent //d is parent of currentNode
                        ){
                        shown = true;
                    }
                }
                if(!d.parent && flatTree.currentNode.parent){ //d is root and not currentNode then show "main" at current node depths < 1 or for children of depth 1
                    shown = flatTree.currentNode.depth > 1 || is(flatTree.currentNode.children);
                }

                if (d.module ? options.modules.indexOf(d.module) > -1 : true){
                    shown = shown && true;
                }else{
                    shown = false;
                }
                return shown;
            },
            rgb2rgba = function rgb2rgba(rgb, a){ //rgb(#,#,#) -> rgba(#,#,#,#) which adds opacity (alpha) channel to rgb color
                return rgb.replace(/(rgb)([^\)]*)/, '$1a$2,' + a);
            },
            generateColors = function generateColors(i){ //function to generate basic gradient color objects when not specified in json
                var rgb = d3.rgb(color(i)), //use d3 color generator to pick a color
                    genColor = 'rgb(' + rgb.r + ',' + rgb.g + ',' + rgb.b + ')'; //build rgb color from components
                return[ //default gradient color array
                    {position:'0%', color:rgb2rgba(genColor, 0.2)},
                    {position:'30%', color:genColor},
                    {position:'100%', color:rgb2rgba(genColor, 0.2)}
                ];
            },
            gradient = function gradient(prefix, colors){ //build vendor specific browser gradients (except IE9)
                var gradientString = prefix + '(top, ';
                for(var a in colors){
                    if(colors.hasOwnProperty(a)){
                        gradientString += colors[a].color + ' ' + colors[a].position + ', ';
                    }
                }
                return gradientString.slice(0, -2) + ')'; //remove comma and space then append closing parenthesis to finish prefix string
            },
            setBackground = function setBackground(caller, mouseover){ //function to generate static and mouseover background gradients
                var thisD3 = d3.select(caller),
                    d = thisD3.node().__data__,
                    i = flatTree.indexOf(d),
                    colors = d.colors,
                    selected = is(mouseover) || flatTree.currentNode === d;
                if(Array.isArray(d)){ //check if d is a group
                    colors = d.parent.colors ? d.parent.colors : generateColors(flatTree.indexOf(d.parent)); //group inherit parent's color scheme
                }
                if(!colors){ //if no json gradient is specified generate some color gradients
                    colors = generateColors(i);
                }
                thisD3.select('a');
                if(navigator.appVersion.indexOf('MSIE') !== -1 && parseFloat(navigator.appVersion.split('MSIE')[1]) < 10){//IE9 special treatment
                    caller.style.background = (function IE9Background(d){ //IE9 glitches on D3's style assign (D3 bug?), so this does the identical thing but works
                        if(!selected){
                            return 'transparent';
                        } // if not selected then don't generate gradient
                        var image = '<?xml version="1.0" ?><svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 1 1" preserveAspectRatio="none"><linearGradient id="i' + i + '" gradientUnits="userSpaceOnUse" x1="0%" y1="0%" x2="0%" y2="100%">"'; //build svg for IE9
                        for(var a in colors){
                            if(colors.hasOwnProperty(a)){
                                image += '<stop offset="' + colors[a].position + '" stop-color="' + colors[a].color + '" />';
                            }
                        }
                        image += '</linearGradient><rect x="0" y="0" width="1" height="1" fill="url(#i' + i + ')" /></svg>';
                        return 'url(data:image/svg+xml;base64,' + base64.encode(image) + ')'; //return base64 encoded svg data url
                    }(d));
                }else{
                    thisD3.style('background', function backgroundStyle(d){ //IE10+ and all other browsers
                        return selected ? gradient('-moz-linear-gradient', colors) : 'transparent';
                    }).style('background', function backgroundStyle(d){
                        return selected ? gradient('-webkit-linear-gradient', colors) : 'transparent';
                    }).style('background', function backgroundStyle(d){
                        return selected ? gradient('-ms-linear-gradient', colors) : 'transparent';
                    });
                }
            },
            flatTreeFirstLevelCount = flatTree.filter(function(e){ //keep track of first level elements for auto group sizing
                return e.depth === 1;
            }).length,
            drawMenu = function drawMenu(){
                d3.select('.navmenu').selectAll('.item-container').data(flatTree).call(function navmenu(){
                    this.enter().append('div').attr('class', 'item-container').call(function navmenuEnter(){
                        this.each(function navmenuEnterEach(d){

                            var thisD3 = d3.select(this).append('div').attr('class', 'item-content');
                            if(Array.isArray(d) && d[0]){ //d is array which means display as list
                                var children = d[0].parent.children;
                                for(var child in children){
                                    (child | 0 !== 0 && child % 5 === 0 ? thisD3 = d3.select(this).append('div') : thisD3) //child % 5 to create new columns after 4 rows
                                        .attr('class', 'item-content list')
                                        .style('vertical-align', 'top')
                                        .append('a')
                                        .attr('class', 'no-outline')
                                        .style('display', 'block')
                                        .style('text-align', 'left')
                                        .attr('href', children[child].href)
                                        .text(children[child].name);
                                }
                            }else{
                                if(d.icon){
                                    thisD3.append('img').attr('src', d.icon);
                                }
                                thisD3.append('a').style('display', 'block').attr('href', d.href).text(d.name);
                            }

                        });
                        var selected = function selected(d){
                            if(is(d.href)){
                                window.location = d.href;
                            }
                            if(!Array.isArray(d)){
                                var lastNode = flatTree.currentNode;
                                flatTree.currentNode = d;
                                setBackground(d3.select('.navmenu').selectAll('.item-container')[0][flatTree.indexOf(lastNode)]);
                                drawMenu();
                                $(window).trigger('hashchange');
                            }
                        };
                        this.on('click', selected);
                        this.on('keypress', function keypress(d){
                            var keyCode = d3.event.keyCode;
                            if(keyCode === 13 || keyCode === 32){ //enter or space
                                selected(d);
                            }
                        });
                    });
                    var tabIndex = 1;
                    this.selectAll('a').each(function navmenuAEach(d){
                        this.tabIndex = isShown(d) ? tabIndex++ : -1;
                    });
                    setBackground(this[0][flatTree.indexOf(flatTree.currentNode)]);
                    this.transition().duration(is(json.menuTransitionDuration) ? json.menuTransitionDuration | 0 : 300)
                        .styleTween('width', function navmenuTween(d){
                            var mainButtonWidth = 98, //width of main (go to root) button
                                normalButtonWidth = 138, //regular button width
                                groupedButtonsWidth = (flatTreeFirstLevelCount - 1) * normalButtonWidth - mainButtonWidth, //width of grouped area that contains grouped buttons
                                width = d.depth === 0 ? mainButtonWidth : Array.isArray(d) ? groupedButtonsWidth : normalButtonWidth,
                                start = d.shown === true ? width : 0,
                                end = isShown(d) ? width : 0,
                                i = d3.interpolateRound(start, end);
                            d.shown = isShown(d);
                            return function navmenuTweenFunction(t){
                                return i(t) + 'px';
                            };
                        });
                    this.on('mouseover',function navmenuMouseover(d){
                        if(!Array.isArray(d)){
                            setBackground(this, 'over');
                            d3.select(this).select('a').attr('class','item-content-hover');
                            d3.select(this).select('img').attr('src', function navmenuMouseoverIconSrc(d){
                                return is(d.iconSelected) ? d.iconSelected : d.icon;
                            });
                        }
                    }).on('mouseout', function navmenuMouseout(d){
                            if(!Array.isArray(d)){
                                setBackground(this);
                                d3.select(this).select('a').attr('class','');
                                d3.select(this).select('img').attr('src', function navmenuMouseoutIconSrc(d){
                                    return is(d.iconSelected) && d === flatTree.currentNode ? d.iconSelected : d.icon;
                                });
                            }
                        });
                    this.select('img').attr('src', function navmenuIconSrc(d){
                        return d === flatTree.currentNode && is(d.iconSelected) ? d.iconSelected : d.icon;
                    });
                });
            },
            drawVisited = function drawVisited(){
                if(!d3.select('.navmenu .extra').node()){ //check if "Recently Visited" nav div doesn't exist then create it
                    d3.select('.navmenu').append('div').attr('class', 'item-container extra').append('div').attr('class', 'item-content');
                }
                d3.select('.navmenu .extra').style('display', function navmenuExtraDisplay(){ //show recently visited whenever "Main" (root) menu button is shown
                    return isShown(flatTree[0]) ? '' : 'none'; //display none if root not shown
                });
                d3.select('.navmenu .extra .item-content').selectAll('a').data(history).call(function navmenuExtraA(){
                    this.enter().append('a').attr('href',function navmenuExtraAEnterHref(d){
                        return d && d.href ? d.href : undefined;
                    }).text(function navmenuExtraAEnterText(d){
                        return d && d.name ? d.name : undefined;
                    }).on('click', function navmenuExtraAEnterClick(){
                        drawMenu();
                    });
                    this.attr('href',function navmenuExtraAHref(d){
                        return d && d.href ? d.href : undefined;
                    }).text(function navmenuExtraAText(d){
                        return d && d.name ? d.name : undefined;
                    }).on('click', function navmenuExtraAClick(){
                        drawMenu();
                    });
                    this.exit().remove();
                });
            },
            drawPlus = function drawPlus(){
                if(!d3.select('.navmenu .plus').node()){ //check if "Recently Visited" nav div doesn't exist then create it
                    d3.select('.navmenu').append('div').attr('class', 'item-container plus').append('div').attr('class', 'item-content').append('div');
                }
                d3.select('.navmenu .plus').style('display', function drawPlusStyleDisplay(){ //show recently visited whenever "Main" (root) menu button isn't shown
                    return isShown(flatTree[0]) ? 'none' : ''; //display none if root shown
                });
            };
        drawMenu();
        drawVisited();
        drawPlus();
        if(!history.menuIsOpen){
            $('.nav-container, .navFloat').animate({height:'toggle'}, 0);
        } //close menu if history says it was
        d3.select('.menu-toggle div').on('click', function menutoggleClick(){ //open or close menu and update menuIsOpen state
            $('.nav-container, .navFloat').animate({height:'toggle'}, history.menuIsOpen ? (json.closeDuration ? json.closeDuration | 0 : 200) : (json.openDuration ? json.openDuration | 0 : 500), history.menuIsOpen ? (json.closeType ? json.closeType : 'easeOutExpo') : (json.openType ? json.openType : 'easeOutElastic'));
            history.menuIsOpen = !history.menuIsOpen;
            history.update();
        });
    };
});