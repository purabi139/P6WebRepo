define([
    "jquery", "underscore", "text!src/templates/widgets/toolbar.htm"
], function ($, _, ToolbarLayout) {
    "use strict";

    var toolbarLayoutElement = $(ToolbarLayout);

    var Toolbar = function () {
    };

    Toolbar.prototype = {
        _AdditionPlacement: {
            Append: 0,
            Prepend: 1
        },

        AdditionType: {
            Add: 0,
            Delete: 1
        },

        ButtonSize: {
            Mini: "btn-mini",
            Small: "btn-small",
            Normal: "",
            Large: "btn-large"
        },

        ButtonType: {
            Danger: "btn-danger",
            Default: "",
            Info: "btn-info",
            Inverse: "btn-inverse",
            Primary: "btn-primary",
            Success: "btn-success",
            Warning: "btn-warning",
            Action: "btn-action",
            BlueDark: "btn-blue-dark",
            BlueLight: "btn-blue-light"
        },

        ButtonDataDismissType:{
            Modal : "modal",
            Alert : "alert"
        },

        DropDirection: {
            Down: "",
            Up: "dropup"
        },

        Button: function (options) {
            options.additionInfo = null;
            return this._createButtonHtml(".tpl-button", options);
        },

        ButtonDataDismiss : function(options){
            return this._createButtonHtml(".tpl-button-data-dismiss", options);
        },

        ButtonAppended: function (options, additionType) {
            options.additionInfo = this._createAdditionInfo(additionType, this._AdditionPlacement.Append);
            return this._createButtonHtml(".tpl-button", options);
        },

        ButtonPrepended: function (options, additionType) {
            options.additionInfo = this._createAdditionInfo(additionType, this._AdditionPlacement.Prepend);
            return this._createButtonHtml(".tpl-button", options);
        },

        ButtonDropdown: function (options) {
            options.dropDirection = options.dropDirection || this.DropDirection.Down;
            options.hasDivider = false;
            return this._createButtonHtml(".tpl-buttonDropdown", options);
        },

        ButtonDropdownWithDivider: function (options) {
            options.dropDirection = options.dropDirection || this.DropDirection.Down;
            options.hasDivider = true;
            return this._createButtonHtml(".tpl-buttonDropdown", options);
        },

        SplitButtonDropdown: function (options) {
            options.dropDirection = options.dropDirection || this.DropDirection.Down;
            return this._createButtonHtml(".tpl-splitButtonDropdown", options);
        },

        ButtonGroup: _.template(_.pluckMarkup(toolbarLayoutElement, ".tpl-buttonGroup", null)),

        Toolbar: _.template(_.pluckMarkup(toolbarLayoutElement, ".tpl-toolbar", null)),

        _createAdditionInfo: function (additionType, additionPlacement) {
            var additionInfo = null;

            switch (additionType) {
                case this.AdditionType.Add:
                    additionInfo = {
                        cssClass: "add",
                        label: "+"
                    };
                    break;
                case this.AdditionType.Delete:
                    additionInfo = {
                        cssClass: "del",
                        label: "x"
                    };
                    break;
            }
            switch (additionPlacement) {
                case this._AdditionPlacement.Append:
                    additionInfo.append = true;
                    break;
                case this._AdditionPlacement.Prepend:
                    additionInfo.prepend = true;
                    break;
            }
            return additionInfo;
        },

        _createButtonHtml: function (templateClass, options) {
            return _.pluckMarkup(toolbarLayoutElement, templateClass, _.defaults(options, {
                size: this.ButtonSize.Normal,
                type: this.ButtonType.BlueLight
            }));
        },

        _itemEnabled: function (itemElement) {
            var result = true;

            // See https://github.com/twitter/bootstrap/pull/2301/files
            if (itemElement.prop("disabled") || itemElement.is(".disabled") || itemElement.is("[disabled]")) {
                result = false;
            }
            return result;
        },

        ToolbarItemCallback: function (callback) {
            var self = this;

            return function (e) {
                return self._itemEnabled($(e.currentTarget)) ? _.bind(callback, this)(e) : false;
            };
        },

        enable: function (buttonElement) {
            buttonElement.removeClass("disabled");
        },

        disable: function (buttonElement) {
            if (!buttonElement.hasClass("disabled")) {
                buttonElement.addClass("disabled");
            }
        }
    };

    return new Toolbar();
});
