define([
    'jquery', 'underscore', 'i18n!src/nls/localeStrings',
    'text!src/views/widgets/filter/filter.htm'
], function ($, _, Locale, filtermarkup) {
    'use strict';
    var $filterMarkup = _.pluckMarkup($(filtermarkup), '.filter_markup', null);

    var minimumLettersForWord = 2;


    $.widget('orcl.filtersearch', {
        options : {
            searchCallback : $.noop,
            resetSearch : $.noop,
            indicateNoResults : $.noop,
            indicateFoundResults : $.noop,
            placeholder : 'Filter',
            alternateText : 'Filter',
            searchData : { },
            getSelectorsToHide : null

        },
        _create : function () {
            var filterScope = this;
            var filterbox = _.template($filterMarkup,
                {placeholder : this.options.placeholder, alternateText : this.options.alternateText});
            filterScope.element.append(filterbox);
            filterScope.options._filterbox = this.element.find('.filterbox');

            filterScope.options._filterbox.on('keyup', function () {
                var filterBoxValue = filterScope.options._filterbox.val();
                filterScope.options._filterbox.toggleClass('empty', '' === filterBoxValue);

                if (filterBoxValue !== filterScope.options._lastFilterBoxValue) {

                    var words = _.reject(filterBoxValue.split(' '), function (word) {
                        return word.length < minimumLettersForWord;
                    });
                    if (words.length === 0) {
                       filterScope._resetSearch();
                        return;
                    }
                    var matchedSettings = _.intersection.apply(this, _.map(words, $.proxy(filterScope, '_findWord')));
                    filterScope.options.resetSearch();
                    var hideSelectors = filterScope.options.getSelectorsToHide(matchedSettings);
                    _.each(hideSelectors,function(unMatchedSelector){
                        var hideElement =unMatchedSelector;
                        hideElement.addClass('hidden');
                    });
                    if (matchedSettings.length === 0 || hideSelectors.length === 0) {
                        filterScope.options.indicateNoResults();
                        filterScope.options._filterbox.addClass('filterbox-no-results');
                        filterScope.options._filterbox.attr('title', 'No results found for filter');

                    } else {
                        filterScope.options._filterbox.addClass('filterbox-with-results');
                        filterScope.options.indicateFoundResults();
                    }
                }

                filterScope.options._lastFilterBoxValue = filterBoxValue;
            });

            filterScope.element.find('.clear-text-input').on('click', function ($event) {
                filterScope.options._filterbox.val('');
               filterScope._resetSearch();
                $event.preventDefault();

            });
            return this;
        },
        _findWord : function (searchTerm) {
            var filterScope = this;
            var results = [];

            searchTerm = searchTerm.toLowerCase();
            for (var str in filterScope.options.searchData) {
                if (str.toLowerCase().indexOf(searchTerm) !== -1) {
                    results.push(filterScope.options.searchData[str]);
                }
            }

            return results;
        },
        _resetSearch : function(){
            var filterScope = this;
            filterScope.options._filterbox.removeClass('filterbox-with-results');
            filterScope.options._filterbox.removeClass('filterbox-no-results');
            filterScope.options._filterbox.attr('title', filterScope.options.alternateText);
            filterScope.options.resetSearch();
        }
    });
});
