define([
    'jquery', 'underscore', 'text!src/views/widgets/checkboxTable.htm', 'src/views/widgets/accessibleImage'],
    function ($, _, checkboxTableMarkup) {

        'use strict';
        var $tableMarkup = $(checkboxTableMarkup);
        var tableMarkup = _.pluckMarkup($tableMarkup, '.checkbox-table', null);
        var tableColumnHeaderMarkup = _.pluckMarkup($tableMarkup, '.table-column-header', null);
        var tableRowStartMarkup = _.pluckMarkup($tableMarkup, '.table-row-start', null);
        var tableRowCheckboxMarkup = _.pluckMarkup($tableMarkup, '.table-checkbox', null);
        var tableTargetKey = 'table_target_selector';
        var expandedClass = 'expanded';

        $.widget('orcl.tableofcheckboxes', {
            _options : {
                sections : [],
                tablePrefix : '',
                _checkedOptions : []
            },
            _create : function () {
                var checkboxTableScope = this;
                checkboxTableScope.options._linkedColumns = {};
                checkboxTableScope.options._oneWayColumns = {};
                var $widgetElement = checkboxTableScope.element;
                var checkboxHandler = function ($event) {
                    var $currentCheckbox = $($event.currentTarget);
                    var row = $currentCheckbox.attr('name');
                    var column = $currentCheckbox.attr('value');
                    //find linked columns in the map that also need to be checked
                    if (checkboxTableScope.options._linkedColumns[row + column]) {
                        var currentLinkedColumns = checkboxTableScope.options._linkedColumns[row + column].main || [];
                        currentLinkedColumns = _.compact(currentLinkedColumns);
                        if ($currentCheckbox.prop('checked')) {
                            currentLinkedColumns = currentLinkedColumns.concat(checkboxTableScope.options._linkedColumns[row + column].other) || [];
                        }
                        var checkSelectorMarkup = 'input[name="<%=row%>"][value="<%=column%>"]';
                        _.each(currentLinkedColumns, function (entry) {

                            var checkSelector = _.template(checkSelectorMarkup,{row:entry.row,column:entry.column});
                            if ($widgetElement.find(checkSelector).prop('checked') === $currentCheckbox.prop('checked')) {
                                return false;
                            }
                            $widgetElement.find(checkSelector).click();
                        });
                    }
                    //if current column is in the oneway column and is unchecked,  uncheck the other columns
                    var currentOtherLinkedColumns = checkboxTableScope.options._oneWayColumns[row + column];
                    if (!$currentCheckbox.prop('checked')) {
                        _.each(currentOtherLinkedColumns, function (entry) {
                            if (true === $widgetElement.find('input[name="' + entry.row + '"][value="' + entry.column + '"]').prop('checked')) {
                                $widgetElement.find('input[name="' + entry.row + '"][value="' + entry.column + '"]').click();
                            }
                        });
                    }
                };
                _.each(checkboxTableScope.options.sections, function (section) {
                    var tableTitle = section.title,
                        tabletype = checkboxTableScope.options.tablePrefix + tableTitle.replace(/ /g, "_"),
                        columnHeaders = section.columnHeaders,
                        rowHeaders = section.rowHeaders;


                    $widgetElement.append(_.template(tableMarkup,
                        {tableType : tabletype, tableHeader : tableTitle}));
                    $widgetElement.find('li span.twistie-text.' + tabletype).accessibleImage({cssClass : 'accessibleTwistie', altText : 'collapsed'});

                    $widgetElement.find('span.' + tabletype).data(tableTargetKey, tabletype);
                    //Dynamically insert columns in table based on available actions
                    var tableSelector = 'table.' + tabletype;
                    //build the table header
                    var $tableHeaderRow = $widgetElement.find(tableSelector + ' thead tr');
                    _.each(columnHeaders, function (columnHeader, index) {
                        $tableHeaderRow.append(_.template(tableColumnHeaderMarkup,
                            {columnid : 'c' + index, actionName : columnHeader, actionLabel : columnHeader}));

                    });

                    //Dynamically insert rows with the entries in all the columns defined above.
                    _.each(rowHeaders, function (rowHeader, rowIndex) {
                        var tableRowTemplate = tableRowStartMarkup;
                        _.each(columnHeaders, function (columnHeader, columnIndex) {
                            if (!rowHeader.available || _.contains(rowHeader.available, columnHeader)) {
                                tableRowTemplate += _.template(tableRowCheckboxMarkup,
                                    {cellId : 'r' + rowIndex + ' c' + columnIndex, row : rowHeader.internalName, column : columnHeader});
                            } else {
                                tableRowTemplate += "<td>&nbsp;</td>";
                            }
                        });
                        var tableRowEntityTemplate = '<tr>' + tableRowTemplate + '</tr>';
                        var $checkBoxTable = $widgetElement.find(tableSelector);
                        $checkBoxTable.append(_.template(tableRowEntityTemplate,
                            {rowid : 'r' + rowIndex, entityName : rowHeader.displayName}));
                        if (rowHeader.linked) {
                            _.each(rowHeader.linked, function (linked) {
                                var linkedColumns = linked.twoWayLinked || linked;
                                _.each(linkedColumns, function (entry) {
                                        //build a map from one column to its linked columns
                                        _.each(linkedColumns, function (linkedColumn) {
                                            var currentMainColumnIndex = linkedColumn.row + linkedColumn.column;
                                            var linkedArray = {};
                                            linkedArray.main = _.reject(linkedColumns, function (currentColumn) {
                                                return currentColumn.row === linkedColumn.row && currentColumn.column === linkedColumn.column;
                                            }) || [];
                                            //add one way relationships
                                            if (linked.oneWayLinked) {
                                                linkedArray.other = linked.oneWayLinked;
                                                _.each(linked.oneWayLinked, function (currentOtherColumn) {
                                                    checkboxTableScope.options._oneWayColumns[currentOtherColumn.row + currentOtherColumn.column] = linkedColumns;
                                                });
                                            }
                                            checkboxTableScope.options._linkedColumns[currentMainColumnIndex] = linkedArray;
                                        });

                                        $widgetElement.find(':checkbox').change(checkboxHandler);

                                    }
                                );
                            });

                        }

                    });

                    //Implement twistie
                    $widgetElement.on('click', 'span.twistie-text.' + tabletype, function ($event) {
                        var $elementWithData = $($event.currentTarget);
                        var $twistieSpan = $elementWithData.accessibleImage('rootElement');
                        $twistieSpan.toggleClass(expandedClass);
                        $elementWithData.toggleClass(expandedClass);
                        //TODO: expanded and collapsed needs to be translated
                        $elementWithData.accessibleImage('accessibleTextElement').html(($twistieSpan.hasClass(expandedClass) ? 'expanded' : 'collapsed'));
                        $('table.' + $elementWithData.data(tableTargetKey)).toggle();

                    });


                    //Hide table on load
                    $(tableSelector).hide();

                    checkboxTableScope.options._checkedOptions = [];
                });


                checkboxTableScope._on($widgetElement, {
                    change : function (event) {
                        var checkboxScope = this;
                        var currentCheckbox = event.target;
                        if ($(currentCheckbox).is(':checkbox')) {
                            var column = $(currentCheckbox).val();
                            var row = $(currentCheckbox).attr('name');

                            var currentCheckedRow;
                            var currentCheckedRowIndex;
                            if (checkboxTableScope.options._checkedOptions) {
                                currentCheckedRow = $.grep(checkboxTableScope.options._checkedOptions,
                                    function (object, index) {
                                        if (row === object.row) {
                                            currentCheckedRowIndex = index;
                                            return true;
                                        } else {
                                            return false;
                                        }
                                    });
                            }
                            if (column && (!currentCheckedRow || currentCheckedRow.length === 0)) {
                                checkboxTableScope.options._checkedOptions.push({row : row, columns : [column]});
                            } else {
                                if (!$(currentCheckbox).attr('checked')) {
                                    var optionIndex = currentCheckedRow[0].columns.indexOf(column);
                                    currentCheckedRow[0].columns.splice(optionIndex, 1);
                                } else {
                                    if ($.inArray(column, currentCheckedRow[0].columns) === -1) {

                                        currentCheckedRow[0].columns.push(column);
                                    }
                                }
                                if (!currentCheckedRow[0].columns.length) {
                                    checkboxTableScope.options._checkedOptions.splice(currentCheckedRowIndex, 1);
                                }
                            }

                            checkboxTableScope._trigger('tableofcheckboxchanged');
                        }
                    },
                    click : function ($event) {
                        var $currentTarget = $($event.target);
                        if ($currentTarget.is('SPAN') && (($currentTarget.hasClass('twistie-text')) || (($currentTarget.hasClass('accesibleTwistie')) ))) {
                            if (checkboxTableScope.options.expandCollapseCallback) {
                                checkboxTableScope.options.expandCollapseCallback($event);
                            }
                        }
                    }
                });
            },
            setCheckboxes : function (selectedCheckboxes) {
                var checkboxTableScope = this;
                //var tableSelector = '.' + tabletype;
                if (!selectedCheckboxes || selectedCheckboxes.length === 0) {
                    checkboxTableScope.element.find('table input:checked').removeAttr('checked');
                    checkboxTableScope.options._checkedOptions = [];
                    return;
                }
                _.each(selectedCheckboxes, function (checkOption) {
                    var separator = '';
                    var permissionSelector = _.reduce(checkOption.columns, function (result, column) {
                        if (result.length > 0) {
                            separator = ',';
                        }
                        return result + separator + '[value="' + column + '"]';
                    }, '');


                    checkboxTableScope.element.find('table input[name="' + checkOption.row + '"]').filter(permissionSelector).attr('checked',
                        'checked');
                });

                checkboxTableScope.options._checkedOptions = selectedCheckboxes;
            },
            getCheckboxes : function () {
                var checkboxTableScope = this;
                return checkboxTableScope.options._checkedOptions;
            },
            expandAll : function () {
                var checkboxTableScope = this;
                _.each(checkboxTableScope.element.find('span.twistie-text'), function (currentspan) {
                    var $twistieSpan = $(currentspan).find('span:first');

                    $twistieSpan.addClass(expandedClass);
                    $($twistieSpan.parent('.twistie-text')).addClass(expandedClass);
                    //TODO: Needs to be translated
                    $twistieSpan.find('>span').html(expandedClass);
                    checkboxTableScope.element.find('table').show();
                });
            },
            collapseAll : function () {
                var checkboxTableScope = this;
                _.each($('span.twistie-text'), function (currentspan) {
                    var $twistieSpan = $(currentspan).find('span:first');

                    $twistieSpan.removeClass(expandedClass);
                    $($twistieSpan.parent('.twistie-text')).removeClass(expandedClass);
                    //TODO: Needs to be translated
                    $twistieSpan.find('>span').html("collapsed");
                    checkboxTableScope.element.find('table').hide();
                });
            }

        });
    });