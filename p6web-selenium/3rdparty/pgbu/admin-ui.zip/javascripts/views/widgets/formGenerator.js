define([
    'jquery', 'underscore', 'i18n!src/nls/localeStrings', 'src/utilities/hint', 'inputsapi.date/dateWidget'
], function ($, _, locale, hint) {
    'use strict';

    // WARNING: not a true widget, even though it's in the widget directory.
    // It's in the widget directory to establish the intent of turning settings into a widget.

    /**
     * HTML Classname semantics:
     * setting: the DOM element corresponding to a JSON setting object.
     * setting-wrapper: wraps the form element of class setting and all its appendages,
     *   including label, hint, help hyperlink, related data hyperlinks, widget DOM injections,
     *   extra layout or styling DOM, validation feedback, and setting-children,
     *   and gets attached to either a setting-children parent, or the root container.
     *   setting and setting-wrapper elements are 1-to-1.
     * setting-children: parent of a setting-wrapper for each setting form element corresponding to
     *   a member of layoutChildren, child of either the setting or the setting-wrapper.
     *   Every setting with layoutChildren has exactly one setting-children DOM element.
     *
     * For an explicit set of setting element tags, the setting's label and setting-children elements
     * are peers of the setting element.  Otherwise, the setting's label and setting-children elements
     * are children of the setting element.
     */

    // Layout and decoration markup
    var fieldsetMarkup = '<fieldset></fieldset>';
    var divMarkup = '<div></div>';
    var labelMarkup = '<label class="setting-label" for="<%=id%>"><%=label%></label>';
    var legendMarkup = '<legend class="setting-label"><%=label%></legend>';
    var h3Markup = '<h3 class="setting-label"><%=label%></h3>';
    var h4Markup = '<h4 class="setting-label"><%=label%></h4>';
    var identityMarkup = '<%=label%>';
    var wrapperMarkup = '<div class="setting-wrapper"></div>';
    var childrenMarkup = '<div class="setting-children"></div>';

    // Generic element
    var textMarkup = '<input type="text" name="<%=internalName%>" id="<%=id%>" />';

    function settingWidthClass (lengthMax) {
        return lengthMax < 5 ? 'setting-width-1' :
            lengthMax < 10 ? 'setting-width-2' :
            lengthMax < 15 ? 'setting-width-3' :
            lengthMax < 30 ? 'setting-width-4' :
            'setting-width-5';
    }

    /**
     * Base class for type-specific form generating objects.
     * @constructor
     */
    function Setting () {
        this.initialize();
    }
    // Instance variables & methods
    $.extend(Setting.prototype, {
        initialize: function () {
            this.$el = null; // Display element
            return this;
        },
        /**
         * Abstract base class to construct a form element with a decoration wrapper based on a json object.
         * @param options // See factory options.
         * @return {Setting}
         */
        set: function (options) {
            this._buildSelf(options);
            return this;
        },
        add508: function (options) {
            if (options.json.tooltip) {
                this.$el.attr('title', options.json.tooltip);
            }
            return this;
        },
        widgetize: function () {
            return this;
        },
        wrap: function (options, hintContent) {
            return options.json.label ?
                this.wrapLabeled(options, hintContent) :
                this.wrapUnlabeled(options, hintContent);
        },
        wrapLabeled: function (options, hintContent) {
            var $wrapper = this.wrapAndInject(options);
            this.insertLabel(this.build$Label(options.json.label));
            if (hintContent) {
                $wrapper.append(hintContent);
            }
            return $wrapper;
        },
        wrapAndInject: function (options) {
            return (options.level ?
                $(wrapperMarkup).appendTo(options.$parentElement) :
                options.$parentElement.addClass('setting-wrapper'))
                .append(this.$el);
        },
        wrapUnlabeled: function (options, hintContent) {
            var $lastSiblingWrapper = options.$parentElement.children().last();
            if (0 === $lastSiblingWrapper.length) {
                $lastSiblingWrapper = options.$parentElement.closest('.setting-wrapper').has('>.setting');
            }
            if (0 === $lastSiblingWrapper.length) {
                return this.wrapAndInject(options);
            } else {
                this.joinSibling$wrapper($lastSiblingWrapper, options, hintContent);
            }
            return $lastSiblingWrapper;
        },
        joinSibling$wrapper: function ($lastWrapper, options, hintContent) {
            var $lastSibling = $lastWrapper.children('.setting,.setting-label').last();
            $lastSibling.after($(wrapperMarkup).addClass('setting-no-label').append(this.$el));
            var $hint = $lastWrapper.children('.setting-hint');
            if (0 === $hint.length) {
                $lastWrapper.append(hintContent);
            } else {
                $hint.append($(hintContent).children());
            }
            return $lastWrapper;
        },
        getLabelMarkup: function () {
            return labelMarkup;
        },
        build$Label: function (label) {
            return $(_.template(this.getLabelMarkup(), { label: label, id: this.$el.prop('id') }));
        },
        insertLabel: function ($label) {
            return this.$el.before($label);
        },
        buildChildren$Container: function () {
            return $(childrenMarkup).appendTo(this.$el.closest('.setting-wrapper'));
        },
        _buildSelf: function (options) { throw new Error('Internal error: subclasses must define _buildSelf. Options are ' + options.toString()); },
        _makeSetting$el: function (markup, json) {
            this._assertSetting(json);
            this.$el = $(_.template(markup, _.extend({ id: this._uniqueId(json) }, json)));
            this.$el.addClass(this.$el.attr('name')).addClass('setting');
            return this.$el;
        },
        _assertSetting: function (currentInput) {
            if (!currentInput.hasOwnProperty('internalName')) {
                throw (new Error(_.template('Server-side error: <%=item%> cannot be set.',
                    { item: ('"' + (currentInput.label ? currentInput.label : '(unknown)') + '"') ||
                        (currentInput.type + '(' + currentInput.defaultValue + ')') })));
            }
        },
        _uniqueId: function (json) {
            return _.uniqueId((json.internalName || 'setting-structure') + '-');
        }
    });

    /**
     * Setting subclass to generate DOM corresponding to a group.  Also serves as a base class.
     * @constructor
     */
    function GroupSetting () {
        Setting.call(this);
    }
    GroupSetting.prototype = new Setting();
    $.extend(GroupSetting.prototype, {
        _buildSelf: function (options) {
            this._assertSetting(options.json);
            this.$el = $(2 === options.level ? fieldsetMarkup : divMarkup)
                .addClass('setting-group')
                .prop('id', this._uniqueId(options.json));
            if (1 === options.level) {
                this.$el.addClass('setting-category');
            }
            return this;
        },
        getLabelMarkup: function () {
            return 'fieldset' === this.$el.prop('tagName').toLowerCase() ?
                legendMarkup :
                this.$el.hasClass('setting-category') ? h3Markup : h4Markup;
        },
        insertLabel: function ($label) {
            return this.$el.append($label);
        },
        buildChildren$Container: function () {
            return $(childrenMarkup).appendTo(this.$el);
        },
        wrapUnlabeled: function (options) {
            var $wrapper = this.wrapAndInject(options);
            $wrapper.removeClass('setting-no-label');
            return $wrapper;
        }
    });

    function BooleanSetting () {
        Setting.call(this);
    }
    BooleanSetting.prototype = new Setting();
    BooleanSetting.markup = '<input type="checkbox" id="<%=id%>" name="<%=internalName%>" value="true"/>';
    $.extend(BooleanSetting.prototype, {
        _buildSelf: function (options) {
            this._makeSetting$el(BooleanSetting.markup, options.json);
            return this;
        },
        insertLabel: function ($label) {
            return this.$el.after($label);
        }
    });

    // Only for CHOICE options
    function CandidateSetting () {
        Setting.call(this);
    }
    CandidateSetting.markup = '<input type="radio" value="<%=value%>" id="<%=id%>" name="<%=internalName%>" />';
    CandidateSetting.prototype = new Setting();
    $.extend(CandidateSetting.prototype, {
        _buildSelf: function (options) {
            var parentJsonCopy = _.map(options.parentJson, _.identity);
            parentJsonCopy.reverse();
            var parentChoice = _.find(parentJsonCopy, function (jsonObj) {
                return 'CHOICE' === jsonObj.type;
            });
            options.json.internalName = parentChoice.internalName;
            this._makeSetting$el(CandidateSetting.markup, options.json);
            return this;
        },
        insertLabel: function ($label) {
            return this.$el.after($label);
        }
    });

    function ChoiceSetting () {
        GroupSetting.call(this);
    }
    ChoiceSetting.prototype = new GroupSetting();
    $.extend(ChoiceSetting.prototype, {
        _buildSelf: function (options) {
            this._assertSetting(options.json);
            GroupSetting.prototype._buildSelf.call(this, options);
            this.$el.removeClass('setting-group').addClass('setting-choice');
            return this;
        }
    });

    function DateSetting () {
        Setting.call(this);
    }
    DateSetting.markup = '<input type="date" class="setting-date" name="<%=internalName%>" id="<%=id%>" />';
    DateSetting.prototype = new Setting();
    $.extend(DateSetting.prototype, {
        _buildSelf: function (options) {
            this._makeSetting$el(DateSetting.markup, options.json);
            return this;
        },
        widgetize: function () {
            this.$el.datePicker({
                style: 'self',
                fallback: false,
                locale : {
                    today: locale.label.today,
                    cancel: locale.label.cancel
                },
                dateFormat: 'mm/dd/yyyy hh:MM TT',
                valFormat: 'mm-dd-yyyy',
                spinner: {time:{format: 'hh:MM:s'}},
                type: 'datetime'
            });
        }
    });

    function DropdownSetting () {
        Setting.call(this);
    }
    DropdownSetting.markup = '<select class="setting-dropdown" id="<%=id%>" name="<%=internalName%>"></select>';
    DropdownSetting.prototype = new Setting();
    $.extend(DropdownSetting.prototype, {
        _buildSelf: function (options) {
            this._makeSetting$el(DropdownSetting.markup, options.json);
            return this;
        },
        buildChildren$Container: function () {
            return this.$el;
        }
    });

    function DurationSetting () {
        Setting.call(this);
    }
    DurationSetting.prototype = new Setting();
    $.extend(DurationSetting.prototype, {
        _buildSelf: function (options) {
            this._makeSetting$el(textMarkup, options.json).addClass('setting-duration');
            return this;
        }
    });

    function InformationSetting () {
        Setting.call(this);
    }
    InformationSetting.markup = '<p class="setting-information"></p>';
    InformationSetting.prototype = new Setting();
    $.extend(InformationSetting.prototype, {
        _buildSelf: function (options) {
            this.$el = $(InformationSetting.markup)
                .addClass('setting')
                .prop('id', this._uniqueId(options.json));
            return this;
        },
        getLabelMarkup: function () {
            return identityMarkup;
        },
        build$Label: function (label) {
            return label;
        },
        insertLabel: function (label) {
            return this.$el.text(label.trim());
        },
        buildChildren$Container: function () {
            return $(childrenMarkup).appendTo(this.$el);
        }
    });

    function IntegerSetting () {
        Setting.call(this);
    }
    IntegerSetting.markup = '<input type="number" class="setting-integer" name="<%=internalName%>" id="<%=id%>"/>';
    IntegerSetting.prototype = new Setting();
    $.extend(IntegerSetting.prototype, {
        _buildSelf: function (options) {
            this._makeSetting$el(IntegerSetting.markup, options.json).addClass('setting-integer');
            var bounds = options.json.bounds || {};
            if (bounds.numberMin) {
                this.$el.attr('min', bounds.numberMin);
            }
            if (bounds.numberMax) {
                this.$el.attr('max', bounds.numberMax);
            }
            var nDigits = bounds.hasOwnProperty('numberMax') ?
                bounds.numberMax.toString().length : 20;
            if (nDigits > 8) {
                this.$el.addClass('setting-width-3');
            } else if (nDigits > 3) {
                this.$el.addClass('setting-width-2');
            }

            //TODO: if ('text' === this.$el.prop('type')), add spinner widget

            return this;
        }
    });

    function NumberSetting () {
        Setting.call(this);
    }
    NumberSetting.markup = '<input type="number" class="setting-floating-point" name="<%=internalName%>" id="<%=id%>"/>';
    NumberSetting.prototype = new Setting();
    $.extend(NumberSetting.prototype, {
        _buildSelf: function (options) {
            this._makeSetting$el(NumberSetting.markup, options.json).addClass('setting-number');
            var bounds = options.json.bounds || {};
            if (bounds.numberMin) {
                this.$el.attr('min', bounds.numberMin);
            }
            if (bounds.numberMax) {
                this.$el.attr('max', bounds.numberMax);
            }
            this.$el.attr('step', bounds.numberStep || '.01');
            return this;
        }
    });

    function OptionGroupSetting () {
        Setting.call(this);
    }
    OptionGroupSetting.markup = '<optgroup></optgroup>';
    OptionGroupSetting.prototype = new Setting();
    $.extend(OptionGroupSetting.prototype, {
        _buildSelf: function () {
            this.$el = $(OptionGroupSetting.markup);
            return this;
        },
        wrap: function (options) {
            var $wrapper = options.$parentElement.append(this.$el);
            this.$el.attr('label', options.json.label);
            return $wrapper;
        },
        buildChildren$Container: function () {
            return this.$el;
        }
    });

    function OptionSetting () {
        Setting.call(this);
    }
    OptionSetting.markup = '<option value="<%=value%>"></option>';
    OptionSetting.prototype = new Setting();
    $.extend(OptionSetting.prototype, {
        _buildSelf: function (options) {
            this.$el = $(_.template(OptionSetting.markup, options.json));
            return this;
        },
        wrap: function (options) {
            var $wrapper = options.$parentElement.append(this.$el);
            this.$el.text(options.json.label);
            return $wrapper;
        },
        buildChildren$Container: function () {
            throw new Error('Select options cannot have child elements.');
        }
    });

    function PasswordSetting () {
        Setting.call(this);
    }
    PasswordSetting.markup = '<input type="password" name="<%=internalName%>" id="<%=id%>" />';
    PasswordSetting.prototype = new Setting();
    $.extend(PasswordSetting.prototype, {
        _buildSelf: function (options) {
            this._makeSetting$el(PasswordSetting.markup, options.json);
            return this;
        }
    });

    function StringSetting () {
        Setting.call(this);
    }
    StringSetting.prototype = new Setting();
    $.extend(StringSetting.prototype, {
        _buildSelf: function (options) {
            this._makeSetting$el(textMarkup, options.json);
            // Manage bounds whether creating or replacing
            var bounds = options.json.bounds || {};
            if (bounds.lengthMax) {
                this.$el.attr('maxlength', bounds.lengthMax)
                    .addClass(settingWidthClass(options.json.bounds.lengthMax));
            }
            return this;
        }
    });

    function UrlSetting () {
        Setting.call(this);
    }
    UrlSetting.markup = textMarkup;
    UrlSetting.buttonMarkup = '<button id="button-<%=id%>" class="btn btn-blue-light <%=key%>">' + '<span><%=buttonLabel%></span></button>';
    UrlSetting.outputMarkup = '<output for="button-<%=id%>"></output>';
    /**
     * Implement a change handler to set on the RootSetting, to handle changes to URL text.
     * "this" is the text input DOM element that triggered the change.
     */
    UrlSetting.handleUrlChange = function () {
        console.log('handle change');
        return $(this).data('url')._handleUrlChange();
    };
    UrlSetting.handleUrlKeyUp = function () {
        console.log('handle key up');
        return $(this).data('url')._handleKeyUp();
    };
    /**
     * Implement a click handler to set on the RootSetting, to handle clicks on the Test Connection button.
     * "this" is the button input DOM element that was clicked.
     */
    UrlSetting.handleTestTrigger = function () {
        console.log('handle click');
        var $button = $(this);
        var $el = $('#' + $button.prop('id').slice('button-'.length))
                .first(),
            urlSetting = $el.data('url');
        urlSetting._handleTestTrigger();
        return false; // stopPropagation && preventDefault
    };
    // UrlSetting instance methods
    UrlSetting.prototype = new Setting();
    $.extend(UrlSetting.prototype, {
        _buildSelf: function (options) {
            this._makeSetting$el(textMarkup, options.json).addClass('setting-url');
            this.testConnectionXHR = null;
            this._testedValue = null;
            return this;
        },
        widgetize: function () {
            this.$el.after($(wrapperMarkup).append(_.template(UrlSetting.buttonMarkup + UrlSetting.outputMarkup, {
                id: this.$el.prop('id'),
                key: this.$el.prop('name'),
                buttonLabel: locale.label.test_connection
            })));
            this.setupListeners();
            this.$el.data('url', this);},
        setupListeners: function () {
            var $root = this.$el.parents('.setting-wrapper').last(),
                $allUrlSettings = $root.find('.setting-url');
            if (1 === $allUrlSettings.length) {
                $root
                    //.on('change', 'input[type="text"].setting-url', UrlSetting.handleUrlChange)
                    .on('keyup', 'input[type="text"].setting-url', UrlSetting.handleUrlKeyUp)
                    .on('click', 'input[type="text"].setting-url+.setting-wrapper>button', UrlSetting.handleTestTrigger);
                /*
                 * Modifying a button label in the avondale environment fails during a change event if the event
                 * is caused by clicking the button.
                 * In that case, the series of events goes:
                 * mouseDown(button), blur($el), change($el), mouseUp(button), click(button).
                 * Trouble is that jQuery UI captures the mouseUp, notices that the button changed since mouseDown,
                 * and bails in such a way that the button click handler never gets called.
                 */
            }
            return this;
        },
        _setFeedback: function (state, optionalTooltip) {
            var $output = this._getOutput(),
                $button = this._getButton(),
                $wrapper = $output.parent('.setting-wrapper');
            $wrapper
                .removeClass('setting-wait setting-failed setting-succeeded setting-canceled');
            $output
                .empty()
                .removeAttr('title');
            switch (state) {
                case 'wait':
                    $wrapper
                        .addClass('setting-wait');
                    $output
                        .text('waiting...')
                        .removeAttr('title');
                    $button.children('span')
                        .first()
                        .text('Cancel Test');
                    break;
                case 'succeed':
                    $wrapper
                        .addClass('setting-succeeded');
                    $output
                        //.text(String.fromCharCode(10004))
                        .html('<span>' + String.fromCharCode(10004) + '</span> Connection succeeded')
                        .attr('title', 'Connection succeeded');
                    $button.children('span')
                        .first()
                        .text('Clear Results');
                    break;
                case 'fail':
                    $wrapper
                        .addClass('setting-failed');
                    $output
                        //.text(String.fromCharCode(10006))
                        .html('<span>' + String.fromCharCode(10006) + '</span> Connection failed')
                        .attr('title', optionalTooltip || 'Connection failed');
                    $button.children('span')
                        .first()
                        .text('Clear Results');
                    break;
                case 'cancel':
                    $wrapper
                        .addClass('setting-canceled');
                    $button.children('span')
                        .first()
                        .text('Test Connection');
                    break;
                case 'clear':
                    $button.children('span')
                        .first()
                        .text('Test Connection');
            }
            return this;
        },
        /*
        _urlConditionallyEnableButton: function ($button, $output) {
            $button.prop('disabled', this.$el.prop('disabled') ||
                $output.hasClass('setting-wait') ||
                !(this.$el.val() || '').trim().length);
            $button.toggleClass('disabled', $button.prop('disabled'));
            return this;
        },
        */
        _getButton: function () {
            return this.$el.closest('.setting-wrapper').find('#button-' + this.$el.prop('id'));
        },
        _getOutput: function () {
            var id = this.$el.prop('id');
            return this.$el.closest('.setting-wrapper').find('output[for="button-' + id + '"]');
        },
        _handleKeyUp: function () {
            var value = this.$el.val().trim();
            if (value !== this._testedValue) {
                this._handleUrlChange();
            }
        },
        _handleUrlChange: function () {
            if (this.testConnectionXHR) {
                this.testConnectionXHR.abort();
            } else {
                this._setFeedback('clear');
            }
            return this;
        },
        toString: function () {
            return '[' + this.$el.prop('name') + ', ' + this.$el.val() + ']';
        },
        _completeTest: function () {
            this.testConnectionXHR = null;
            this._testedValue = null;
        },
        _handleTestTrigger: function () {
            var that = this,
                value = encodeURIComponent(this.$el.val().trim()),
                PREFIX = 'rest/settings/testconnection/',
                $wrapper = this.$el.next('.setting-wrapper');
            console.log(this.toString() + '._handleTestTrigger(' + $wrapper.prop('className') + ')');
            if ($wrapper.is('.setting-failed,.setting-succeeded')) {
                this._setFeedback('clear');
                return false;
            } else if ($wrapper.is('.setting-wait')) {
                this.testConnectionXHR.abort();
                return false;
            } else if ($wrapper.is('.setting-canceled')) {
                $wrapper.removeClass('setting-canceled');
                return false;
            }
            this._setFeedback('wait');
            this._testedValue = value;
            this.testConnectionXHR = $.ajax({
                type: 'GET',
                url: PREFIX + value,
                contentType : "application/json; charset=utf-8",
                dataType: 'json',
                timeout: 30000 // thirty seconds
            })
                .done(function (booleanTestResponse) {
                    // Additional arguments are status, xhr. status is always "success".
                    // "this" is the union of the $.ajax argument with ajax defaults.
                    console.log(that.toString() + '.done(' + booleanTestResponse + ')');
                    that._setFeedback(booleanTestResponse ? 'succeed' : 'fail');
                    that._completeTest();
                })
                .fail(function (xhr, cause) {
                    // "this" is the union of the $.ajax argument with ajax defaults.
                    console.log(that.toString() + '.fail(' + cause + ')');
                    if ('abort' === cause) {
                        that._setFeedback('clear');
                    } else {
                        that._setFeedback('fail', cause);
                    }
                    that._completeTest();
                });
            return false;
        }
    });

    function UserSetting () {
        Setting.call(this);
    }
    UserSetting.prototype = new Setting();
    $.extend(UserSetting.prototype, {
        _buildSelf: function (options) {
            this._makeSetting$el(textMarkup, options.json).addClass('setting-user');
        },
        widgetize: function (options) {
            var $userEl = this.$el,
                userCollection = options.userCollection;
            if (options.usersRequest) {
                $.when(options.usersRequest)
                    .done(function () {
                        //TODO: display 'firstName lastName <userName>' with userName as value
                        $userEl.typeahead({
                            source: userCollection.pluck('userName'),
                            items: 5
                        });
                    });
            }
        }
    });

    var factory = {
        manufactureSettings: function (options) {
            if (!options || !options.json) {
                throw new Error ('Setting Factory needs JSON meta-data from which to construct DOM.');
            }
            options.level = options.level || 0;
            options.$parentList = options.$parentList || [];
            options.parentJson = options.parentJson || [];
            options.jsonDomList = options.jsonDomList || [];
            var newSetting = factory.buildSetting(options);
            newSetting.set(options);
            options.jsonDomList.push({ json: options.json, $el: newSetting.$el });
            factory.addSetting508(newSetting, options);
            factory.wrapSetting(newSetting, options);
            factory.buildSettingChildren(newSetting, options);
            return newSetting;
        },
        // Returns a new setting, but not the subtree below that setting.
        buildSetting: function (options) {
            if (!options.level) {
                options.level = 0;
                return new GroupSetting();
            }
            switch (options.json.type) {
                case 'BOOLEAN':
                    return new BooleanSetting();
                case 'CHOICE':
                    return new ChoiceSetting();
                case 'DATE':
                    return new DateSetting();
                case 'DROPDOWN':
                    return new DropdownSetting();
                case 'DURATION':
                case 'SYSTEM_DURATION':
                    return new DurationSetting();
                case 'GROUP':
                    if ('DROPDOWN' === _.pluck(options.parentJson, 'type').pop()) {
                        return new OptionGroupSetting();
                    } else {
                        return new GroupSetting();
                    }
                    break;
                case 'INFORMATION':
                    return new InformationSetting();
                case 'INTEGER':
                    return new IntegerSetting();
                case 'NUMBER': // means floating-point
                    return new NumberSetting();
                case 'OPTION':
                    if (_.contains(_.pluck(options.parentJson, 'type'), 'DROPDOWN')) {
                        return new OptionSetting();
                    } else {
                        return new CandidateSetting();
                    }
                    break;
                case 'PASSWORD':
                    return new PasswordSetting();
                case 'STRING':
                    return new StringSetting();
                case 'URL':
                    return new UrlSetting();
                case 'USER':
                    return new UserSetting();
                default:
                    if (options.json.internalName) {
                        return new StringSetting();
                    } else {
                        return new InformationSetting();
                    }
            }
        },
        addSetting508: function (setting, options) {
            return setting.add508(options);
        },
        wrapSetting: function (setting, options) {
            var $wrapper = setting.wrap(options, factory.buildInstructionHtml(setting.$el, options.json));
            setting.widgetize(options);
            return $wrapper;
        },
        buildInstructionHtml: function ($el, json) {
            var hintContent = [];
            var autoHints = hint.makeHints(json.bounds, locale.label.autoHint).join('  ');
            if (autoHints) {
                hintContent.push('<span class="auto-hint">' + autoHints + '</span>');
            }
            if (json.hint) {
                hintContent.push('<span class="custom-hint">' + hint.punctuate(json.hint) + '</span>');
            }
            return hintContent.length ?
                '<p class="small setting-hint">' +
                    hintContent.join('  ') +
                '</p>' :
                '';
        },
        buildSettingChildren: function (parentSetting, options) {
            var json = options.json;
            if (!json.layoutChildren || !json.layoutChildren.length) {
                return;
            }
            options.level += 1;
            options.$parentList.push(options.$parentElement);
            options.parentJson.push(options.json);
            options.$parentElement = parentSetting.buildChildren$Container();
            $.each(json.layoutChildren || [], function () {
                options.json = this; // "this" is now a json setting from the parental layoutChildren.
                factory.manufactureSettings(options);
            });
            if (0 === options.$parentElement.children().length) {
                options.$parentElement.remove();
            }
            options.level -= 1;
            options.$parentElement = options.$parentList.pop();
            options.parentJson.pop();
            options.json = json;
        }
    };

    /**
     * Construct a new form from scratch, and return a list of objects of the form
     * { jsonObject: {Object} <node in options.json>, $el: {jQuery} <jQuery wrapped DOM element> }.
     * @param {Object} options
     *   Properties:
     *     $parentElement: {jQuery} // required.  Becomes the root wrapper.
     *     json: {Object} // required.  options.json.type must be GROUP.
     *     level: {Integer} // optional.  Undefined means 0.
     *     userCollection: {Backbone.Collection} // optional.  Collection of user information for USER type metadata.
     *     userRequest: {jqXHR} // optional.  Ajax request for userCollection.
     * @return {Array}
     */
    function generateForm (options) {
        options = _.clone(options);
        factory.manufactureSettings(options);
        return options.jsonDomList;
    }
    return generateForm;
});