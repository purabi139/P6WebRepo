define([
    'jquery', 'underscore', 'backbone', 'i18n!src/nls/localeStrings', 'text!src/views/widgets/forms/formView.htm'
], function ($, _, Backbone, locale, formTemplate) {
    'use strict';
    return Backbone.View.extend({
        inputVar : null,
        options : {
            identifier : '', //used as class to identify the widget
            label : '', //used as the display label,
            checked : false //value to put in input
        },
        initialize : function (options) {
            var that = this;
            _.defaults(options, that.options);

            var textBoxTemplate = _.pluckMarkup($(formTemplate), '.htm-checkBoxTemplate',{locale_label_title : options.label, type : options.identifier});

            var inputFull = $(textBoxTemplate);
            var tempCheck = inputFull.find('input');
            tempCheck.attr({
                disabled: false,
                checked: options.checked
            });

            this.inputVar = inputFull;
            return this;
        },
        render : function () {
            return this.inputVar;
        }
    });
});