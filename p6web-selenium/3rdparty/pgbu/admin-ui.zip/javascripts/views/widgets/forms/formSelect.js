define([
    'jquery', 'underscore', 'backbone', 'i18n!src/nls/localeStrings', 'text!src/views/widgets/forms/formView.htm'
], function ($, _, Backbone, locale, formTemplate) {
    'use strict';
    return Backbone.View.extend({
        tagName : 'select',
        options : {
            required : true, //when set to false, a blank option is added with empty string as a value
            identifier : '', //used as class to identify the widget
            label : '' //used as the display label,
        },
        selectTemplate : _.template(_.pluckMarkup($(formTemplate), '.htm-selectTemplate')),
        initialize : function (options) {
            var that = this;

            _.defaults(options, that.options);
            that.options = options;

            var selectTemplate = that.selectTemplate({locale_label_title : options.label, type : options.identifier});
            that.$el.append($(selectTemplate));

            if (options.sourceUrl) {
                var optionsURL = options.sourceUrl;
                $.ajax({
                    url : optionsURL,
                    type : 'GET',
                    contentType : "application/json; charset=utf-8",
                    dataType : "json",
                    success : function (data, textStatus, jqXHR) {
                        if (!options.required) {
                            data.splice(0, 0, {val : '', label : ' '});
                        }
                        var $selectTag = that.$el.find('select');
                        var optionsTemplate = _.template(_.pluckMarkup($(formTemplate), '.htm-selectOptionTemplate'));

                        $.each(data, function (value, key) {
                            $selectTag.append(optionsTemplate(key));
                        });
                    }
                });
            }
            if(options.val){
                var data = options.val;
                var $selectTag = that.$el.find('.'+options.identifier);
                var optionsTemplate = _.template(_.pluckMarkup($(formTemplate), '.htm-selectOptionTemplate'));

                $.each(data, function (value, key) {
                    $selectTag.append(optionsTemplate(key));
                });
            }
            return this;
        },
        render : function () {
            return this;
        }
    });

});