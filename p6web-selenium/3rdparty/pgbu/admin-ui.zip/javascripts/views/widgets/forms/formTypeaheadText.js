define([
    'jquery', 'underscore', 'backbone', 'i18n!src/nls/localeStrings', 'text!src/views/widgets/forms/formView.htm'
], function ($, _, Backbone, locale, formTemplate) {
    'use strict';
    return Backbone.View.extend({

        options : {
            typeaheadOptions : '', //    The typeahead object that will be passed to the bootstrap-typeahead.js plugin
            onChangeCallback : '', //    (Optional) Callback function to be invoked when an option is selected
            sourceUrl : '', //  (Optional) string or function that returns url of ajax call that requests the options
            parse : '', //(Required only if using sourceUrl) Function that formats ajax response from sourceUrl into an Array of strings
            identifier : '', //used as class to identify the widget
            label : '' //used as the display label
        },
        typeaheadTemplate : _.template(_.pluckMarkup($(formTemplate), '.htm-inputTemplate')),
        initialize : function (options) {
            var that = this;

            _.defaults(options, that.options);
            that.options = options;
            var typeaheadOptions = that.options.typeaheadOptions || {}, callback;
            var typeaheadComponent = that.typeaheadTemplate(that.options);
            that.$el.append($(typeaheadComponent));
            var editor = that.$el.find("input");
            if (that.options.sourceUrl) {
                var source = that.options.sourceUrl;
                $.ajax({
                    url : _.isFunction(source) ? source() : source,
                    dataType : 'json',
                    success : function (data) {
                        that.options.parse = that.options.parse || $.noop;
                        that.values = data;
                        typeaheadOptions.source = that.options.parse(data);
                        that.applyTypeahead(typeaheadOptions);
                    },
                    error : function (jqXHR, textStatus, errorThrown) {
                        console.log('A problem occurred getting the options for ' + that.options.identifier + ' typeahead field.');
                        console.log(textStatus + ': ' + errorThrown.toString() + '.');
                    }
                });
            } else {
                editor.typeahead(typeaheadOptions);
            }


            callback = that.options.onChangeCallback;
            if (callback) {
                that.$el.change(function () {

                    callback(that, editor);
                });
            }

            return this;
        },
        applyTypeahead : function (options) {
            var editor = this.$el.find("input");
            editor.typeahead(options);
        },
        render : function () {
            return this;
        },
        remove : function () {
            if (this.options.context.enabled) {
                this.$('.context').contextView('destroy');
            }
        }
    });
});
