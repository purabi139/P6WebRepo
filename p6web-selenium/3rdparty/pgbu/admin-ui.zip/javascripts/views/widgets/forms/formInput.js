define([
    'jquery', 'underscore', 'backbone', 'i18n!src/nls/localeStrings', 'text!src/views/widgets/forms/formView.htm'
], function ($, _, Backbone, locale, formTemplate) {
    'use strict';
    return Backbone.View.extend({
        inputVar : null,
        options : {
            identifier : '', //used as className to identify the widget
            label : '', //used as the display label,
            val : '' //value to put in input
        },
        initialize : function (options) {
            var that = this;
            _.defaults(options, that.options);
            var textBoxTemplate = _.pluckMarkup($(formTemplate), '.htm-inputTemplate', options);
            var inputFull = $(textBoxTemplate);
            var temp = inputFull.find("input");
            $(temp).attr("value", options.val);
            this.inputVar = inputFull;
            return this;
        },
        render : function () {
            return this.inputVar;
        }
    });
});