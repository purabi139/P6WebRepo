define([
    'jquery', 'underscore'
], function ($, _) {
    'use strict';

    /**
     * Governor.
     * Set up certain DOM elements to govern appearance and state of other DOM elements with the following actions,
     * which come in Positive/Negative pairs:
     * 'ENABLE'/'DISABLE', 'SHOW'/'HIDE', 'VISIT'/'DEPART'.
     *
     * Imposes some requirements on the DOM.
     *
     * All governing elements must be input elements and have a name attribute,
     * corresponding to the governor spec internalName property.
     *
     * All governed elements must have a wrapper ancestor with a class specified in
     * options.containerClassName (default "setting-wrapper").
     * Thus, a governed group would have to consist of at least two nested DOM elements:
     * an outer wrapper, and an inner governed element.
     *
     * The wrapper ancestor should contain all DOM elements that must look disabled when the governed element
     * is disabled.  For instance, it should contain any labels for the governed element that should be grayed out
     * and widgets that should be disabled.
     *
     * Governed elements will acquire jQuery data named 'governor', containing their governor specs,
     * and class "governed".
     *
     * Disabling or hiding a group element will disable all input elements within it, but visiting a group element
     * has no such effect.
     * Enabling, showing, or visiting a group element will enable all input elements within it unless
     * disabled by another governor.
     * The view is responsible for any reversals after governor processing.
     * After a governor change triggers governing activity, it triggers an event named 'governor'.
     * Listening for the governor event will ensure that reversals are handled after governing activity.
     */

    //TODO:
    // Governor could be done as a bootstrap data widget, like tabs, with instructions in the data-toggle.
    // This would eliminate the requirement of a name attribute on targeted settings.

    var governorGeneric = {
        options: { // Defaults
            // Elements of class containerClassName are targets of governors.
            // Governor value causes display classes such as "disabled" or "hidden" to be added to or removed from them.
            containerClassName: 'setting-wrapper'
        },
        governorSpec: { // Template
            "internalName": "", // name attribute of the governing form element...
            //TODO: "internalName" is setting-specific. Selector would be more general.
            "values": [
                //TODO: "true" for checkboxes is setting-specific, should be an option
                "true" // trigger value(s) of governing form element; "true" for checkboxes
            ],
            "action": "ENABLE" // one of "ENABLE", "DISABLE", "SHOW", "HIDE"...
            // Note that ENABLE and SHOW are positive actions and DISABLE and HIDE are negative actions.
            // In a contest, negative wins.
            // SHOW also enables and HIDE also disables.

        },
        /**
         * Setup governor actions. Sets .data('governor') on DOM elements that have governors.
         * @param {Array} specDomList // Items are { governor: {governorSpec}, $el: $el }
         * @param {jQuery} $container // Container DOM element of all governors described by specDomList
         * @param {Object} options // optionally contains containerClassName property.
         */
        setup: function (specDomList, $container, options) {
            _.each(specDomList, function (specDomPair) {
                specDomPair.$el.addClass('governed').data('governor', specDomPair.governor);
            });
            var governorNames = _.chain(specDomList)
                .pluck('governor')
                .pluck('internalName')
                .uniq()
                .value(),
                governorSelector = _.joinMultiSelector(governorNames, '[name="<%=key%>"]'),
                governorHandler = function () {
                    governor.activateGovernors($container, options);
                    $container.trigger('governed');
                };
            $container
                .on('change', governorSelector, governorHandler)
                .on('keyup', governorSelector, _.debounce(governorHandler, 500));
        },
        /**
         * Perform actions dictated by governor values on $container and its descendants.
         * @param {jQuery} $container // root or element with class options.containerClassName
         * @param {Object} options // optionally contains containerClassName property.
         */
        activateGovernors: function ($container, options) {
            options = options || governorGeneric.options;
            options.containerSelector = '.' + options.containerClassName;
            options.$root = $container;
            governor.showTree($container, options);
            governor.enableTree($container, options);
            governor.conditionallyHideNodeAndSubtree($container, options);
            governor.conditionallyDisableNodeAndSubtree($container, options);
            return true;
        },
        _getWrapped$Setting: function ($wrapper, options) {
            // The setting that $wrapper wraps is not guaranteed to be a direct child of $wrapper.
            // We can guarantee, however, that it isn't wrapped by another wrapper.
            return $wrapper.find('.governed') // All descendant governed DOM elements
                .filter(function () { // Only those not wrapped by another, lower, wrapper
                    return 0 === $(this)
                        .parentsUntil($wrapper)
                        .filter(options.containerSelector)
                        .length;
                });
        },
        _getChild$Wrappers: function ($wrapper, options) {
            // Most likely the highest descendant wrapper DOM nodes are not direct DOM children of $wrapper,
            // but by definition, the highest ones are not wrapped by another, lower, wrapper.
            return $wrapper.find(options.containerSelector) // All descendant wrappers
                .filter(function () { // Only those not wrapped by another, lower, wrapper
                    return 0 === $(this)
                        .parentsUntil($wrapper)
                        .filter(options.containerSelector)
                        .length;
                });
        },
        /**
         * True if $el's governor's value dictates doing a negative action unconditionally.
         * @param {jQuery} $el // must have a governorSpec in .data('governor')
         * @param {Array} positiveAction // List of strings denoting positive actions like ENABLE or SHOW
         * @param {Array} negativeAction // List of strings denoting negative actions like DISABLE or HIDE
         * @param options
         * @return {Boolean}
         * @private
         */
        _doNegativeAction: function ($el, positiveAction, negativeAction, options) {
            var governorSpec = $el.data('governor');
            if (!governorSpec) {
                return false;
            }
            // Consider both positive and negative enablers, in case we later add more actions that are orthogonal.
            var isPositiveAction = _.contains(positiveAction, governorSpec.action),
                isNegativeAction = _.contains(negativeAction, governorSpec.action);
            // If governorSpec.action is none of the actions we're looking for,
            // or if it is both positive and negative (ambiguous),
            // don't do the negative action.
            if (isPositiveAction === isNegativeAction) {
                return false;
            }
            var $governorEl = options.$root
                .find(':input[name="' + governorSpec.internalName + '"]'),
                governorValue = governor.getValue($governorEl),
                governorValueInSpec = _.contains(governorSpec.values, governorValue);
            return (isPositiveAction && !governorValueInSpec) || (isNegativeAction && governorValueInSpec);
        },
        /**
         * Get the value of $el; checkboxes are always 'true' or 'false';
         * for radio buttons, $el should contain all of them of the same name.
         * @param $el
         * @return {String}
         */
        getValue: function ($el) {
            var $checkboxFilter = $el.filter(':checkbox'),
                $radioFilter = $el.filter(':radio:checked'),
                $regularFilter = $el.not(':checkbox,:radio'),
                value = '';
            if ($checkboxFilter.length) {
                //TODO: settingism, should be customized by an option.
                value = $checkboxFilter.filter(':checked').length ? 'true' : 'false';
            } else if ($radioFilter.length) {
                value = $radioFilter.val();
            } else if ($regularFilter.length) {
                value = $regularFilter.val();
            }
            return value;
        }
    };

    var governorEnableDisable = {
        /**
         * Enable $wrapper and all its descendants.  Intended for use on the root node, affecting the entire tree.
         * @param {jQuery} $wrapper
         * @param {Object} options
         * @private
         */
        enableTree: function ($wrapper, options) {
            $wrapper.find(options.containerSelector + '.disabled').andSelf().removeClass('disabled');
            $wrapper.find(':input:disabled').removeAttr('disabled').removeClass('disabled');
        },
        /**
         * Disable $wrapper and all its descendants.  Intended for use on a subtree.
         * @param {jQuery} $wrapper
         * @private
         */
        disableNodeAndSubtree: function ($wrapper) {
            $wrapper.addClass('disabled');
            var $inputs = $wrapper.find(':input');
            $inputs.attr('disabled', 'disabled').addClass('disabled');
        },
        /**
         * Disable $wrapper and all its descendants conditionally on governor values.
         * Intended for use on the root or any subtrees below the root; recursive.
         * @param $wrapper
         * @param options
         * @private
         */
        conditionallyDisableNodeAndSubtree: function ($wrapper, options) {
            var $setting = governor._getWrapped$Setting($wrapper, options);
            if (governor._doNegativeAction($setting, ['ENABLE', 'SHOW'], ['DISABLE', 'HIDE'], options)) {
                governor.disableNodeAndSubtree($wrapper);
            } else {
                governor._getChild$Wrappers($wrapper, options)
                    .each(function () { governor.conditionallyDisableNodeAndSubtree($(this), options); });
            }
        }
    };

    var governorShowHide = {
        /**
         * Show $wrapper and all its descendants.  Intended for use on the root node, affecting the entire tree.
         * @param {jQuery} $wrapper
         * @param {Object} options
         * @private
         */
        showTree: function ($wrapper, options) {
            $wrapper.find(options.containerSelector + '.hidden').andSelf().removeClass('hidden');
        },
        /**
         * Hide $wrapper and all its descendants.  Intended for use on a subtree.
         * @param {jQuery} $wrapper
         * @private
         */
        hideNodeAndSubtree: function ($wrapper) {
            $wrapper.addClass('hidden');
        },
        /**
         * Hide an element and its descendants conditionally on governor values.
         * Intended for use on the root or any subtrees below the root; recursive.
         * @param {jQuery} $wrapper
         * @param {Object} options
         * @private
         */
        conditionallyHideNodeAndSubtree: function ($wrapper, options) {
            var $setting = governor._getWrapped$Setting($wrapper, options);
            if (governor._doNegativeAction($setting, ['SHOW'], ['HIDE'], options)) {
                governor.hideNodeAndSubtree($wrapper);
            } else {
                governor._getChild$Wrappers($wrapper, options)
                    .each(function () { governor.conditionallyHideNodeAndSubtree($(this), options); });
            }
        }
    };

    var governor = $.extend(
        {},
        governorGeneric,
        governorEnableDisable,
        governorShowHide
    );

    return governor;
});