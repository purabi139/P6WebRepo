define([
    'jquery', 'underscore', 'backbone', "i18n!src/nls/localeStrings",
    "text!src/templates/widgets/actionBar.htm", "src/enums/actionBar",
    "src/views/widgets/toolbar"
], function ($, _, Backbone, locale, viewMarkup, ActionBarEnums, Toolbar) {
    "use strict";

    return Backbone.View.extend({
        defaults: {
            type: ActionBarEnums.Type.SAVE,
            message: locale.text.action_bar_default
        },

        events: {
            "click .save": "_save",
            "click .saveAs": "_saveAs",
            "click .cancel": "_cancel"
        },

        //TODO: options should probably include button details
        initialize: function () {
            _.defaults(this.options.actionBar, this.defaults);
        },

        render: function () {
            if (this.$el.children().length !== 0) {
                return;
            }

            var markup = _.template(viewMarkup)({
                message: this.options.actionBar.message
            });

            this.$el.append(markup);
            this.$(".toolbar").append(this._createToolbar());
        },

        hide: function () {
            if (!this.$el.is(":hidden")) {
                this.$el.slideUp(200);
            }
        },

        show: function () {
            if (this.$el.is(":hidden")) {
                this.$el.slideDown(200);
            }
        },

        remove: function () {
            this.off();
            this.undelegateEvents();
            this.hide();
            this.$el.empty();
        },
        disableSave : function () {
            this.$el.find(':input.save').prop('disabled', true);
            return this;
        },
        _createToolbar: function () {
            var cancelButton = null;
            var saveButton = null;

            cancelButton = Toolbar.ButtonGroup({
                buttons: [Toolbar.Button({
                    recognizedAs: "cancel",
                    label: locale.label.cancel,
                    type: Toolbar.ButtonType.Action
                })]
            });
            switch (this.options.actionBar.type) {
                case ActionBarEnums.Type.SAVE:
                    saveButton = Toolbar.ButtonGroup({
                        buttons: [Toolbar.Button({
                            recognizedAs: "save",
                            label: locale.label.save,
                            type: Toolbar.ButtonType.Action
                        })]
                    });
                    break;
                case ActionBarEnums.Type.SAVE_AS:
                    saveButton = Toolbar.SplitButtonDropdown({
                        recognizedAs: "save",
                        buttonLabel: locale.label.save,
                        buttonItems: [
                            {
                                recognizedAs: "saveAs",
                                label: locale.label.save_as
                            }
                        ],
                        dropDirection: Toolbar.DropDirection.Up,
                        type: Toolbar.ButtonType.Action
                    });
                    break;
            }

            return Toolbar.Toolbar({
                toolbarItems: [
                    cancelButton,
                    saveButton
                ]
            });
        },

        _save: function () {
            this.trigger(ActionBarEnums.Event.SAVE);
        },

        _saveAs: function () {
            this.trigger(ActionBarEnums.Event.SAVE_AS);
        },

        _cancel: function () {
            this.trigger(ActionBarEnums.Event.CANCEL);
        }
    });
});
