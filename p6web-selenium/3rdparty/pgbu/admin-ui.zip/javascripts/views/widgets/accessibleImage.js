define([
    'jquery', 'underscore'], function ($, _) {

    'use strict';
    var imageMarkup = '<span class="<%=accessibleClass%>"><span><%=alternateText%></span></span>';
    /* This widget creates an accessible Image when you need to put the image in the stylesheet.
     It puts text off the visible screen so a sighted user would not see it, but the screen Reader would say it.
     * You should use <img alt/> markup when you can.
     * The paramaters are:
     * cssClass which uses the _.mixin .accesible-image(imageSource). just pass in the path to the image you want to use
     * altText which is the text that the screen reader would use*/
    $.widget('orcl.accessibleImage', {
        _options : {
            cssClass : 'accessibleImage',
            altText : ''
        },
        _create : function () {
            var imageScope = this;
            var imageElement = _.template(imageMarkup,
                {alternateText : imageScope.options.altText, accessibleClass : imageScope.options.cssClass});

            imageScope.element.append(imageElement);

        },
        rootElement: function(){
            //top level element where you put the css class with image in stylesheet
            return this.element.find('span:first');
        },
        accessibleTextElement: function(){
            //element that screen reader will read
            return this.rootElement().find('>span');
        }
    });
});