define([
    'jquery', 'underscore', 'i18n!src/nls/localeStrings',
    'text!src/templates/widgets/scrollablelist.htm'
], function ($, _, Locale, ScrollableListMarkup
    ) {
    'use strict';
    function toSixDigitString (n) {
        var result = Number(n).toFixed(0);
        return String('000000').slice(0, 6 - result.length) + result;
    }

    var $scrollableListMarkup = $(ScrollableListMarkup);

    var $itemMarkup = _.pluckMarkup($scrollableListMarkup, '.scrollable-list-item', null);
    var itemTemplate = _.template($itemMarkup);

    /**
     * Initialize scrollableList from options.
     * "this" should be a $('ul').
     * @param {Array} content // array of {id: {String}, display: {String}} objects
     * @param {Object} options: {
     *     checkboxes: {Boolean}
     *     deleteButtons: {Boolean}
     *     itemClass: {String} // space delimited list of classNames
     *     newPlaceholder: {String} // placeholder for a new item, defaults to localeStrings.label._new.
     *     scrollAmount: {Number} // index into collection to initially display at the top of the view
     *     selection: {String} // id of a member of collection
     * }
     * @events { // events triggered by scrollableList; context is the scrollableList.
     *     'populated' ()
     *     'checked' ([ {String} <id for a look-up in a collection> ])
     *     'unselected' ({ id: {String} <id for look-up in a collection>})
     *     'selected' ({ id: {String} <id for look-up in a collection>})
     *     'editstart' triggered while inserting the item
     *     'editend' triggered when new item is given a name
     * }
     * @return undefined
     */
    $.widget('orcl.scrollablelist', {
        options: {
            checkboxes: false,
            content: [],
            deleteButtons: false,
            itemClass: [],
            lock: 'all',
            newPlaceholder: Locale.label._new,
            typeaheadOptions: [],
            scrollAmount: 0
        },
        _create: function () {
            var settings = this.options, that = this;
            settings.newPlaceholder = Locale.label[settings.newPlaceholder] || settings.newPlaceholder;
            this.element.addClass('ui-scrollable-list');
            this._setOption('checkboxes', settings.checkboxes);
            this._setOption('deleteButtons', settings.deleteButtons);
            // Start with a clean slate
            this.element.on('click', 'li', $.proxy(that, 'select'));
            this._setOption('lock', settings.lock);
            this.populate(this.options.content || []);
            delete this.options.content;
            this._nextNewID = 0;
        },

        _removeItems: function ($items) {
            var that = this;
            var deletedIDs = _.map($items, function(item){return $(item).attr('id');});
            if ($items.is('.selected')) {
                this.deselect();
            }

            var removeChecked = $items.has('input:checked').length;
            $items.css('min-height', 0);
            $items.slideUp();/*.promise()
                .then(function () {*/
                    $items.remove();
                    if (removeChecked) {
                        that._trigger('checked', null, that.getChecklist());
                    }
              //  });
            that._trigger('remove',null, deletedIDs);
            return this;
        },

        _setOption: function (key, value) {
            if (key === 'checkboxes') {
                if (value) {
                    this.element.addClass('show-checkboxes')
                        .on({
                            change: $.proxy(this, 'checkedEvent'),
                            click: $.proxy(this, 'checkClick')
                        }, 'input[type="checkbox"]');
                } else {
                    this.element.removeClass('show-checkboxes')
                        .off({
                            change: $.proxy(this, 'checkedEvent'),
                            click: $.proxy(this, 'checkClick')
                        }, 'input[type="checkbox"]');
                }
            }
            if (key === 'checked') {
                if (value) {
                    this.options.checked = value;
                } else {
                    delete this.options.checked;
                }
            }
            if (key === 'content') {
                this.populate(value || []);
                delete this.options.content;
            }
            if (key === 'deleteButtons') {
                if (value) {
                    this.element.addClass('show-delete-buttons')
                        .on('click', 'button', $.proxy(this, 'removeEvent'));
                } else {
                    this.element.removeClass('show-delete-buttons')
                        .off('click', 'button', $.proxy(this, 'removeEvent'));
                }
            }
            /*if (key === 'lock') {
                this.element.off('dblclick.orcl');
                if (value === 'old') {
                    this.element.on('dblclick', 'li[data-scrollable-list].ui-new-item', $.proxy(this, 'edit'));
                } else if (value !== 'all') {
                    this.element.on('dblclick', 'li[data-scrollable-list]', $.proxy(this, 'edit'));
                }
            }*/
            if (key === 'select') {
                if (value) {
                    this.select(value);
                } else {
                    this.deselect();
                }
            }
            if (key === 'selected') {
                if (value) {
                    this.options.selected = value;
                } else {
                    delete this.options.selected;
                }
            }
            //TODO: implement key === 'disabled'.
            $.Widget.prototype._setOption.apply(this, arguments);
        },

        checkClick: function ($event) {
            $event.stopImmediatePropagation();
        },

        checkedEvent: function ($event) {
            $event.stopImmediatePropagation();
            this._trigger('checked', null, this.getChecklist());
        },

        destroy: function () {
            var that = this;
            this.deselect();
            this.element
                .removeClass('ui-scrollable-list')
                .off('click', 'li[id]', that.select);
            $.Widget.prototype.destroy.call(this);
        },

        deselect: function () {
            var $selection = this.element.find('li.selected');
            if ($selection.length) {
                $selection.removeClass('selected ui-selected');
                this._trigger('unselected', null, {
                    id: $selection.attr('id')
                });
            }
            return this;
        },

        // Select an item by id String, by jQuery event, by DOM element, or by jQuery-wrapped DOM.
        edit: function (item, newLabel) {
            var $item = this.getItem(item);
            $item.find('a').html(newLabel);
            /*if ($item && $item.length && !this.element.has('input[type="text"]').length) {
                console.debug('Edit ' + $item.text().trim());
                var $newInput = $('<input class="ui-new-item" type="text" placeholder="' +
                    this.options.newPlaceholder + '" />')
                    .val($item.text().trim());
                $item.children('span').empty().append($newInput);
                $newInput
                    .typeahead(this.options.typeaheadOptions)
                    .get(0).focus();
                this._trigger('editstart');
            }*/
            return this;
        },

        getSelectedID: function () {
            return this.element.children('.selected').attr('id') || null;
        },

        getAllIDs: function () {
            return this.element.children('li').map(function () {
                return $(this).attr('id');
            }).get();
        },

        getChecklist: function () {
            return this.element
                .find('input:checked')
                .closest('li')
                .map(function () {
                    return $(this).attr('id');
                });
        },

        getItem: function (item) {
            return !item ? item :
                typeof item === 'string' ? this.element.find('li[id="' + item + '"]') :
                item.target ? ($(item.target).is(':input') ? null : $(item.currentTarget)) :
                item.each ? item : $(item);
        },

        populate: function (newContent) {
            var settings = this.options, that = this, $selection = null;
            this.element.empty();
            $.each(newContent, function (index, inputItem) {
                inputItem = inputItem.hasOwnProperty('id') && inputItem.hasOwnProperty('display') ?
                        inputItem : { display: String(inputItem), id: String(inputItem) };
                var $item = $(itemTemplate(inputItem));
                if (settings.selection !== undefined && settings.selection === inputItem.id) {
                    $selection = $item;
                }
                that.element.append($item);
            });
            this._trigger('populated');
            this.select($selection);
            return this;
        },

        remove: function (itemArray) {
            var that = this;
            return this._removeItems($($.map(itemArray, function (item) {
                return that.getItem(item).get(0);
            })));
        },

        removeEvent: function ($event) {
            this._removeItems($($event.target).closest('li'));
            $event.stopImmediatePropagation();
        },

        // Select an item by id String, by jQuery event, by DOM element, or by jQuery-wrapped DOM.
        select: function (item) {
            var $item = this.getItem(item);
            if ($item && $item.length) {
                this.deselect();
                if ($item.length) {
                    $item.addClass('selected ui-selected');
                    this._trigger('selected', null, { id: $item.attr('id') });
                }
            }
            if (item && item.preventDefault){
                item.preventDefault();
            }
            return this;
        },

        _keepNewItem: function ($event) {
            var $target = $($event.target),
                val = $target.val();
            if (!$target.data('typeahead') || true === $target.data('typeahead').shown) {
                $event.target.focus();
            } else if (val) {
                $target.off('.typeahead.data-api');
                var typeahead = $target.data('typeahead');
                typeahead.$menu.remove();
                $target.data('typeahead', null);
                var $span = $target.parent().empty().text(val);
                var $item = $span
                    .parent() // li
                    .removeClass('ui-editing');
                this._trigger('editend', null, { id: $item.attr('id') });
            }
        },

        _newEditableItem: function (newContent, newID) {
            var that = this;
            return $(itemTemplate({
                    id: newID || '_' + toSixDigitString(this._nextNewID++),
                    display: this.options.newPlaceholder/*'<input class="ui-new-item" type="text" placeholder="' +
                        this.options.newPlaceholder + '" />'*/
                }))
                .val(newContent || '')
                .addClass('ui-new-item ui-editing')
                .hide()
                .on('blur', 'input[type="text"]', $.proxy(that, '_keepNewItem'));
        },

        _newItemPostInsertion: function ($newItem) {
            var that = this;

           $newItem.slideDown();//)
           /* $newItem.promise()
                .done(
                function () {
*/
                   /* $newItem.find('input[type="text"]')
                        .typeahead(that.options.typeaheadOptions)
                        .get(0).focus();*/
                   // alert("new");
                    that._trigger('editstart',null,{ id: $newItem.attr('id') });
             //   });
            return this;
        },

        insert: function (index, newContent, newID) {
            var $newItem = this._newEditableItem(newContent, newID),
                $before = typeof index === 'number' ?
                this.element.find('li:nth-child(' + (index + 1) + ')') :
                this.getItem(index);
            return $newItem &&
                this._newItemPostInsertion(($before && $before.length > 0) &&
                    $newItem.insertBefore($before) ||
                    $newItem.appendTo(this.element)) ||
                this;
        },

        append: function (newContent, newID) {
            var $newItem = this._newEditableItem(newContent, newID);
            return $newItem && this._newItemPostInsertion($newItem.appendTo(this.element)) || this;
        },

        prepend: function (newContent, newID) {
            var $newItem = this._newEditableItem(newContent, newID);
            return $newItem && this._newItemPostInsertion($newItem.prependTo(this.element)) || this;
        },
        setItemId: function(currentId, newId){
            this.getItem(currentId).attr('id',newId);
        },
        unsetNew: function(newIds){
            var newItemSelector = 'li';
            var separator = '';
            _.each(newIds, function(id){
                newItemSelector += separator + '[id="' + id + '"]';
                separator = ',';
            });
            $(newItemSelector).removeClass('ui-new-item');
        }
    });

    return 'orcl.scrollablelist';
});
